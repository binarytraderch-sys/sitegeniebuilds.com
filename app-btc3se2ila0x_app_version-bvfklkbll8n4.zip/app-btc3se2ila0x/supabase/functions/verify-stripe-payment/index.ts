import { createClient } from 'jsr:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@19.1.0';
import { corsHeaders, ok, fail } from '../_shared/utils.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');

    if (!stripeKey) throw new Error('STRIPE_SECRET_KEY is not configured. Please add it in project settings.');

    const supabase = createClient(supabaseUrl, supabaseKey);
    const stripe = new Stripe(stripeKey, { apiVersion: '2025-08-27.basil' });

    const { sessionId } = await req.json();
    if (!sessionId) throw new Error('Missing sessionId parameter');

    const session = await stripe.checkout.sessions.retrieve(sessionId);

    if (session.payment_status !== 'paid') {
      return ok({ verified: false, status: session.payment_status, sessionId: session.id });
    }

    // Optimistic update: only move from pending → completed once
    const { data: order } = await supabase
      .from('orders')
      .select('id, status')
      .eq('stripe_session_id', sessionId)
      .maybeSingle();

    let orderUpdated = false;
    if (order && order.status === 'pending') {
      const { error } = await supabase
        .from('orders')
        .update({
          status: 'completed',
          completed_at: new Date().toISOString(),
          customer_email: session.customer_details?.email,
          customer_name: session.customer_details?.name,
          stripe_payment_intent_id: session.payment_intent as string,
        })
        .eq('id', order.id)
        .eq('status', 'pending');
      orderUpdated = !error;
    } else if (order?.status === 'completed') {
      orderUpdated = true;
    }

    return ok({
      verified: true,
      status: 'paid',
      sessionId: session.id,
      paymentIntentId: session.payment_intent,
      amount: session.amount_total,
      currency: session.currency,
      customerEmail: session.customer_details?.email,
      customerName: session.customer_details?.name,
      orderUpdated,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Payment verification failed';
    return fail(msg, 500);
  }
});
