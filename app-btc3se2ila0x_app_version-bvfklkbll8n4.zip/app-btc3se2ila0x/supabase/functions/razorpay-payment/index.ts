import { createClient } from 'npm:@supabase/supabase-js@2';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, authorization, x-client-info, apikey, content-type',
};

const PLANS: Record<string, { credits: number; amountPaise: number; name: string }> = {
  starter:      { credits: 1000,  amountPaise: 50000,  name: 'Starter – ₹500/month'       },
  professional: { credits: 2000,  amountPaise: 100000, name: 'Professional – ₹1,000/month' },
  enterprise:   { credits: 10000, amountPaise: 500000, name: 'Enterprise – ₹5,000/month'   },
};

const DEDUCTION_COST = 30;

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

  const supabaseUrl    = Deno.env.get('SUPABASE_URL')!;
  const serviceKey     = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const razorpayKeyId  = Deno.env.get('RAZORPAY_KEY_ID')!;
  const razorpaySecret = Deno.env.get('RAZORPAY_KEY_SECRET')!;
  const anonKey        = Deno.env.get('SUPABASE_ANON_KEY')!;

  // Authenticate user from JWT
  const authHeader = req.headers.get('Authorization') ?? req.headers.get('authorization');
  if (!authHeader) return json({ error: 'Missing authorization header' }, 401);

  const userClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: { user }, error: authErr } = await userClient.auth.getUser();
  if (authErr || !user) return json({ error: 'Unauthorized' }, 401);

  const serviceClient = createClient(supabaseUrl, serviceKey);

  let body: Record<string, string>;
  try { body = await req.json(); } catch { return json({ error: 'Invalid JSON' }, 400); }

  const { action } = body;

  // ── CREATE ORDER ─────────────────────────────────────────────────────────────
  if (action === 'create-order') {
    const plan = PLANS[body.plan];
    if (!plan) return json({ error: 'Invalid plan' }, 400);

    const credentials = btoa(`${razorpayKeyId}:${razorpaySecret}`);
    const orderRes = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: { Authorization: `Basic ${credentials}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        amount:   plan.amountPaise,
        currency: 'INR',
        receipt:  `sg_${user.id.slice(0, 8)}_${Date.now()}`,
        notes:    { user_id: user.id, plan: body.plan, credits: String(plan.credits) },
      }),
    });

    if (!orderRes.ok) {
      const errText = await orderRes.text();
      return json({ error: `Razorpay error: ${errText}` }, 502);
    }

    const order = await orderRes.json();
    return json({
      order_id:  order.id,
      amount:    order.amount,
      currency:  order.currency,
      key_id:    razorpayKeyId,
      plan_name: plan.name,
    });
  }

  // ── VERIFY PAYMENT + ADD CREDITS ─────────────────────────────────────────────
  if (action === 'verify-payment') {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, plan } = body;
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !plan) {
      return json({ error: 'Missing verification fields' }, 400);
    }

    // Verify HMAC-SHA256 signature using Web Crypto API
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      'raw', enc.encode(razorpaySecret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'],
    );
    const sigBuf = await crypto.subtle.sign('HMAC', keyMaterial, enc.encode(`${razorpay_order_id}|${razorpay_payment_id}`));
    const expectedSig = Array.from(new Uint8Array(sigBuf)).map(b => b.toString(16).padStart(2, '0')).join('');

    if (expectedSig !== razorpay_signature) {
      return json({ error: 'Payment signature verification failed' }, 400);
    }

    // Idempotency guard – reject duplicate payment IDs
    const { data: existing } = await serviceClient
      .from('credit_transactions')
      .select('id')
      .eq('razorpay_payment_id', razorpay_payment_id)
      .maybeSingle();
    if (existing) return json({ error: 'Payment already processed' }, 409);

    const planInfo = PLANS[plan];
    if (!planInfo) return json({ error: 'Invalid plan' }, 400);

    // Fetch current credits
    const { data: profile, error: profileErr } = await serviceClient
      .from('profiles')
      .select('credits')
      .eq('id', user.id)
      .maybeSingle();
    if (profileErr || !profile) return json({ error: 'Profile not found' }, 404);

    const newCredits = (profile.credits ?? 0) + planInfo.credits;

    // Atomically update credits and log transaction
    const [updateResult] = await Promise.all([
      serviceClient.from('profiles').update({ credits: newCredits }).eq('id', user.id),
      serviceClient.from('credit_transactions').insert({
        user_id:             user.id,
        type:                'topup',
        amount:              planInfo.credits,
        description:         planInfo.name,
        razorpay_payment_id,
        razorpay_order_id,
      }),
    ]);

    if (updateResult.error) return json({ error: 'Failed to update credits' }, 500);
    return json({ success: true, credits_added: planInfo.credits, total_credits: newCredits });
  }

  // ── DEDUCT CREDITS ───────────────────────────────────────────────────────────
  if (action === 'deduct-credits') {
    const { data: profile, error: profileErr } = await serviceClient
      .from('profiles')
      .select('credits')
      .eq('id', user.id)
      .maybeSingle();
    if (profileErr || !profile) return json({ error: 'Profile not found' }, 404);

    const current = profile.credits ?? 0;
    if (current < DEDUCTION_COST) {
      return json({ error: 'Insufficient credits', credits: current }, 402);
    }

    const newCredits = current - DEDUCTION_COST;
    const [updateResult] = await Promise.all([
      serviceClient.from('profiles').update({ credits: newCredits }).eq('id', user.id),
      serviceClient.from('credit_transactions').insert({
        user_id:     user.id,
        type:        'deduction',
        amount:      DEDUCTION_COST,
        description: 'Website generation (-30 credits)',
      }),
    ]);

    if (updateResult.error) return json({ error: 'Failed to deduct credits' }, 500);
    return json({ success: true, credits_deducted: DEDUCTION_COST, remaining_credits: newCredits });
  }

  return json({ error: `Unknown action: ${action}` }, 400);
});

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS },
  });
}
