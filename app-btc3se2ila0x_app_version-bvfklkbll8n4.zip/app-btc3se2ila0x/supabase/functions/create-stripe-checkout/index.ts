import { createClient } from 'jsr:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@19.1.0';
import { corsHeaders, ok, fail } from '../_shared/utils.ts';

interface OrderItem {
  name: string;
  price: number;
  quantity: number;
  image_url?: string;
}

interface CheckoutRequest {
  items: OrderItem[];
  currency?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });
  if (req.method !== 'POST') return fail('Method not allowed', 405);

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');

    if (!stripeKey) throw new Error('STRIPE_SECRET_KEY is not configured. Please add it in project settings.');

    const supabase = createClient(supabaseUrl, supabaseKey);
    const stripe = new Stripe(stripeKey, { apiVersion: '2025-08-27.basil' });

    const body: CheckoutRequest = await req.json();
    const { items, currency = 'usd' } = body;

    if (!items?.length) throw new Error('Items cannot be empty');
    for (const item of items) {
      if (!item.name || item.price <= 0 || item.quantity <= 0) {
        throw new Error('Invalid item data');
      }
    }

    // Get user from auth header
    const authHeader = req.headers.get('Authorization');
    const token = authHeader?.replace('Bearer ', '');
    const { data: { user } } = token
      ? await supabase.auth.getUser(token)
      : { data: { user: null } };

    const totalAmount = items.reduce((sum, item) => sum + Math.round(item.price * 100) * item.quantity, 0);
    const formattedItems = items.map((item) => ({
      name: item.name.trim(),
      price: Math.round(item.price * 100),
      quantity: item.quantity,
      image_url: item.image_url?.trim() || '',
    }));

    // Create pending order
    const { data: order, error: orderErr } = await supabase
      .from('orders')
      .insert({
        user_id: user?.id ?? null,
        items: formattedItems,
        total_amount: totalAmount / 100,
        currency: currency.toLowerCase(),
        status: 'pending',
      })
      .select()
      .single();

    if (orderErr) throw new Error(`Failed to create order: ${orderErr.message}`);

    const origin = req.headers.get('origin') || '';

    const session = await stripe.checkout.sessions.create({
      line_items: items.map((item) => ({
        price_data: {
          currency: currency.toLowerCase(),
          product_data: {
            name: item.name,
            ...(item.image_url ? { images: [item.image_url] } : {}),
          },
          unit_amount: Math.round(item.price * 100),
        },
        quantity: item.quantity,
      })),
      mode: 'payment',
      success_url: `${origin}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/payment-cancel`,
      metadata: { order_id: order.id, user_id: user?.id ?? '' },
    });

    await supabase
      .from('orders')
      .update({ stripe_session_id: session.id })
      .eq('id', order.id);

    return ok({ url: session.url, sessionId: session.id, orderId: order.id });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Payment processing failed';
    return fail(msg, 500);
  }
});
