import { createClient } from 'npm:@supabase/supabase-js@2';

// CORS headers
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers':
    'Authorization, authorization, x-client-info, apikey, content-type',
};

// Direct API endpoints — OpenRouter removed; multi-model fallback chain v42
const GEMINI_URL =
  'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse';
const ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages';
const OPENAI_URL    = 'https://api.openai.com/v1/chat/completions';

// Platform Gemini gateway (fallback if direct keys are absent)
const GEMINI_GATEWAY_URL =
  'https://app-btc3se2ila0x-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse';

const MAX_PROMPT_CHARS = 12_000;

// Razorpay plans
const RAZORPAY_PLANS: Record<string, { credits: number; amountPaise: number; name: string }> = {
  starter:      { credits: 1000,  amountPaise: 50000,  name: 'Starter - Rs.500/month'        },
  professional: { credits: 2000,  amountPaise: 100000, name: 'Professional - Rs.1,000/month'  },
  enterprise:   { credits: 10000, amountPaise: 500000, name: 'Enterprise - Rs.5,000/month'    },
};
const DEDUCTION_COST = 30;

// Types
interface OpenAIMsg  { role: 'system' | 'user' | 'assistant'; content: string }
interface GeminiPart { text: string }
interface GeminiMsg  { role: 'user' | 'model'; parts: GeminiPart[] }

// Helpers
function truncate(s: string, max: number): string {
  return s.length <= max ? s : s.slice(0, max) + '\n[...truncated to fit token limit]';
}

function compressMessages(msgs: OpenAIMsg[]): OpenAIMsg[] {
  const total = msgs.reduce((n, m) => n + m.content.length, 0);
  if (total <= MAX_PROMPT_CHARS) return msgs;
  return msgs.map((m, i) => {
    if (i === 0 || i >= msgs.length - 2) return m;
    if (m.role === 'assistant' && m.content.length > 500)
      return { ...m, content: '[Previous output omitted to save tokens]' };
    if (m.role === 'user' && m.content.length > 800)
      return { ...m, content: truncate(m.content, 800) };
    return m;
  });
}

async function hmacSha256Hex(secret: string, message: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'],
  );
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(message));
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function jsonResp(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS },
  });
}

// Convert OpenAI messages → Gemini contents[] (merges consecutive same-role turns)
function toGeminiContents(msgs: OpenAIMsg[]): GeminiMsg[] {
  const out: GeminiMsg[] = [];
  for (const m of msgs) {
    if (m.role === 'system') {
      out.unshift({ role: 'user', parts: [{ text: '[SYSTEM INSTRUCTIONS]\n' + m.content }] });
    } else {
      out.push({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] });
    }
  }
  const merged: GeminiMsg[] = [];
  for (const turn of out) {
    const prev = merged[merged.length - 1];
    if (prev && prev.role === turn.role) {
      prev.parts.push(...turn.parts);
    } else {
      merged.push({ ...turn, parts: [...turn.parts] });
    }
  }
  return merged;
}

// Extract Anthropic-style {system, messages[]} from OpenAI messages
function toAnthropicMessages(msgs: OpenAIMsg[]): {
  system: string | undefined;
  messages: { role: 'user' | 'assistant'; content: string }[];
} {
  const systemParts = msgs.filter(m => m.role === 'system').map(m => m.content);
  const thread = msgs
    .filter(m => m.role !== 'system')
    .map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }));
  return {
    system: systemParts.length ? systemParts.join('\n\n') : undefined,
    messages: thread,
  };
}

// Stream Anthropic SSE → OpenAI-format SSE (for frontend parser compatibility)
function anthropicToOpenAISseStream(upstream: Response, model: string): Response {
  const encoder = new TextEncoder();
  const reader  = upstream.body!.getReader();
  const decoder = new TextDecoder();

  const stream = new ReadableStream({
    async start(controller) {
      let buf = '';
      let eventType = '';
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += decoder.decode(value, { stream: true });
          const lines = buf.split('\n');
          buf = lines.pop() ?? '';
          for (const line of lines) {
            if (line.startsWith('event: ')) {
              eventType = line.slice(7).trim();
            } else if (line.startsWith('data: ')) {
              const raw = line.slice(6).trim();
              if (eventType === 'content_block_delta') {
                try {
                  const parsed = JSON.parse(raw);
                  const text: string = parsed?.delta?.text ?? '';
                  if (text) {
                    const chunk = { choices: [{ delta: { content: text }, finish_reason: null }] };
                    controller.enqueue(encoder.encode(`data: ${JSON.stringify(chunk)}\n\n`));
                  }
                } catch { /* malformed frame — skip */ }
              } else if (eventType === 'message_stop') {
                controller.enqueue(encoder.encode('data: [DONE]\n\n'));
              }
              if (line !== '') eventType = '';
            }
          }
        }
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
      'X-Model-Used': model,
      ...CORS,
    },
  });
}

// Mock SSE fallback — emits Gemini-format frames
function buildMockHtml(userPrompt: string): string {
  const title = userPrompt.slice(0, 60).replace(/[<>"]/g, '') || 'My Website';
  const year  = new Date().getFullYear();
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title}</title>
<style>
:root{--primary:#7c3aed;--primary-hover:#6d28d9;--bg:#0f0f13;--bg-card:#1a1a24;--text:#f1f1f3;--text-muted:#9ca3af;--border:rgba(255,255,255,0.08);--radius:12px}
*{box-sizing:border-box;margin:0;padding:0}html{scroll-behavior:smooth}
body{background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;line-height:1.6}
nav{position:sticky;top:0;z-index:100;display:flex;align-items:center;justify-content:space-between;padding:1rem 2rem;background:rgba(15,15,19,.85);backdrop-filter:blur(12px);border-bottom:1px solid var(--border)}
.nav-logo{font-weight:700;font-size:1.2rem;color:var(--primary)}
.nav-links{display:flex;gap:2rem}.nav-links a{color:var(--text-muted);font-size:.9rem;transition:color .2s;text-decoration:none}.nav-links a:hover{color:var(--text)}
.nav-cta{background:var(--primary);color:#fff;border:none;padding:.5rem 1.2rem;border-radius:8px;cursor:pointer;font-size:.9rem;transition:background .2s}.nav-cta:hover{background:var(--primary-hover)}
.hero{min-height:80vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:4rem 2rem;background:radial-gradient(ellipse 80% 50% at 50% -20%,rgba(124,58,237,.25),transparent)}
.hero-badge{display:inline-block;background:rgba(124,58,237,.15);color:var(--primary);border:1px solid rgba(124,58,237,.3);border-radius:99px;padding:.3rem 1rem;font-size:.8rem;margin-bottom:1.5rem}
.hero h1{font-size:clamp(2.2rem,6vw,4rem);font-weight:800;line-height:1.15;margin-bottom:1.2rem;background:linear-gradient(135deg,#fff 0%,#c4b5fd 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero p{font-size:1.1rem;color:var(--text-muted);max-width:540px;margin:0 auto 2.5rem}
.hero-btns{display:flex;gap:1rem;justify-content:center;flex-wrap:wrap}
.btn-primary{background:var(--primary);color:#fff;border:none;padding:.8rem 2rem;border-radius:10px;font-size:1rem;cursor:pointer;transition:background .2s,transform .2s}.btn-primary:hover{background:var(--primary-hover);transform:translateY(-2px)}
.btn-outline{background:transparent;color:var(--text);border:1px solid var(--border);padding:.8rem 2rem;border-radius:10px;font-size:1rem;cursor:pointer;transition:border-color .2s}.btn-outline:hover{border-color:var(--primary)}
section{padding:5rem 2rem}.container{max-width:1100px;margin:0 auto}
.section-title{text-align:center;font-size:clamp(1.6rem,3vw,2.4rem);font-weight:700;margin-bottom:.75rem}
.section-sub{text-align:center;color:var(--text-muted);margin-bottom:3rem}
.grid-3{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1.5rem}
.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:1.8rem;transition:transform .2s,border-color .2s}.card:hover{transform:translateY(-4px);border-color:rgba(124,58,237,.3)}
.card-icon{font-size:2rem;margin-bottom:1rem}.card h3{font-size:1.1rem;font-weight:600;margin-bottom:.5rem}.card p{color:var(--text-muted);font-size:.9rem}
.cta-section{background:linear-gradient(135deg,rgba(124,58,237,.2),rgba(109,40,217,.1));border:1px solid rgba(124,58,237,.2);border-radius:20px;text-align:center;padding:4rem 2rem;margin:2rem 0}
.cta-section h2{font-size:2rem;font-weight:700;margin-bottom:1rem}.cta-section p{color:var(--text-muted);margin-bottom:2rem}
footer{border-top:1px solid var(--border);padding:2rem;text-align:center;color:var(--text-muted);font-size:.85rem}
.reveal{opacity:0;transform:translateY(24px);transition:opacity .6s ease,transform .6s ease}.reveal.visible{opacity:1;transform:none}
@media(max-width:768px){nav{padding:1rem}.nav-links{display:none}.hero h1{font-size:2rem}}
</style>
</head>
<body>
<nav>
  <span class="nav-logo">SiteGenie - ${title}</span>
  <div class="nav-links"><a href="#features">Features</a><a href="#about">About</a><a href="#contact">Contact</a></div>
  <button class="nav-cta">Get Started</button>
</nav>
<div class="hero">
  <div class="container">
    <div class="hero-badge">Now available</div>
    <h1>${title}</h1>
    <p>A modern, production-ready website built with premium design, smooth animations, and responsive layout.</p>
    <div class="hero-btns">
      <button class="btn-primary">Get Started Free</button>
      <button class="btn-outline">Learn More</button>
    </div>
  </div>
</div>
<section id="features">
  <div class="container">
    <h2 class="section-title reveal">Powerful Features</h2>
    <p class="section-sub reveal">Everything you need to succeed, built right in.</p>
    <div class="grid-3">
      <div class="card reveal"><div class="card-icon">rocket</div><h3>Lightning Fast</h3><p>Optimized for performance with instant load times and smooth animations throughout.</p></div>
      <div class="card reveal"><div class="card-icon">art</div><h3>Premium Design</h3><p>Apple-quality UI with glassmorphism, gradients, and modern typography.</p></div>
      <div class="card reveal"><div class="card-icon">phone</div><h3>Fully Responsive</h3><p>Looks perfect on every device - desktop, tablet, and mobile.</p></div>
      <div class="card reveal"><div class="card-icon">lock</div><h3>Secure by Default</h3><p>Built with security best practices and accessibility standards baked in.</p></div>
      <div class="card reveal"><div class="card-icon">bolt</div><h3>Easy to Customize</h3><p>Clean modular code with CSS custom properties for effortless theming.</p></div>
      <div class="card reveal"><div class="card-icon">globe</div><h3>Production Ready</h3><p>Deploy anywhere - Vercel, Netlify, or any static host in seconds.</p></div>
    </div>
  </div>
</section>
<section id="contact">
  <div class="container">
    <div class="cta-section reveal">
      <h2>Ready to Get Started?</h2>
      <p>Join thousands of users building amazing websites today.</p>
      <button class="btn-primary">Start Building Free</button>
    </div>
  </div>
</section>
<footer><p>Copyright ${year} ${title}. Built with SiteGenie AI.</p></footer>
<script>
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.1});
document.querySelectorAll('.reveal').forEach(el=>obs.observe(el));
window.addEventListener('scroll',()=>{document.querySelector('nav').style.boxShadow=window.scrollY>50?'0 4px 24px rgba(0,0,0,.4)':'none'});
</script>
</body>
</html>`;
}

function mockSseStream(userPrompt: string): Response {
  const html = buildMockHtml(userPrompt);
  const encoder = new TextEncoder();
  const chunkSize = 150;

  const stream = new ReadableStream({
    async start(controller) {
      for (let i = 0; i < html.length; i += chunkSize) {
        const chunk = html.slice(i, i + chunkSize);
        controller.enqueue(encoder.encode(
          'data: ' + JSON.stringify({ candidates: [{ content: { parts: [{ text: chunk }] }, finishReason: null }] }) + '\n\n'
        ));
        await new Promise(r => setTimeout(r, 6));
      }
      controller.enqueue(encoder.encode(
        'data: ' + JSON.stringify({ candidates: [{ content: { parts: [{ text: '' }] }, finishReason: 'STOP' }] }) + '\n\n'
      ));
      controller.enqueue(encoder.encode('data: [DONE]\n\n'));
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
      'X-Model-Used': 'mock/sitegenie-fallback',
      'X-Mock-Response': 'true',
      ...CORS,
    },
  });
}

// Main Handler
Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  if (req.method !== 'POST') return jsonResp({ error: 'Method Not Allowed' }, 405);

  let rawBody: Record<string, unknown>;
  try { rawBody = await req.json(); }
  catch { return jsonResp({ error: 'Invalid request body' }, 400); }

  // Razorpay action routing
  if (rawBody.razorpay_action) {
    const action         = rawBody.razorpay_action as string;
    const supabaseUrl    = Deno.env.get('SUPABASE_URL')!;
    const serviceKey     = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const anonKey        = Deno.env.get('SUPABASE_ANON_KEY')!;
    const razorpayKeyId  = Deno.env.get('RAZORPAY_KEY_ID')!;
    const razorpaySecret = Deno.env.get('RAZORPAY_KEY_SECRET')!;

    const authHeader = req.headers.get('Authorization') ?? req.headers.get('authorization');
    if (!authHeader) return jsonResp({ error: 'Missing authorization header' }, 401);

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: authErr } = await userClient.auth.getUser();
    if (authErr || !user) return jsonResp({ error: 'Unauthorized' }, 401);

    const svc = createClient(supabaseUrl, serviceKey);

    if (action === 'create-order') {
      const plan = RAZORPAY_PLANS[rawBody.plan as string];
      if (!plan) return jsonResp({ error: 'Invalid plan' }, 400);
      const creds = btoa(`${razorpayKeyId}:${razorpaySecret}`);
      const orderRes = await fetch('https://api.razorpay.com/v1/orders', {
        method: 'POST',
        headers: { Authorization: `Basic ${creds}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: plan.amountPaise, currency: 'INR',
          receipt: `sg_${user.id.slice(0, 8)}_${Date.now()}`,
          notes: { user_id: user.id, plan: rawBody.plan, credits: String(plan.credits) },
        }),
      });
      if (!orderRes.ok) return jsonResp({ error: `Razorpay: ${await orderRes.text()}` }, 502);
      const order = await orderRes.json();
      return jsonResp({
        order_id: order.id, amount: order.amount,
        currency: order.currency, key_id: razorpayKeyId, plan_name: plan.name,
      });
    }

    if (action === 'verify-payment') {
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature, plan } =
        rawBody as Record<string, string>;
      if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !plan)
        return jsonResp({ error: 'Missing fields' }, 400);

      const expectedSig = await hmacSha256Hex(
        razorpaySecret, `${razorpay_order_id}|${razorpay_payment_id}`,
      );
      if (expectedSig !== razorpay_signature)
        return jsonResp({ error: 'Signature mismatch' }, 400);

      const { data: existing } = await svc.from('credit_transactions')
        .select('id').eq('razorpay_payment_id', razorpay_payment_id).maybeSingle();
      if (existing) return jsonResp({ error: 'Payment already processed' }, 409);

      const planInfo = RAZORPAY_PLANS[plan];
      if (!planInfo) return jsonResp({ error: 'Invalid plan' }, 400);

      const { data: profile } = await svc.from('profiles')
        .select('credits').eq('id', user.id).maybeSingle();
      if (!profile) return jsonResp({ error: 'Profile not found' }, 404);

      const newCredits = (profile.credits ?? 0) + planInfo.credits;
      await Promise.all([
        svc.from('profiles').update({ credits: newCredits }).eq('id', user.id),
        svc.from('credit_transactions').insert({
          user_id: user.id, type: 'topup', amount: planInfo.credits,
          description: planInfo.name, razorpay_payment_id, razorpay_order_id,
        }),
      ]);
      return jsonResp({ success: true, credits_added: planInfo.credits, total_credits: newCredits });
    }

    if (action === 'deduct-credits') {
      const { data: profile } = await svc.from('profiles')
        .select('credits').eq('id', user.id).maybeSingle();
      if (!profile) return jsonResp({ error: 'Profile not found' }, 404);
      const current = profile.credits ?? 0;
      if (current < DEDUCTION_COST)
        return jsonResp({ error: 'Insufficient credits', credits: current }, 402);
      const newCredits = current - DEDUCTION_COST;
      await Promise.all([
        svc.from('profiles').update({ credits: newCredits }).eq('id', user.id),
        svc.from('credit_transactions').insert({
          user_id: user.id, type: 'deduction', amount: DEDUCTION_COST,
          description: 'Website generation (-30 credits)',
        }),
      ]);
      return jsonResp({ success: true, credits_deducted: DEDUCTION_COST, remaining_credits: newCredits });
    }

    return jsonResp({ error: `Unknown razorpay_action: ${action}` }, 400);
  }

  // LLM path — model chain: Gemini 2.5 Flash → Claude 3.5 Haiku → GPT-4o-mini → platform gateway → mock
  let messages: OpenAIMsg[];
  try {
    if (Array.isArray(rawBody.messages) && (rawBody.messages as unknown[]).length > 0) {
      messages = rawBody.messages as OpenAIMsg[];
    } else if (Array.isArray(rawBody.contents) && (rawBody.contents as unknown[]).length > 0) {
      messages = (rawBody.contents as { role: string; parts: { text: string }[] }[]).map((t) => ({
        role: (t.role === 'model' ? 'assistant' : t.role) as OpenAIMsg['role'],
        content: t.parts.map((p) => p.text).join(''),
      }));
    } else {
      throw new Error('Missing messages or contents');
    }
  } catch {
    return jsonResp({ error: 'Invalid request body' }, 400);
  }

  const systemMsg = messages.find(m => m.role === 'system');
  const recent    = messages.filter(m => m.role !== 'system').slice(-5);
  const safe      = compressMessages(systemMsg ? [systemMsg, ...recent] : recent);
  const userMsg   = safe.filter(m => m.role === 'user').pop()?.content ?? '';

  // ── 1. Google Gemini 2.5 Flash (direct API) ───────────────────────────────
  const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
  if (GEMINI_API_KEY) {
    try {
      const resp = await fetch(GEMINI_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY },
        body: JSON.stringify({ contents: toGeminiContents(safe) }),
        signal: AbortSignal.timeout(120_000),
      });
      if (resp.status === 429 || resp.status === 402) {
        return new Response(await resp.text(), {
          status: resp.status,
          headers: { 'Content-Type': 'application/json', ...CORS },
        });
      }
      if (resp.ok && resp.body) {
        console.log('Serving via google/gemini-2.5-flash (direct)');
        return new Response(resp.body, {
          headers: {
            'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache',
            'X-Content-Type-Options': 'nosniff', 'X-Model-Used': 'google/gemini-2.5-flash', ...CORS,
          },
        });
      }
      console.warn('Gemini direct error:', resp.status, await resp.text().catch(() => ''));
    } catch (e) {
      console.warn('Gemini direct fetch failed:', e instanceof Error ? e.message : e);
    }
  }

  // ── 2. Anthropic Claude 3.5 Haiku ─────────────────────────────────────────
  const ANTHROPIC_API_KEY = Deno.env.get('ANTHROPIC_API_KEY');
  if (ANTHROPIC_API_KEY) {
    try {
      const { system, messages: threadMsgs } = toAnthropicMessages(safe);
      const body: Record<string, unknown> = {
        model: 'claude-3-5-haiku-20241022',
        max_tokens: 8192,
        stream: true,
        messages: threadMsgs,
      };
      if (system) body.system = system;
      const resp = await fetch(ANTHROPIC_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(120_000),
      });
      if (resp.status === 429 || resp.status === 402) {
        return new Response(await resp.text(), {
          status: resp.status,
          headers: { 'Content-Type': 'application/json', ...CORS },
        });
      }
      if (resp.ok && resp.body) {
        console.log('Serving via anthropic/claude-3-5-haiku');
        return anthropicToOpenAISseStream(resp, 'anthropic/claude-3-5-haiku');
      }
      console.warn('Anthropic error:', resp.status, await resp.text().catch(() => ''));
    } catch (e) {
      console.warn('Anthropic fetch failed:', e instanceof Error ? e.message : e);
    }
  }

  // ── 3. OpenAI GPT-4o-mini ─────────────────────────────────────────────────
  const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
  if (OPENAI_API_KEY) {
    try {
      const resp = await fetch(OPENAI_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
        },
        body: JSON.stringify({ model: 'gpt-4o-mini', stream: true, messages: safe }),
        signal: AbortSignal.timeout(120_000),
      });
      if (resp.status === 429 || resp.status === 402) {
        return new Response(await resp.text(), {
          status: resp.status,
          headers: { 'Content-Type': 'application/json', ...CORS },
        });
      }
      if (resp.ok && resp.body) {
        console.log('Serving via openai/gpt-4o-mini');
        return new Response(resp.body, {
          headers: {
            'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache',
            'X-Content-Type-Options': 'nosniff', 'X-Model-Used': 'openai/gpt-4o-mini', ...CORS,
          },
        });
      }
      console.warn('OpenAI error:', resp.status, await resp.text().catch(() => ''));
    } catch (e) {
      console.warn('OpenAI fetch failed:', e instanceof Error ? e.message : e);
    }
  }

  // ── 4. Platform Gemini gateway ────────────────────────────────────────────
  const INTEGRATIONS_API_KEY = Deno.env.get('INTEGRATIONS_API_KEY');
  if (INTEGRATIONS_API_KEY) {
    try {
      const resp = await fetch(GEMINI_GATEWAY_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${INTEGRATIONS_API_KEY}`,
        },
        body: JSON.stringify({ contents: toGeminiContents(safe) }),
        signal: AbortSignal.timeout(120_000),
      });
      if (resp.ok && resp.body) {
        console.log('Serving via platform Gemini gateway');
        return new Response(resp.body, {
          headers: {
            'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache',
            'X-Content-Type-Options': 'nosniff', 'X-Model-Used': 'google/gemini-2.5-flash', ...CORS,
          },
        });
      }
    } catch (e) {
      console.warn('Platform gateway failed:', e instanceof Error ? e.message : e);
    }
  }

  // ── 5. Mock fallback ──────────────────────────────────────────────────────
  console.warn('All LLM providers failed — serving mock response');
  return mockSseStream(userMsg);
});
