-- RPC: add credits after Razorpay payment (idempotent by payment_id)
CREATE OR REPLACE FUNCTION public.add_credits_after_payment(
  p_user_id           uuid,
  p_credits           integer,
  p_plan_name         text,
  p_razorpay_payment_id text,
  p_razorpay_order_id   text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_existing_id uuid;
  v_new_credits integer;
BEGIN
  -- Must be called by the authenticated user themselves
  IF auth.uid() != p_user_id THEN
    RETURN jsonb_build_object('success', false, 'error', 'Unauthorized');
  END IF;

  -- Idempotency: reject duplicate payment_id
  SELECT id INTO v_existing_id
    FROM credit_transactions
   WHERE razorpay_payment_id = p_razorpay_payment_id
   LIMIT 1;
  IF v_existing_id IS NOT NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Payment already processed');
  END IF;

  -- Update credits
  UPDATE profiles
     SET credits = credits + p_credits
   WHERE id = p_user_id
   RETURNING credits INTO v_new_credits;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Profile not found');
  END IF;

  -- Log the transaction
  INSERT INTO credit_transactions(user_id, type, amount, description, razorpay_payment_id, razorpay_order_id)
  VALUES (p_user_id, 'topup', p_credits, p_plan_name, p_razorpay_payment_id, p_razorpay_order_id);

  RETURN jsonb_build_object('success', true, 'total_credits', v_new_credits);
END;
$$;

-- RPC: deduct 30 credits per generation
CREATE OR REPLACE FUNCTION public.deduct_generation_credits(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_current  integer;
  v_new      integer;
BEGIN
  IF auth.uid() != p_user_id THEN
    RETURN jsonb_build_object('success', false, 'error', 'Unauthorized');
  END IF;

  SELECT credits INTO v_current FROM profiles WHERE id = p_user_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Profile not found');
  END IF;

  IF v_current < 30 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Insufficient credits', 'credits', v_current);
  END IF;

  v_new := v_current - 30;
  UPDATE profiles SET credits = v_new WHERE id = p_user_id;

  INSERT INTO credit_transactions(user_id, type, amount, description)
  VALUES (p_user_id, 'deduction', 30, 'Website generation (-30 credits)');

  RETURN jsonb_build_object('success', true, 'remaining_credits', v_new);
END;
$$;

-- RPC: fetch current credits (read-only)
CREATE OR REPLACE FUNCTION public.get_my_credits()
RETURNS integer
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT COALESCE(credits, 0) FROM profiles WHERE id = auth.uid();
$$;

GRANT EXECUTE ON FUNCTION public.add_credits_after_payment TO authenticated;
GRANT EXECUTE ON FUNCTION public.deduct_generation_credits TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_my_credits TO authenticated;