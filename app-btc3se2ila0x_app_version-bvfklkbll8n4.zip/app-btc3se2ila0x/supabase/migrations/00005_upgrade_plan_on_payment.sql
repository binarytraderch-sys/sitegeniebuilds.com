
CREATE OR REPLACE FUNCTION add_credits_after_payment(
  p_user_id             uuid,
  p_credits             integer,
  p_plan_name           text,
  p_razorpay_payment_id text,
  p_razorpay_order_id   text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_existing_id uuid;
  v_new_credits  integer;
  v_new_plan     subscription_plan;
BEGIN
  -- Must be called by the authenticated user themselves
  IF auth.uid() != p_user_id THEN
    RETURN jsonb_build_object('success', false, 'error', 'Unauthorized');
  END IF;

  -- Idempotency: reject duplicate payment_id
  SELECT id INTO v_existing_id
    FROM credit_transactions
   WHERE razorpay_payment_id = p_razorpay_payment_id
   LIMIT 1;
  IF v_existing_id IS NOT NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Payment already processed');
  END IF;

  -- Derive plan tier from credits purchased
  -- enterprise >= 10000 credits, pro = everything else paid
  IF p_credits >= 10000 THEN
    v_new_plan := 'enterprise'::subscription_plan;
  ELSE
    v_new_plan := 'pro'::subscription_plan;
  END IF;

  -- Update credits AND plan (never downgrade from enterprise)
  UPDATE profiles
     SET credits = credits + p_credits,
         plan    = CASE
                     WHEN plan = 'enterprise'::subscription_plan THEN 'enterprise'::subscription_plan
                     ELSE v_new_plan
                   END
   WHERE id = p_user_id
   RETURNING credits INTO v_new_credits;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Profile not found');
  END IF;

  -- Log the transaction
  INSERT INTO credit_transactions(user_id, type, amount, description, razorpay_payment_id, razorpay_order_id)
  VALUES (p_user_id, 'topup', p_credits, p_plan_name, p_razorpay_payment_id, p_razorpay_order_id);

  RETURN jsonb_build_object('success', true, 'total_credits', v_new_credits);
END;
$$;
