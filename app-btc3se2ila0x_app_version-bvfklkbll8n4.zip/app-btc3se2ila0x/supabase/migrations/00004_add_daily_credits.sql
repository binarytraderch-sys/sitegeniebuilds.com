-- Track when user last claimed daily credits
ALTER TABLE public.profiles
  ADD COLUMN last_daily_credit_at timestamptz DEFAULT NULL;

-- RPC: claim 30 free daily credits (once per UTC day, idempotent)
CREATE OR REPLACE FUNCTION public.claim_daily_credits()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id    uuid := auth.uid();
  v_last_claim timestamptz;
  v_new_credits integer;
BEGIN
  IF v_user_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Not authenticated');
  END IF;

  SELECT last_daily_credit_at INTO v_last_claim
    FROM profiles WHERE id = v_user_id;

  -- Already claimed today (UTC day)
  IF v_last_claim IS NOT NULL AND
     date_trunc('day', v_last_claim AT TIME ZONE 'UTC') =
     date_trunc('day', now() AT TIME ZONE 'UTC') THEN
    RETURN jsonb_build_object('success', false, 'already_claimed', true,
      'next_claim_at', (date_trunc('day', now() AT TIME ZONE 'UTC') + interval '1 day'));
  END IF;

  -- Add 30 credits and update claim timestamp
  UPDATE profiles
     SET credits = credits + 30,
         last_daily_credit_at = now()
   WHERE id = v_user_id
   RETURNING credits INTO v_new_credits;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Profile not found');
  END IF;

  -- Log transaction
  INSERT INTO credit_transactions(user_id, type, amount, description)
  VALUES (v_user_id, 'topup', 30, 'Daily free credits (+30)');

  RETURN jsonb_build_object('success', true, 'credits_added', 30, 'total_credits', v_new_credits);
END;
$$;

GRANT EXECUTE ON FUNCTION public.claim_daily_credits TO authenticated;