-- Add credits column to profiles
ALTER TABLE public.profiles ADD COLUMN credits integer NOT NULL DEFAULT 0;

-- Table to log all credit transactions (top-ups & deductions)
CREATE TABLE public.credit_transactions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type          text NOT NULL CHECK (type IN ('topup', 'deduction')),
  amount        integer NOT NULL,
  description   text,
  razorpay_payment_id text,
  razorpay_order_id   text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- RLS: users can only see their own transactions
ALTER TABLE public.credit_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users_read_own_transactions" ON public.credit_transactions
  FOR SELECT TO authenticated USING (user_id = auth.uid());

-- Helper: service-role can insert transactions
CREATE POLICY "service_insert_transactions" ON public.credit_transactions
  FOR INSERT TO service_role WITH CHECK (true);

-- Helper: service-role can update profiles credits
CREATE POLICY "service_update_credits" ON public.profiles
  FOR UPDATE TO service_role USING (true) WITH CHECK (true);