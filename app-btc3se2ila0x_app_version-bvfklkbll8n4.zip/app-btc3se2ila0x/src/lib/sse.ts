// Pure-fetch SSE client — no ky, no eventsource-parser.
// Ky's afterResponse hook consumes the body before ky finishes, causing
// "body already used" errors. Native fetch + manual line parsing avoids this.

export interface StreamRequestOptions {
  functionUrl: string;
  requestBody: unknown;
  supabaseAnonKey: string;
  onData: (data: string) => void;
  onComplete: () => void;
  onError: (error: Error) => void;
  signal?: AbortSignal;
}

/**
 * POST to a Supabase Edge Function that returns an SSE stream,
 * read each `data:` line and call onData per frame.
 * First-token latency can be up to 30 s — no timeout imposed here.
 */
export async function sendStreamRequest(options: StreamRequestOptions): Promise<void> {
  const { functionUrl, requestBody, supabaseAnonKey, onData, onComplete, onError, signal } = options;

  let response: Response;
  try {
    response = await fetch(functionUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseAnonKey}`,
        'apikey': supabaseAnonKey,
      },
      body: JSON.stringify(requestBody),
      signal,
    });
  } catch (err: unknown) {
    if (signal?.aborted) return;
    onError(err instanceof Error ? err : new Error(String(err)));
    return;
  }

  // Surface HTTP-level errors (429 quota, 402 balance, 5xx, etc.)
  if (!response.ok) {
    let detail = `HTTP ${response.status}`;
    try {
      const body = await response.text();
      const parsed = JSON.parse(body);
      // Handle both flat { error: "..." } and nested { error: { message: "..." } }
      const errField = parsed?.error;
      detail = (typeof errField === 'string' ? errField : errField?.message)
        ?? parsed?.message
        ?? body
        ?? detail;
    } catch { /* ignore parse errors */ }
    onError(new Error(detail));
    return;
  }

  if (!response.body) {
    onError(new Error('No response body from Edge Function'));
    return;
  }

  // Read the SSE stream line-by-line
  const reader  = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer    = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? ''; // keep the last incomplete line

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        const data = trimmed.slice(5).trim();
        if (!data || data === '[DONE]') continue;
        onData(data);
      }
    }
    // Flush any remaining buffer
    if (buffer.trim().startsWith('data:')) {
      const data = buffer.trim().slice(5).trim();
      if (data && data !== '[DONE]') onData(data);
    }
    onComplete();
  } catch (err: unknown) {
    if (signal?.aborted) return; // user cancelled — not an error
    onError(err instanceof Error ? err : new Error(String(err)));
  }
}
