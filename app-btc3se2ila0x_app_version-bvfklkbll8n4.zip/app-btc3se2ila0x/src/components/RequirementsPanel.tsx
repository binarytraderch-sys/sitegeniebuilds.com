import React from 'react';
import { motion } from 'motion/react';
import { FileText, Pencil, Sparkles, CheckCircle2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface RequirementsPanelProps {
  content: string;
  isStreaming: boolean;
  isModify: boolean;
}

function inlineStyle(text: string): React.ReactNode {
  const parts: React.ReactNode[] = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    if (m[0].startsWith('**'))
      parts.push(<strong key={m.index} className="font-semibold text-foreground">{m[0].slice(2, -2)}</strong>);
    else
      parts.push(<code key={m.index} className="px-1 py-0.5 rounded bg-muted text-primary font-mono text-[11px]">{m[0].slice(1, -1)}</code>);
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts.length > 1 ? <>{parts}</> : (parts[0] ?? text);
}

function renderLine(line: string, idx: number): React.ReactNode {
  if (/^# /.test(line))
    return <h1 key={idx} className="text-lg font-bold text-foreground mt-5 mb-2 first:mt-0">{line.slice(2)}</h1>;
  if (/^## /.test(line))
    return <h2 key={idx} className="text-base font-semibold text-foreground mt-4 mb-1.5 border-b border-border pb-1">{line.slice(3)}</h2>;
  if (/^### /.test(line))
    return <h3 key={idx} className="text-sm font-semibold text-foreground mt-3 mb-1">{line.slice(4)}</h3>;
  if (/^[-*] /.test(line))
    return (
      <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground py-0.5 ml-2 list-none">
        <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-primary shrink-0" />
        <span>{inlineStyle(line.slice(2))}</span>
      </li>
    );
  if (/^\d+\. /.test(line)) {
    const num = line.match(/^(\d+)\. /)?.[1] ?? '';
    return (
      <li key={idx} className="flex items-start gap-2.5 text-sm text-muted-foreground py-0.5 ml-2 list-none">
        <span className="shrink-0 h-5 w-5 rounded-full bg-primary/10 text-primary text-[10px] font-bold flex items-center justify-center mt-0.5">{num}</span>
        <span>{inlineStyle(line.replace(/^\d+\. /, ''))}</span>
      </li>
    );
  }
  if (/^---/.test(line)) return <hr key={idx} className="border-border my-3" />;
  if (!line.trim()) return <div key={idx} className="h-1" />;
  if (/^\|/.test(line)) {
    const cells = line.split('|').filter((c) => c.trim() && !/^[-:]+$/.test(c.trim()));
    if (!cells.length) return null;
    return (
      <div key={idx} className="flex gap-2 text-xs font-mono text-muted-foreground bg-muted/30 px-2 py-1 rounded">
        {cells.map((c, i) => <span key={i} className="flex-1">{c.trim()}</span>)}
      </div>
    );
  }
  if (/^```/.test(line)) return null;
  return <p key={idx} className="text-sm text-muted-foreground leading-relaxed">{inlineStyle(line)}</p>;
}

const RequirementsPanel: React.FC<RequirementsPanelProps> = ({ content, isStreaming, isModify }) => {
  const lines = content.split('\n');
  return (
    <div className="flex-1 min-h-0 overflow-y-auto flex flex-col">
      <div className="sticky top-0 z-10 flex items-center gap-2 px-5 py-3 bg-card border-b border-border shrink-0">
        <div className="h-6 w-6 rounded-md bg-primary/10 flex items-center justify-center shrink-0">
          {isModify ? <Pencil className="h-3.5 w-3.5 text-primary" /> : <FileText className="h-3.5 w-3.5 text-primary" />}
        </div>
        <span className="text-sm font-semibold">{isModify ? 'Modification Plan' : 'Requirements Document'}</span>
        {isStreaming && (
          <Badge variant="secondary" className="ml-auto text-[10px] h-5 gap-1 animate-pulse">
            <Sparkles className="h-2.5 w-2.5" /> Generating…
          </Badge>
        )}
        {!isStreaming && content && (
          <Badge variant="outline" className="ml-auto text-[10px] h-5 gap-1 text-primary border-primary/30 bg-primary/5">
            <CheckCircle2 className="h-2.5 w-2.5" /> Ready
          </Badge>
        )}
      </div>
      <div className="px-5 py-4 flex-1">
        {content ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-0.5">
            {lines.map((line, i) => renderLine(line, i))}
            {isStreaming && (
              <motion.span
                animate={{ opacity: [1, 0] }}
                transition={{ duration: 0.6, repeat: Infinity, repeatType: 'reverse' }}
                className="inline-block ml-0.5 h-4 w-0.5 bg-primary align-middle"
              />
            )}
          </motion.div>
        ) : (
          <div className={cn('flex flex-col items-center justify-center gap-3 py-20 text-muted-foreground', isStreaming && 'animate-pulse')}>
            <div className="h-12 w-12 rounded-2xl border-2 border-dashed border-border flex items-center justify-center">
              <FileText className="h-5 w-5 opacity-30" />
            </div>
            <p className="text-sm font-medium">{isStreaming ? 'Analyzing your prompt…' : 'Requirements will appear here'}</p>
            <p className="text-xs opacity-50 text-center max-w-[220px]">
              {isStreaming ? 'Generating a structured requirements document…' : 'Submit a prompt to generate a requirements document before code generation'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default RequirementsPanel;
