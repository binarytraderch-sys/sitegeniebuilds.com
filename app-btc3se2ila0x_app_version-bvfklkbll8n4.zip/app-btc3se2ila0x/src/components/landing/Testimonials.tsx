import React, { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const testimonials = [
  {
    name: 'Sarah Chen',
    role: 'Founder at TechStart',
    avatar: 'SC',
    content:
      'SiteGenie transformed our startup\'s online presence. We went from idea to launch in under 2 hours. The AI understood exactly what we needed and delivered beyond expectations.',
    rating: 5,
  },
  {
    name: 'Marcus Johnson',
    role: 'Marketing Director at Bloom Co',
    avatar: 'MJ',
    content:
      'As a non-technical person, I was amazed at how easy it was to create a professional website. The AI-generated copy was spot-on and the design is stunning.',
    rating: 5,
  },
  {
    name: 'Emily Rodriguez',
    role: 'Freelance Designer',
    avatar: 'ER',
    content:
      'I use SiteGenie to rapidly prototype designs for clients. It saves me hours of work and the output quality is incredible. My clients love the speed and results.',
    rating: 5,
  },
  {
    name: 'David Park',
    role: 'CTO at DataFlow',
    avatar: 'DP',
    content:
      'The code export feature is a game-changer. We generate landing pages with SiteGenie and then customize the React code. Clean, well-structured, and production-ready.',
    rating: 5,
  },
  {
    name: 'Lisa Thompson',
    role: 'Small Business Owner',
    avatar: 'LT',
    content:
      'I spent months trying to build a website with other tools. With SiteGenie, I described my bakery and had a beautiful site running the same day. Absolutely magical.',
    rating: 5,
  },
];

const Testimonials: React.FC = () => {
  const [current, setCurrent] = useState(0);

  const next = useCallback(() => {
    setCurrent((prev) => (prev + 1) % testimonials.length);
  }, []);

  const prev = useCallback(() => {
    setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  }, []);

  useEffect(() => {
    const timer = setInterval(next, 6000);
    return () => clearInterval(timer);
  }, [next]);

  const testimonial = testimonials[current];

  return (
    <section className="py-20 md:py-28" id="testimonials">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">
            Loved by <span className="gradient-text">Builders</span> Worldwide
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Join thousands of creators, founders, and businesses who trust SiteGenie for their websites.
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          <div className="relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, x: 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -40 }}
                transition={{ duration: 0.4 }}
                className="text-center"
              >
                <div className="flex items-center justify-center gap-1 mb-6">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-warning text-warning" />
                  ))}
                </div>

                <blockquote className="text-xl md:text-2xl font-medium leading-relaxed text-pretty mb-8">
                  &ldquo;{testimonial.content}&rdquo;
                </blockquote>

                <div className="flex items-center justify-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-semibold">
                    {testimonial.avatar}
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-semibold">{testimonial.name}</div>
                    <div className="text-xs text-muted-foreground">{testimonial.role}</div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="flex items-center justify-center gap-4 mt-10">
            <Button
              variant="outline"
              size="icon"
              onClick={prev}
              className="rounded-full"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>

            <div className="flex items-center gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrent(index)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    index === current
                      ? 'w-6 bg-primary'
                      : 'w-2 bg-muted-foreground/30 hover:bg-muted-foreground/50'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>

            <Button
              variant="outline"
              size="icon"
              onClick={next}
              className="rounded-full"
              aria-label="Next testimonial"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;