import React from 'react';
import { motion } from 'motion/react';
import {
  Wand2,
  Palette,
  Smartphone,
  Zap,
  Globe,
  Lock,
  BarChart3,
  Code2,
} from 'lucide-react';

const features = [
  {
    icon: Wand2,
    title: 'AI-Powered Design',
    description:
      'Our advanced AI analyzes your requirements and creates custom designs that match your brand identity perfectly.',
  },
  {
    icon: Palette,
    title: 'Smart Theming',
    description:
      'Automatically generates cohesive color palettes, typography, and visual styles that work together harmoniously.',
  },
  {
    icon: Smartphone,
    title: 'Fully Responsive',
    description:
      'Every website is built mobile-first and looks stunning on every device, from phones to ultra-wide monitors.',
  },
  {
    icon: Zap,
    title: 'Lightning Fast',
    description:
      'Optimized code and assets ensure your website loads instantly, improving user experience and SEO rankings.',
  },
  {
    icon: Globe,
    title: 'SEO Optimized',
    description:
      'Built-in SEO best practices including structured data, meta tags, and semantic HTML for better search visibility.',
  },
  {
    icon: Lock,
    title: 'Enterprise Security',
    description:
      'HTTPS by default, secure authentication, and regular security updates keep your website and users protected.',
  },
  {
    icon: BarChart3,
    title: 'Analytics Ready',
    description:
      'Integrated analytics dashboard helps you track visitors, engagement, and conversions in real-time.',
  },
  {
    icon: Code2,
    title: 'Clean Code Export',
    description:
      'Export production-ready source code in React, Next.js, or plain HTML for complete developer flexibility.',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4 },
  },
};

const Features: React.FC = () => {
  return (
    <section className="py-20 md:py-28 bg-muted/30" id="features">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">
            Everything You <span className="gradient-text">Need</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Powerful features that make website building effortless. From AI design to deployment, we have you covered.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {features.map((feature) => (
            <motion.div
              key={feature.title}
              variants={itemVariants}
              className="group h-full flex flex-col p-6 rounded-2xl border border-border bg-card hover:border-primary/30 hover:shadow-lg transition-all duration-300"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 mb-4 group-hover:bg-primary/20 transition-colors">
                <feature.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="text-base font-semibold mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground text-pretty leading-relaxed flex-1">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Features;