import React from 'react';
import { motion } from 'motion/react';
import { Check, ArrowRight, Layers, Type, Image, MousePointer } from 'lucide-react';
import { Button } from '@/components/ui/button';

const capabilities = [
  { icon: Layers, label: 'Auto Layout' },
  { icon: Type, label: 'AI Copywriting' },
  { icon: Image, label: 'Smart Images' },
  { icon: MousePointer, label: 'Interactive' },
];

const DemoSection: React.FC = () => {
  return (
    <section className="py-20 md:py-28" id="demo">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">
            See the <span className="gradient-text">Magic</span> in Action
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Watch how our AI transforms a simple description into a fully functional, beautiful website.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center"
        >
          <div className="order-2 lg:order-1 space-y-8">
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 mt-0.5">
                  <Check className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-1">Describe in Natural Language</h3>
                  <p className="text-sm text-muted-foreground text-pretty">
                    Simply type what you want: "A modern SaaS landing page with pricing, testimonials, and a hero section with purple gradients."
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 mt-0.5">
                  <Check className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-1">AI Analyzes & Plans</h3>
                  <p className="text-sm text-muted-foreground text-pretty">
                    Our agent breaks down your request, selects the best components, and creates a design strategy tailored to your goals.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 mt-0.5">
                  <Check className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-1">Instant Generation</h3>
                  <p className="text-sm text-muted-foreground text-pretty">
                    Within seconds, a complete website is generated with real copy, curated images, and polished interactions.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              {capabilities.map((cap) => (
                <div
                  key={cap.label}
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm"
                >
                  <cap.icon className="h-4 w-4 text-primary" />
                  <span>{cap.label}</span>
                </div>
              ))}
            </div>

            <Button className="bg-primary hover:bg-primary/90" type="button" onClick={() => {}}>
              Try Live Demo
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>

          <div className="order-1 lg:order-2">
            <div className="relative rounded-2xl border border-border bg-card overflow-hidden shadow-xl">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-info/5 pointer-events-none" />
              <div className="p-6 md:p-8">
                <div className="flex items-center gap-2 mb-6 pb-4 border-b border-border">
                  <div className="h-3 w-3 rounded-full bg-destructive" />
                  <div className="h-3 w-3 rounded-full bg-warning" />
                  <div className="h-3 w-3 rounded-full bg-success" />
                  <div className="ml-4 h-6 flex-1 rounded-md bg-muted flex items-center px-3">
                    <span className="text-xs text-muted-foreground truncate">
                      sitegenie.ai/preview/landing-page
                    </span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="rounded-xl bg-gradient-to-r from-primary/20 to-info/20 p-6">
                    <div className="h-4 w-32 rounded bg-primary/30 mb-3" />
                    <div className="h-3 w-full rounded bg-white/20 mb-2" />
                    <div className="h-3 w-2/3 rounded bg-white/20" />
                    <div className="flex gap-2 mt-4">
                      <div className="h-8 w-24 rounded-lg bg-white/30" />
                      <div className="h-8 w-24 rounded-lg bg-white/10" />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="h-20 rounded-lg bg-muted space-y-2 p-3">
                      <div className="h-6 w-6 rounded bg-primary/20" />
                      <div className="h-2 w-full rounded bg-muted-foreground/20" />
                    </div>
                    <div className="h-20 rounded-lg bg-muted space-y-2 p-3">
                      <div className="h-6 w-6 rounded bg-info/20" />
                      <div className="h-2 w-full rounded bg-muted-foreground/20" />
                    </div>
                    <div className="h-20 rounded-lg bg-muted space-y-2 p-3">
                      <div className="h-6 w-6 rounded bg-success/20" />
                      <div className="h-2 w-full rounded bg-muted-foreground/20" />
                    </div>
                  </div>

                  <div className="rounded-xl bg-muted p-4 space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/20" />
                      <div className="flex-1 space-y-1.5">
                        <div className="h-2.5 w-24 rounded bg-muted-foreground/20" />
                        <div className="h-2 w-16 rounded bg-muted-foreground/10" />
                      </div>
                    </div>
                    <div className="h-2 w-full rounded bg-muted-foreground/10" />
                    <div className="h-2 w-5/6 rounded bg-muted-foreground/10" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default DemoSection;