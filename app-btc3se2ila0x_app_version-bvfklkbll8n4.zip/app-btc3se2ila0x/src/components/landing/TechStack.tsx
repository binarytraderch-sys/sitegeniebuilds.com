import React from 'react';
import { motion } from 'motion/react';

// ─── Tool definitions ─────────────────────────────────────────────────────────
interface Tool {
  name: string;
  purpose: string;
  href: string;
  /** Inline SVG path(s) for the logo mark */
  logo: React.ReactNode;
  color: string; // tailwind text color for the logo tint
}

// SVG logos built inline — no external images needed
const AnthropicLogo = () => (
  <svg viewBox="0 0 32 32" fill="currentColor" className="h-5 w-5">
    <path d="M18.1 4h-4.2L6 28h4.5l1.6-4.6h7.8L21.5 28H26L18.1 4zm-4.6 15.4 2.5-7.2 2.5 7.2h-5z" />
  </svg>
);

const GeminiLogo = () => (
  <svg viewBox="0 0 32 32" fill="none" className="h-5 w-5">
    <path d="M16 4C16 4 20.5 13 28 16C20.5 19 16 28 16 28C16 28 11.5 19 4 16C11.5 13 16 4 16 4Z"
      fill="currentColor" />
  </svg>
);

const OpenAILogo = () => (
  <svg viewBox="0 0 32 32" fill="currentColor" className="h-5 w-5">
    <path d="M27.5 13.1a7.5 7.5 0 0 0-.64-6.15 7.6 7.6 0 0 0-8.18-3.64A7.58 7.58 0 0 0 13 1.06a7.6 7.6 0 0 0-7.25 5.27 7.58 7.58 0 0 0-5.06 3.67 7.6 7.6 0 0 0 .94 8.93 7.56 7.56 0 0 0 .63 6.15 7.6 7.6 0 0 0 8.18 3.64A7.57 7.57 0 0 0 16 30.94a7.6 7.6 0 0 0 7.25-5.27 7.58 7.58 0 0 0 5.06-3.67 7.6 7.6 0 0 0-.81-8.9zm-11.5 16.1a5.63 5.63 0 0 1-3.62-1.31l.18-.1 6.01-3.47a1 1 0 0 0 .5-.86v-8.47l2.54 1.47a.09.09 0 0 1 .05.07v7.02a5.64 5.64 0 0 1-5.66 5.65zM4.18 23.94a5.62 5.62 0 0 1-.67-3.79l.18.11 6 3.47a.99.99 0 0 0 1 0l7.33-4.23v2.93a.09.09 0 0 1-.04.08L11.9 25.97a5.64 5.64 0 0 1-7.72-2.03zm-1.45-13.1a5.6 5.6 0 0 1 2.93-2.48v7.13a.99.99 0 0 0 .5.86l7.32 4.22-2.54 1.47a.1.1 0 0 1-.09.01L4.73 18.6a5.64 5.64 0 0 1-2-7.76zm20.88 4.84L16.29 11.4l2.54-1.46a.1.1 0 0 1 .09-.01l6.12 3.53a5.63 5.63 0 0 1-.87 10.16v-7.13a.99.99 0 0 0-.56-.9zm2.53-3.8-.18-.11-6-3.46a.99.99 0 0 0-1 0L11.64 12.6V9.67a.09.09 0 0 1 .04-.08L17.77 6.1a5.63 5.63 0 0 1 8.37 5.78zm-15.9 5.22L8.7 15.63a.09.09 0 0 1-.05-.07V8.54a5.63 5.63 0 0 1 9.24-4.32l-.18.1-6 3.47a1 1 0 0 0-.5.86v8.45l-2.47-1.14zm1.38-2.97 3.26-1.88 3.26 1.88v3.75l-3.26 1.88-3.26-1.88V14.13z" />
  </svg>
);

const OpenRouterLogo = () => (
  <svg viewBox="0 0 32 32" fill="currentColor" className="h-5 w-5">
    <circle cx="8" cy="16" r="3" />
    <circle cx="24" cy="8" r="3" />
    <circle cx="24" cy="24" r="3" />
    <path d="M11 16h6.5M17.5 16l-3-4M17.5 16l-3 4" stroke="currentColor" strokeWidth="1.8"
      fill="none" strokeLinecap="round" />
  </svg>
);

const E2BLogo = () => (
  <svg viewBox="0 0 32 32" fill="currentColor" className="h-5 w-5">
    <rect x="3" y="6" width="26" height="20" rx="3" fill="none" stroke="currentColor" strokeWidth="2" />
    <path d="M8 12l4 4-4 4M15 20h9" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round" fill="none" />
  </svg>
);

const WebContainerLogo = () => (
  <svg viewBox="0 0 32 32" fill="currentColor" className="h-5 w-5">
    <rect x="3" y="5" width="26" height="18" rx="2" fill="none" stroke="currentColor" strokeWidth="2" />
    <rect x="5" y="7" width="22" height="14" rx="1" fill="currentColor" opacity="0.15" />
    <path d="M11 23v4M21 23v4M7 27h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <circle cx="16" cy="14" r="4" fill="none" stroke="currentColor" strokeWidth="1.8" />
    <path d="M14 14h4M16 12v4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const LangGraphLogo = () => (
  <svg viewBox="0 0 32 32" fill="currentColor" className="h-5 w-5">
    <circle cx="16" cy="6" r="3" />
    <circle cx="6" cy="22" r="3" />
    <circle cx="26" cy="22" r="3" />
    <path d="M16 9v6M13.5 21L7.5 20M18.5 21l6-1" stroke="currentColor" strokeWidth="1.8"
      fill="none" strokeLinecap="round" />
    <circle cx="16" cy="16" r="3" />
  </svg>
);

const VercelLogo = () => (
  <svg viewBox="0 0 32 32" fill="currentColor" className="h-5 w-5">
    <path d="M16 4L29 26H3L16 4z" />
  </svg>
);

const TOOLS: Tool[] = [
  {
    name: 'Claude API',
    purpose: 'Main coding agent',
    href: 'https://www.anthropic.com/api',
    logo: <AnthropicLogo />,
    color: 'text-orange-400',
  },
  {
    name: 'Gemini API',
    purpose: 'Fast edits',
    href: 'https://ai.google.dev',
    logo: <GeminiLogo />,
    color: 'text-blue-400',
  },
  {
    name: 'OpenAI API',
    purpose: 'Reasoning & planning',
    href: 'https://platform.openai.com',
    logo: <OpenAILogo />,
    color: 'text-emerald-400',
  },
  {
    name: 'OpenRouter',
    purpose: 'Multi-model routing',
    href: 'https://openrouter.ai',
    logo: <OpenRouterLogo />,
    color: 'text-purple-400',
  },
  {
    name: 'E2B',
    purpose: 'Sandbox execution',
    href: 'https://e2b.dev',
    logo: <E2BLogo />,
    color: 'text-cyan-400',
  },
  {
    name: 'WebContainer',
    purpose: 'Browser container',
    href: 'https://webcontainers.io',
    logo: <WebContainerLogo />,
    color: 'text-sky-400',
  },
  {
    name: 'LangGraph',
    purpose: 'AI orchestration',
    href: 'https://www.langchain.com/langgraph',
    logo: <LangGraphLogo />,
    color: 'text-teal-400',
  },
  {
    name: 'Vercel AI SDK',
    purpose: 'Streaming UI',
    href: 'https://sdk.vercel.ai',
    logo: <VercelLogo />,
    color: 'text-foreground',
  },
];

// Duplicate the list so the marquee loops seamlessly
const MARQUEE_ITEMS = [...TOOLS, ...TOOLS];

// ─── Component ────────────────────────────────────────────────────────────────
const TechStack: React.FC = () => {
  return (
    <section className="py-16 md:py-20 border-y border-border bg-muted/20 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 md:px-6 mb-10 text-center">
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2"
        >
          Powered by industry-leading AI infrastructure
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.08 }}
          className="text-2xl md:text-3xl font-bold text-balance"
        >
          Built on the{' '}
          <span className="gradient-text">Best AI Stack</span>
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.14 }}
          className="mt-3 text-sm text-muted-foreground max-w-xl mx-auto text-pretty"
        >
          SiteGenie orchestrates the world's most powerful models and developer tools
          to plan, design, code, and ship your website automatically.
        </motion.p>
      </div>

      {/* ── Scrolling marquee ─────────────────────────────────────────────── */}
      <div className="relative w-full">
        {/* Fade masks */}
        <div className="pointer-events-none absolute left-0 top-0 h-full w-24 md:w-40 bg-gradient-to-r from-background to-transparent z-10" />
        <div className="pointer-events-none absolute right-0 top-0 h-full w-24 md:w-40 bg-gradient-to-l from-background to-transparent z-10" />

        <div className="flex overflow-hidden select-none">
          <motion.div
            className="flex gap-4 shrink-0"
            animate={{ x: ['0%', '-50%'] }}
            transition={{ duration: 28, ease: 'linear', repeat: Infinity }}
          >
            {MARQUEE_ITEMS.map((tool, i) => (
              <a
                key={`${tool.name}-${i}`}
                href={tool.href}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-3 shrink-0 rounded-xl border border-border bg-card px-5 py-3.5 shadow-sm hover:border-primary/40 hover:shadow-md transition-all duration-200 hover:-translate-y-0.5"
              >
                <span className={`${tool.color} transition-transform duration-200 group-hover:scale-110`}>
                  {tool.logo}
                </span>
                <div className="text-left">
                  <p className="text-sm font-semibold text-foreground whitespace-nowrap leading-tight">
                    {tool.name}
                  </p>
                  <p className="text-[11px] text-muted-foreground whitespace-nowrap leading-tight mt-0.5">
                    {tool.purpose}
                  </p>
                </div>
              </a>
            ))}
          </motion.div>
        </div>
      </div>

      {/* ── Static grid fallback / detail view on md+ ─────────────────────── */}
      <div className="mx-auto max-w-7xl px-4 md:px-6 mt-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {TOOLS.map((tool, i) => (
            <motion.a
              key={tool.name}
              href={tool.href}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className="group flex items-start gap-3 rounded-xl border border-border bg-card p-4 hover:border-primary/40 hover:shadow-md transition-all duration-200"
            >
              <div className={`mt-0.5 shrink-0 ${tool.color} transition-transform duration-200 group-hover:scale-110`}>
                {tool.logo}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{tool.name}</p>
                <p className="text-[11px] text-muted-foreground text-pretty mt-0.5 leading-tight">
                  {tool.purpose}
                </p>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TechStack;
