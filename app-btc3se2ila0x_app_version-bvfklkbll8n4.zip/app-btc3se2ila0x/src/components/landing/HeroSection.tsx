import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, Play, Zap, Shield, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

const trustIndicators = [
  { icon: Zap, label: 'Instant Generation' },
  { icon: Shield, label: 'Production Ready' },
  { icon: Users, label: '10K+ Users' },
];

const HeroSection: React.FC = () => {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 md:pt-40 md:pb-28">
      {/* Animated gradient blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 h-96 w-96 rounded-full bg-primary/20 blur-3xl animate-float" />
        <div className="absolute top-20 right-0 h-80 w-80 rounded-full bg-info/20 blur-3xl animate-float-delayed" />
        <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-primary/15 blur-3xl animate-pulse-glow" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 md:px-6">
        <div className="flex flex-col items-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 mb-8"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-success" />
            </span>
            <span className="text-sm text-muted-foreground">Now with AI Design v2.0</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight max-w-4xl text-balance"
          >
            Build Stunning Websites with{' '}
            <span className="gradient-text">AI Magic</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl text-pretty"
          >
            Describe your vision, and our AI agent generates a complete, production-ready website in minutes. No coding required.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-10 flex flex-col sm:flex-row items-center gap-4"
          >
            <Link to="/register">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-base px-8">
                Start Building Free
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Button variant="outline" size="lg" className="text-base px-8" type="button" onClick={() => {}}>
              <Play className="mr-2 h-4 w-4" />
              Watch Demo
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-10 flex items-center gap-6 md:gap-10"
          >
            {trustIndicators.map((item) => (
              <div key={item.label} className="flex items-center gap-2 text-sm text-muted-foreground">
                <item.icon className="h-4 w-4 text-primary" />
                <span>{item.label}</span>
              </div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-16 w-full max-w-5xl"
          >
            <div className="relative rounded-2xl border border-border bg-card/50 backdrop-blur-sm overflow-hidden shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
              <div className="p-6 md:p-10">
                <div className="flex items-center gap-2 mb-6">
                  <div className="h-3 w-3 rounded-full bg-destructive" />
                  <div className="h-3 w-3 rounded-full bg-warning" />
                  <div className="h-3 w-3 rounded-full bg-success" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="rounded-xl bg-muted/50 p-4 space-y-3">
                    <div className="h-3 w-20 rounded bg-primary/20" />
                    <div className="h-2 w-full rounded bg-muted" />
                    <div className="h-2 w-3/4 rounded bg-muted" />
                    <div className="h-24 rounded-lg bg-primary/10 mt-2" />
                  </div>
                  <div className="rounded-xl bg-muted/50 p-4 space-y-3">
                    <div className="h-3 w-24 rounded bg-primary/20" />
                    <div className="h-2 w-full rounded bg-muted" />
                    <div className="h-2 w-2/3 rounded bg-muted" />
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <div className="h-16 rounded-lg bg-accent" />
                      <div className="h-16 rounded-lg bg-accent" />
                    </div>
                  </div>
                  <div className="rounded-xl bg-muted/50 p-4 space-y-3">
                    <div className="h-3 w-16 rounded bg-primary/20" />
                    <div className="h-2 w-full rounded bg-muted" />
                    <div className="h-2 w-4/5 rounded bg-muted" />
                    <div className="h-24 rounded-lg bg-gradient-to-br from-primary/20 to-info/20 mt-2" />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;