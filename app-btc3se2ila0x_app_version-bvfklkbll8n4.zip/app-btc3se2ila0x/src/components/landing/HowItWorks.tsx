import React from 'react';
import { motion } from 'motion/react';
import { MessageSquare, Wand2, Rocket, ArrowRight } from 'lucide-react';

const steps = [
  {
    number: '01',
    icon: MessageSquare,
    title: 'Describe Your Vision',
    description:
      'Tell our AI agent what kind of website you want. Describe your brand, audience, and goals in natural language.',
  },
  {
    number: '02',
    icon: Wand2,
    title: 'AI Generates Everything',
    description:
      'Our AI crafts a complete website with custom design, copy, images, and functionality tailored to your needs.',
  },
  {
    number: '03',
    icon: Rocket,
    title: 'Launch in Minutes',
    description:
      'Review, customize, and publish your production-ready website with one click. No coding or design skills needed.',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

const HowItWorks: React.FC = () => {
  return (
    <section className="py-20 md:py-28" id="how-it-works">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">
            How It <span className="gradient-text">Works</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            From idea to live website in three simple steps. Our AI handles the complexity so you can focus on your vision.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12"
        >
          {steps.map((step, index) => (
            <motion.div
              key={step.number}
              variants={itemVariants}
              className="relative"
            >
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-12 left-full w-12 z-0">
                  <ArrowRight className="h-6 w-6 text-muted-foreground/30 mx-auto" />
                </div>
              )}
              <div className="relative z-10 flex flex-col items-center text-center p-6 rounded-2xl border border-border bg-card/50 backdrop-blur-sm hover:bg-card transition-colors">
                <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 mb-5">
                  <step.icon className="h-6 w-6 text-primary" />
                </div>
                <span className="text-xs font-semibold text-primary mb-2">
                  Step {step.number}
                </span>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-sm text-muted-foreground text-pretty leading-relaxed">
                  {step.description}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default HowItWorks;