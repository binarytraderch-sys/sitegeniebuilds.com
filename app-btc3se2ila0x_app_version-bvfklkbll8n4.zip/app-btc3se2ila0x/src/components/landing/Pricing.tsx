import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Check, Sparkles, Coins } from 'lucide-react';
import { Button } from '@/components/ui/button';

const plans = [
  {
    name: 'Beginner',
    description: 'Try SiteGenie with no commitment.',
    price: { monthly: '₹100', annual: '₹100' },
    credits: 200,
    features: [
      '200 credits/month',
      '~6 website generations',
      'All AI models included',
      'Community support',
      'SiteGenie subdomain',
    ],
    cta: 'Get Started',
    ctaVariant: 'outline' as const,
    highlighted: false,
  },
  {
    name: 'Starter',
    description: 'Great for individuals who build regularly.',
    price: { monthly: '₹500', annual: '₹500' },
    credits: 1000,
    features: [
      '1,000 credits/month',
      '~33 website generations',
      'All AI models included',
      'Email support',
      'Modification mode',
    ],
    cta: 'Buy Starter',
    ctaVariant: 'outline' as const,
    highlighted: false,
  },
  {
    name: 'Pro',
    description: 'For professionals who build frequently.',
    price: { monthly: '₹1,000', annual: '₹1,000' },
    credits: 2000,
    features: [
      '2,000 credits/month',
      '~66 website generations',
      'All AI models included',
      'Priority support',
      'Modification mode',
      'Advanced analytics',
    ],
    cta: 'Buy Pro',
    ctaVariant: 'default' as const,
    highlighted: true,
  },
  {
    name: 'Enterprise',
    description: 'For agencies and high-volume builders.',
    price: { monthly: '₹5,000', annual: '₹5,000' },
    credits: 10000,
    features: [
      '10,000 credits/month',
      '~333 website generations',
      'All AI models included',
      'Dedicated support',
      'Custom branding',
      'SLA guarantee',
    ],
    cta: 'Buy Enterprise',
    ctaVariant: 'outline' as const,
    highlighted: false,
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

const Pricing: React.FC = () => {
  return (
    <section className="py-20 md:py-28 bg-muted/30" id="pricing">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">
            Simple, Transparent <span className="gradient-text">Pricing</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Buy credits and generate websites instantly. 30 credits per generation. No subscriptions, no hidden fees.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8"
        >
          {plans.map((plan) => (
            <motion.div
              key={plan.name}
              variants={itemVariants}
              className={`relative flex flex-col rounded-2xl border p-6 md:p-8 h-full ${
                plan.highlighted
                  ? 'border-primary/50 bg-card shadow-xl shadow-primary/5'
                  : 'border-border bg-card/50'
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
                    <Sparkles className="h-3 w-3" />
                    Most Popular
                  </span>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-lg font-semibold">{plan.name}</h3>
                <p className="mt-1 text-sm text-muted-foreground text-pretty">
                  {plan.description}
                </p>
              </div>

              <div className="mb-2">
                <span className="text-4xl font-bold tracking-tight">
                  {plan.price.monthly}
                </span>
                <span className="text-muted-foreground text-sm ml-1">/month</span>
              </div>

              <div className="flex items-center gap-1.5 mb-6">
                <Coins className="h-4 w-4 text-primary shrink-0" />
                <span className="text-sm font-semibold text-primary">
                  {plan.credits.toLocaleString()} credits
                </span>
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3 text-sm">
                    <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link to="/register" className="mt-auto">
                <Button
                  variant={plan.ctaVariant}
                  className={`w-full ${
                    plan.highlighted
                      ? 'bg-primary hover:bg-primary/90'
                      : ''
                  }`}
                >
                  {plan.cta}
                </Button>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        <p className="text-center text-xs text-muted-foreground mt-8">
          Secured by Razorpay · UPI, Cards, Net Banking & Wallets accepted · 30 credits per generation
        </p>
      </div>
    </section>
  );
};

export default Pricing;