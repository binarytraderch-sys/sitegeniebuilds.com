import React from 'react';
import { motion } from 'motion/react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const faqs = [
  {
    question: 'How does the AI website builder work?',
    answer:
      'Simply describe what you want in natural language — like "a modern SaaS landing page with purple gradients." Our AI analyzes your request, selects appropriate components, generates custom copy and design, and produces a complete, production-ready website in seconds.',
  },
  {
    question: 'Do I need coding skills to use SiteGenie?',
    answer:
      'Not at all. SiteGenie is designed for everyone, regardless of technical background. You just describe your vision, and the AI handles all the coding, design, and deployment. If you are a developer, you can export the source code for further customization.',
  },
  {
    question: 'Can I use my own domain name?',
    answer:
      'Yes. Pro and Enterprise plans include custom domain support. You can connect your existing domain or purchase a new one directly through the platform. Free plans include a SiteGenie subdomain.',
  },
  {
    question: 'What technologies are used for the generated websites?',
    answer:
      'We generate modern, production-ready code using React, Next.js, TypeScript, and Tailwind CSS. The output follows best practices for performance, accessibility, and SEO. You can export the code at any time.',
  },
  {
    question: 'Is there a limit to how many websites I can create?',
    answer:
      'Free plans allow up to 3 websites. Pro and Enterprise plans offer unlimited website generation, making them perfect for agencies, freelancers, and businesses with multiple projects.',
  },
  {
    question: 'Can I edit the website after it is generated?',
    answer:
      'Absolutely. You can refine your description and regenerate any section, or use our visual editor to make precise adjustments to layout, colors, typography, and content without touching code.',
  },
  {
    question: 'How is my data secured?',
    answer:
      'Security is our top priority. All websites are served over HTTPS, user data is encrypted at rest and in transit, and we follow enterprise-grade security practices. Enterprise plans include additional SSO and compliance features.',
  },
  {
    question: 'What happens if I cancel my subscription?',
    answer:
      'Your websites remain accessible, but you will be downgraded to the Free plan limits. You can always export your code before canceling. We do not delete your projects unless you explicitly request it.',
  },
];

const FAQ: React.FC = () => {
  return (
    <section className="py-20 md:py-28 bg-muted/30" id="faq">
      <div className="mx-auto max-w-3xl px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">
            Frequently Asked <span className="gradient-text">Questions</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Everything you need to know about SiteGenie. Can not find an answer? Contact our support team.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-border">
                <AccordionTrigger className="text-left text-base font-medium hover:no-underline py-5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-sm leading-relaxed text-pretty pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
};

export default FAQ;