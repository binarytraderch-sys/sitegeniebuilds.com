import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Sparkles,
  LayoutDashboard,
  CreditCard,
  Settings,
  LogOut,
  Menu,
  Sun,
  Moon,
  MessageSquareCode,
  Plus,
  Crown,
  Zap,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/components/ThemeProvider';
import { useCredits, SubscriptionPlan } from '@/hooks/use-credits';
import { toast } from 'sonner';

const PLAN_CONFIG: Record<SubscriptionPlan, { label: string; icon: React.ReactNode; className: string }> = {
  free:       { label: 'Free',       icon: <Zap   className="h-3 w-3" />, className: 'bg-muted text-muted-foreground border-border' },
  pro:        { label: 'Pro',        icon: <Crown className="h-3 w-3" />, className: 'bg-amber-500/15 text-amber-600 border-amber-500/30 dark:text-amber-400' },
  enterprise: { label: 'Enterprise', icon: <Crown className="h-3 w-3" />, className: 'bg-primary/10 text-primary border-primary/30' },
};

const navItems = [
  { label: 'Agent Chat',   href: '/dashboard/chat',         icon: MessageSquareCode },
  { label: 'Projects',     href: '/dashboard',               icon: LayoutDashboard },
  { label: 'Subscription', href: '/dashboard/subscription',  icon: CreditCard },
];

interface DashboardLayoutProps {
  children: React.ReactNode;
  /** When true the main area becomes a flex column with overflow-hidden,
   *  letting children control their own scrolling (e.g. the AI chat page). */
  fullHeight?: boolean;
}

const SidebarContent: React.FC<{ onNavigate?: () => void }> = ({ onNavigate }) => {
  const { profile, user, signOut } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { plan } = useCredits();
  const location = useLocation();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    toast.success('Signed out successfully.');
    navigate('/');
    onNavigate?.();
  };

  const displayName =
    profile?.full_name ||
    user?.user_metadata?.full_name ||
    user?.user_metadata?.name ||
    user?.email?.split('@')[0] ||
    'User';

  const avatarUrl = profile?.avatar_url || user?.user_metadata?.avatar_url;
  const initials = displayName
    .split(' ')
    .map((n: string) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const planCfg = PLAN_CONFIG[plan] ?? PLAN_CONFIG.free;

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 p-5 border-b border-border">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary shrink-0">
          <Sparkles className="h-4 w-4 text-primary-foreground" />
        </div>
        <span className="text-base font-semibold tracking-tight">SiteGenie</span>
      </div>

      {/* New Chat CTA */}
      <div className="px-4 pt-4">
        <Link to="/dashboard/chat" onClick={onNavigate}>
          <Button className="w-full gap-2 bg-primary hover:bg-primary/90 justify-start" size="sm">
            <Plus className="h-4 w-4 shrink-0" />
            New Chat
          </Button>
        </Link>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const isActive =
            item.href === '/dashboard'
              ? location.pathname === '/dashboard'
              : location.pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              to={item.href}
              onClick={onNavigate}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:bg-accent hover:text-foreground'
              }`}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border space-y-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleTheme}
          className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground"
        >
          {theme === 'dark' ? (
            <Sun className="h-4 w-4 shrink-0" />
          ) : (
            <Moon className="h-4 w-4 shrink-0" />
          )}
          {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
        </Button>

        <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-muted/50">
          <Avatar className="h-8 w-8 shrink-0">
            <AvatarImage src={avatarUrl} alt={displayName} />
            <AvatarFallback className="text-xs bg-primary text-primary-foreground">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 min-w-0">
              <p className="text-sm font-medium truncate">{displayName}</p>
              <Badge
                variant="outline"
                className={`shrink-0 h-4 px-1.5 text-[10px] font-semibold gap-0.5 leading-none border ${planCfg.className}`}
              >
                {planCfg.icon}
                {planCfg.label}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
          </div>
        </div>

        <Button
          variant="ghost"
          size="sm"
          onClick={handleSignOut}
          className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground"
        >
          <LogOut className="h-4 w-4 shrink-0" />
          Sign Out
        </Button>
      </div>
    </div>
  );
};

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children, fullHeight = false }) => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className={`flex w-full bg-background ${fullHeight ? 'h-screen overflow-hidden' : 'min-h-screen'}`}>
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 border-r border-border bg-card">
        <SidebarContent />
      </aside>

      {/* Main content */}
      <div className={`flex-1 min-w-0 flex flex-col ${fullHeight ? 'overflow-hidden' : 'overflow-x-hidden'}`}>
        {/* Mobile header */}
        <header className="flex lg:hidden items-center h-14 px-4 border-b border-border bg-card shrink-0">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Open menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0 bg-card">
              <SidebarContent onNavigate={() => setMobileOpen(false)} />
            </SheetContent>
          </Sheet>
          <div className="flex items-center gap-2 ml-3">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary">
              <Sparkles className="h-3.5 w-3.5 text-primary-foreground" />
            </div>
            <span className="text-base font-semibold tracking-tight">SiteGenie</span>
          </div>
        </header>

        <main className={
          fullHeight
            ? 'flex-1 min-h-0 overflow-hidden flex flex-col'
            : 'flex-1 p-4 md:p-8 overflow-y-auto'
        }>
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;