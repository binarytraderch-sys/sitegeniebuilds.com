import { HelmetProvider, Helmet } from "react-helmet-async";
import { TooltipProvider } from "@/components/ui/tooltip";

interface PageMetaProps {
  title?: string;
  description?: string;
  canonical?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  twitterTitle?: string;
  twitterDescription?: string;
  twitterImage?: string;
  /** Prevents search engines from indexing this page. Use for /login, /dashboard, etc. */
  noIndex?: boolean;
}

const PageMeta = ({
  title,
  description,
  canonical,
  ogTitle,
  ogDescription,
  ogImage,
  twitterTitle,
  twitterDescription,
  twitterImage,
  noIndex = false,
}: PageMetaProps) => {
  const resolvedOgTitle       = ogTitle        ?? title;
  const resolvedOgDescription = ogDescription  ?? description;
  const resolvedTwTitle       = twitterTitle   ?? ogTitle ?? title;
  const resolvedTwDescription = twitterDescription ?? ogDescription ?? description;
  const resolvedTwImage       = twitterImage   ?? ogImage;

  return (
    <Helmet>
      {title       && <title>{title}</title>}
      {description && <meta name="description"  content={description} />}
      {noIndex
        ? <meta name="robots" content="noindex, nofollow" />
        : <meta name="robots" content="index, follow" />
      }
      {canonical && <link rel="canonical" href={canonical} />}

      {/* Open Graph */}
      {resolvedOgTitle       && <meta property="og:title"       content={resolvedOgTitle} />}
      {resolvedOgDescription && <meta property="og:description" content={resolvedOgDescription} />}
      {ogImage               && <meta property="og:image"       content={ogImage} />}
      {canonical             && <meta property="og:url"         content={canonical} />}

      {/* Twitter Card */}
      {resolvedTwTitle       && <meta name="twitter:title"       content={resolvedTwTitle} />}
      {resolvedTwDescription && <meta name="twitter:description" content={resolvedTwDescription} />}
      {resolvedTwImage       && <meta name="twitter:image"       content={resolvedTwImage} />}
    </Helmet>
  );
};

export const AppWrapper = ({ children }: { children: React.ReactNode }) => (
  <HelmetProvider>
    <TooltipProvider>
      {children}
    </TooltipProvider>
  </HelmetProvider>
);

export default PageMeta;
