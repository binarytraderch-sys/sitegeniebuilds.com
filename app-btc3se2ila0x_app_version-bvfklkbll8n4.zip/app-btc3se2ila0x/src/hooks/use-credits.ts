import { useState, useEffect, useCallback } from 'react';
// @ts-ignore
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';

export type SubscriptionPlan = 'free' | 'pro' | 'enterprise';

export function useCredits() {
  const { user } = useAuth();
  const [credits, setCredits] = useState<number | null>(null);
  const [plan, setPlan] = useState<SubscriptionPlan>('free');
  const [loading, setLoading] = useState(true);
  const [dailyClaimed, setDailyClaimed] = useState(false);

  const fetchCredits = useCallback(async () => {
    if (!user) { setCredits(null); setPlan('free'); setLoading(false); return; }
    setLoading(true);
    const [{ data: creditsData, error: creditsError }, { data: profileData }] = await Promise.all([
      supabase.rpc('get_my_credits'),
      supabase.from('profiles').select('plan').eq('id', user.id).maybeSingle(),
    ]);
    if (!creditsError && typeof creditsData === 'number') setCredits(creditsData);
    if (profileData?.plan) setPlan(profileData.plan as SubscriptionPlan);
    setLoading(false);
  }, [user]);

  // Fetch fresh credits and return the value directly (avoids stale closure reads)
  const getLatestCredits = useCallback(async (): Promise<number> => {
    if (!user) return 0;
    const { data, error } = await supabase.rpc('get_my_credits');
    if (!error && typeof data === 'number') {
      setCredits(data);
      return data;
    }
    return 0;
  }, [user]);

  const claimDailyCredits = useCallback(async (): Promise<{
    success: boolean;
    already_claimed?: boolean;
    credits_added?: number;
    total_credits?: number;
    next_claim_at?: string;
    error?: string;
  }> => {
    if (!user) return { success: false, error: 'Not authenticated' };
    const { data, error } = await supabase.rpc('claim_daily_credits');
    if (error) return { success: false, error: error.message };
    const result = data as {
      success: boolean;
      already_claimed?: boolean;
      credits_added?: number;
      total_credits?: number;
      next_claim_at?: string;
      error?: string;
    };
    if (result.success && result.total_credits !== undefined) {
      setCredits(result.total_credits);
      setDailyClaimed(true);
    }
    if (result.already_claimed) setDailyClaimed(true);
    return result;
  }, [user]);

  // Auto-claim daily credits silently on login
  useEffect(() => {
    if (!user) return;
    fetchCredits().then(() => {
      claimDailyCredits();
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const deductCredits = useCallback(async (): Promise<{ success: boolean; remaining?: number; error?: string }> => {
    if (!user) return { success: false, error: 'Not authenticated' };
    const { data, error } = await supabase.rpc('deduct_generation_credits', { p_user_id: user.id });
    if (error) return { success: false, error: error.message };
    const result = data as { success: boolean; remaining_credits?: number; error?: string };
    if (result.success) {
      setCredits(result.remaining_credits ?? null);
      return { success: true, remaining: result.remaining_credits };
    }
    return { success: false, error: result.error ?? 'Failed to deduct credits' };
  }, [user]);

  const addCredits = useCallback(async (
    creditsToAdd: number,
    planName: string,
    paymentId: string,
    orderId: string,
  ): Promise<{ success: boolean; total?: number; error?: string }> => {
    if (!user) return { success: false, error: 'Not authenticated' };
    const { data, error } = await supabase.rpc('add_credits_after_payment', {
      p_user_id: user.id,
      p_credits: creditsToAdd,
      p_plan_name: planName,
      p_razorpay_payment_id: paymentId,
      p_razorpay_order_id: orderId,
    });
    if (error) return { success: false, error: error.message };
    const result = data as { success: boolean; total_credits?: number; error?: string };
    if (result.success) {
      setCredits(result.total_credits ?? null);
      // Refresh plan from DB after successful payment
      const { data: profileData } = await supabase.from('profiles').select('plan').eq('id', user.id).maybeSingle();
      if (profileData?.plan) setPlan(profileData.plan as SubscriptionPlan);
      return { success: true, total: result.total_credits };
    }
    return { success: false, error: result.error ?? 'Failed to add credits' };
  }, [user]);

  return { credits, plan, loading, dailyClaimed, fetchCredits, getLatestCredits, deductCredits, addCredits, claimDailyCredits };
}
