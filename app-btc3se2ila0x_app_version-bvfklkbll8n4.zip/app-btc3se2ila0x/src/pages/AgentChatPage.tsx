import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import {
  Send, Sparkles, Monitor, Tablet, Smartphone, RefreshCw,
  ExternalLink, Copy, Code2, Eye, CheckCheck, Plus, Bot,
  Globe, FileCode2, GripVertical, Zap, PackageCheck, BarChart3,
  Clock, AlertTriangle, StopCircle, Lightbulb, Palette,
  Wrench, Bug, Pencil, RotateCcw, FileText, Coins, AlertCircle,
  Lock, Crown,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { useAuth } from '@/contexts/AuthContext';
// @ts-ignore
import { supabase } from '@/db/supabase';
import { sendStreamRequest } from '@/lib/sse';
import { toast } from 'sonner';
import DashboardLayout from '@/components/layout/DashboardLayout';
import RequirementsPanel from '@/components/RequirementsPanel';
import { useCredits } from '@/hooks/use-credits';
import { cn } from '@/lib/utils';
import PageMeta from '@/components/common/PageMeta';

// ─── Env ──────────────────────────────────────────────────────────────────────
const SUPABASE_URL      = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
const EDGE_FN_URL       = `${SUPABASE_URL}/functions/v1/llm-v46`;

// ─── Constants ────────────────────────────────────────────────────────────────
const MAX_HISTORY      = 5;
const MAX_PROMPT_CHARS = 12_000;
const PREVIEW_FLUSH_MS = 500;

// ─── System prompt ────────────────────────────────────────────────────────────
const CORE_SYSTEM_PROMPT = `You are SiteGenie, an elite autonomous AI Full Stack Website Builder Agent.
Your mission: generate COMPLETE, production-ready, premium websites from user prompts.

INTELLIGENCE RULES — READ FIRST:
- Analyse the user's prompt to detect industry, audience, tone and purpose BEFORE generating
- Adapt EVERY design decision (colors, typography, sections, content, CTA) to the detected domain
- A restaurant website must feel warm and appetising — NOT like a SaaS product
- A SaaS website must feel clean and technical — NOT like a food blog
- A portfolio must feel creative and personal — NOT like a corporate service
- Use domain-specific language, CTAs, and section types throughout

BEHAVIOR:
- Think step-by-step — plan architecture before writing code
- Generate Apple/Vercel/Linear-quality websites: visually stunning, fully responsive
- NEVER output incomplete code, NEVER leave TODO comments, NEVER use placeholder sections
- NEVER generate fake/empty components or break imports
- Generate complete working code every time — no partial outputs
- All copy must sound written by a human expert in that industry

OUTPUT FORMAT (STRICT):
- Output ONLY raw HTML starting with <!DOCTYPE html>
- No markdown fences, no explanation text, no commentary before/after
- Embed ALL CSS in a <style> tag inside <head>
- Embed ALL JavaScript in a <script> tag before </body>
- Use CSS custom properties for the full design system
- Clear section comments: <!-- COMPONENT: SectionName -->

DESIGN SYSTEM (adapt to domain):
- Premium spacing (8px base grid)
- Smooth gradients and glassmorphism cards (domain-appropriate intensity)
- Elegant micro-animations and IntersectionObserver scroll-reveal
- Dark theme by default unless domain calls for light (e.g. healthcare, education)
- Premium typography from Google Fonts (domain-appropriate: serif for food/luxury, sans for tech)
- Sticky nav with hamburger for mobile

QUALITY STANDARDS:
- Semantic HTML5 (header/main/section/article/footer/nav)
- aria-labels on all interactive elements
- alt text on all images
- Mobile-first responsive at 768px and 1024px
- Zero broken tags, zero JS errors, zero CSS syntax errors
- Real content — never "Lorem ipsum", never "Coming soon", never TODO

ERROR RECOVERY:
- If any section fails, self-heal and complete the output
- Repair broken layouts, missing tags, JS errors before returning`;

const MODIFY_SYSTEM_PROMPT = `You are SiteGenie in MODIFICATION MODE — an elite AI Website Modifier.
An existing production website is provided. You must intelligently modify ONLY what was requested.

MODIFICATION RULES:
- DO NOT create a new website from scratch
- Preserve the existing layout, design system, CSS variables, and all components
- Modify ONLY the specific section or feature requested by the user
- Maintain 100% visual consistency with the existing design
- Reuse all existing CSS custom properties and component patterns
- Keep all existing sections untouched unless explicitly asked to change them

OUTPUT FORMAT (STRICT):
- Output the COMPLETE modified HTML file starting with <!DOCTYPE html>
- No markdown fences, no commentary, no explanation
- The output must be the full working file — not a diff or partial snippet

PROJECT MEMORY — always maintain these across modifications:
- Pages and sections structure
- Design system (colors, fonts, spacing tokens)
- Component patterns and class names
- JavaScript behaviors and event handlers
- All previous customizations by the user`;

// ─── Smart Intelligence Engine ────────────────────────────────────────────────
// Analyses the user's prompt and returns a rich context object that is injected
// into every pipeline phase, making generation domain-aware and purpose-driven.

interface WebsiteContext {
  type: string;           // e.g. "restaurant", "saas", "portfolio"
  industry: string;       // human-readable industry label
  primaryColor: string;   // best-fit brand color
  accentColor: string;    // complementary accent
  bgColor: string;        // dark/light bg
  theme: 'dark' | 'light';
  style: string;          // glassmorphism / minimal / corporate / bold
  sections: string[];     // which sections to include
  tone: string;           // professional / playful / elegant / technical
  fonts: string;          // recommended Google Fonts or system
  keywords: string[];     // domain-specific content keywords
  cta: string;            // primary call-to-action text
  audience: string;       // target audience description
  features: string[];     // domain-specific features to include
}

function detectWebsiteContext(prompt: string): WebsiteContext {
  const p = prompt.toLowerCase();

  // ── Category matchers ────────────────────────────────────────────────────
  const is = (words: string[]) => words.some(w => p.includes(w));

  const isRestaurant  = is(['restaurant','cafe','coffee','bakery','food','menu','chef','cuisine','dining','pizza','sushi','burger','bar','bistro','eatery','catering']);
  const isEcommerce   = is(['shop','store','ecommerce','product','buy','sell','cart','checkout','inventory','marketplace','retail','woocommerce','shopify']);
  const isSaas        = is(['saas','software','app','platform','tool','dashboard','crm','erp','analytics','workflow','automation','subscription','b2b']);
  const isPortfolio   = is(['portfolio','freelance','designer','photographer','artist','creative','showcase','work','projects','resume','cv','personal']);
  const isBlog        = is(['blog','news','article','post','editorial','magazine','newsletter','publication','writing','content']);
  const isAgency      = is(['agency','studio','firm','consulting','marketing','branding','digital','creative agency','web agency']);
  const isHealthcare  = is(['clinic','hospital','doctor','health','medical','wellness','fitness','gym','yoga','therapy','dental','pharmacy']);
  const isEducation   = is(['school','course','learning','education','tutorial','coaching','academy','training','university','e-learning','lms']);
  const isReal        = is(['real estate','property','house','apartment','rent','lease','mortgage','realtor','listing','homes']);
  const isTravel      = is(['travel','hotel','booking','tour','vacation','trip','destination','resort','airbnb','hostel','cruise']);
  const isFinance     = is(['finance','bank','invest','crypto','nft','trading','stock','insurance','fintech','payment','wallet']);
  const isAi          = is(['ai','artificial intelligence','machine learning','llm','chatbot','gpt','neural','deep learning','model','inference']);
  const isStartup     = is(['startup','launch','product launch','mvp','seed','funding','venture','growth']);
  const isEvent       = is(['event','conference','wedding','concert','ticket','festival','meetup','summit']);
  const isNonprofit   = is(['nonprofit','charity','donation','volunteer','ngo','cause','social impact','community']);

  // ── Context map ──────────────────────────────────────────────────────────
  if (isRestaurant) return {
    type: 'restaurant', industry: 'Food & Beverage',
    primaryColor: '#e07b39', accentColor: '#f5c97a', bgColor: '#0e0b08',
    theme: 'dark', style: 'warm glassmorphism',
    sections: ['Navbar','Hero','Menu Highlights','Our Story','Gallery','Reservations','Testimonials','Location & Hours','Footer'],
    tone: 'warm, inviting, appetising',
    fonts: "'Playfair Display', 'Lato', serif",
    keywords: ['menu','reservation','cuisine','fresh ingredients','chef','dining experience','table booking'],
    cta: 'Reserve a Table',
    audience: 'food lovers, local diners, families, couples',
    features: ['Interactive menu with categories','Online reservation form','Photo gallery with lightbox','Location map embed','Opening hours display','Special offers banner'],
  };

  if (isEcommerce) return {
    type: 'ecommerce', industry: 'E-Commerce & Retail',
    primaryColor: '#10b981', accentColor: '#34d399', bgColor: '#0a0f0d',
    theme: 'dark', style: 'clean minimal',
    sections: ['Navbar with cart','Hero Banner','Featured Products','Categories Grid','Best Sellers','Trust Badges','Testimonials','Newsletter CTA','Footer'],
    tone: 'persuasive, trustworthy, energetic',
    fonts: "'Inter', system-ui, sans-serif",
    keywords: ['shop now','add to cart','free shipping','best sellers','sale','new arrivals','secure checkout'],
    cta: 'Shop Now',
    audience: 'online shoppers, deal seekers, brand fans',
    features: ['Product grid with hover effects','Category filter tabs','Shopping cart icon with count','Discount badge system','Trust badges (secure, returns, support)','Newsletter signup'],
  };

  if (isSaas) return {
    type: 'saas', industry: 'SaaS & Software',
    primaryColor: '#6c63ff', accentColor: '#a78bfa', bgColor: '#07070f',
    theme: 'dark', style: 'Linear-style glassmorphism',
    sections: ['Navbar','Hero with demo CTA','Logos (Social Proof)','Features Grid','How It Works','Pricing Tiers','Testimonials','FAQ','CTA Banner','Footer'],
    tone: 'professional, confident, modern',
    fonts: "'Inter', 'Geist', system-ui",
    keywords: ['free trial','get started','dashboard','integrations','API','workflow','automate','scale'],
    cta: 'Start Free Trial',
    audience: 'developers, product teams, CTOs, SMBs',
    features: ['Animated feature cards','3-tier pricing table','Integration logos marquee','Code snippet demo','Dashboard preview mockup','Free trial CTA'],
  };

  if (isPortfolio) return {
    type: 'portfolio', industry: 'Creative Portfolio',
    primaryColor: '#f59e0b', accentColor: '#fbbf24', bgColor: '#0c0c0c',
    theme: 'dark', style: 'minimal bold',
    sections: ['Navbar','Hero (name + tagline)','About Me','Skills & Tools','Projects Grid','Work Process','Testimonials','Contact Form','Footer'],
    tone: 'confident, creative, personal',
    fonts: "'Space Grotesk', 'DM Sans', sans-serif",
    keywords: ['hire me','view work','projects','skills','get in touch','available for freelance'],
    cta: 'View My Work',
    audience: 'potential clients, recruiters, collaborators',
    features: ['Project showcase grid with hover overlay','Skills progress display','Contact form with validation','Downloadable resume link','Social links','Availability status badge'],
  };

  if (isBlog) return {
    type: 'blog', industry: 'Blog & Content',
    primaryColor: '#3b82f6', accentColor: '#60a5fa', bgColor: '#09090f',
    theme: 'dark', style: 'editorial minimal',
    sections: ['Navbar','Hero (latest post)','Featured Articles Grid','Categories','Newsletter Signup','Recent Posts','About Author','Footer'],
    tone: 'informative, engaging, readable',
    fonts: "'Merriweather', 'Inter', serif",
    keywords: ['read more','subscribe','latest articles','trending','categories','author'],
    cta: 'Subscribe Now',
    audience: 'readers, enthusiasts, professionals in the niche',
    features: ['Article card grid with tags','Category filter','Newsletter subscription form','Author bio section','Reading time indicator','Related posts'],
  };

  if (isAgency) return {
    type: 'agency', industry: 'Creative Agency',
    primaryColor: '#ec4899', accentColor: '#f472b6', bgColor: '#080810',
    theme: 'dark', style: 'bold glassmorphism',
    sections: ['Navbar','Hero with reel','Services Grid','Our Work / Case Studies','Process Steps','Team','Client Logos','Testimonials','Contact CTA','Footer'],
    tone: 'bold, creative, results-driven',
    fonts: "'Syne', 'Inter', sans-serif",
    keywords: ['our work','services','case study','results','strategy','creative','branding','digital'],
    cta: 'Start a Project',
    audience: 'businesses, founders, marketing managers',
    features: ['Case study cards with results metrics','Team member cards','Service cards with icons','Client logo strip','Process timeline','Project enquiry form'],
  };

  if (isHealthcare) return {
    type: 'healthcare', industry: 'Health & Wellness',
    primaryColor: '#14b8a6', accentColor: '#2dd4bf', bgColor: '#060f0e',
    theme: 'dark', style: 'clean trustworthy',
    sections: ['Navbar','Hero','Services','About / Credentials','Why Choose Us','Testimonials','Appointments CTA','FAQ','Contact & Map','Footer'],
    tone: 'caring, professional, reassuring',
    fonts: "'Nunito', 'Inter', sans-serif",
    keywords: ['book appointment','trusted care','our services','specialists','patient care','consultation'],
    cta: 'Book Appointment',
    audience: 'patients, health-conscious individuals, families',
    features: ['Service cards with icons','Appointment booking form','Doctor/team profiles','Before-after or result showcases','Trust badges (certified, licensed)','FAQ accordion'],
  };

  if (isEducation) return {
    type: 'education', industry: 'Education & E-Learning',
    primaryColor: '#8b5cf6', accentColor: '#a78bfa', bgColor: '#080814',
    theme: 'dark', style: 'friendly modern',
    sections: ['Navbar','Hero','Featured Courses','How It Works','Instructors','Student Testimonials','Pricing / Enroll','FAQ','Footer'],
    tone: 'encouraging, clear, motivational',
    fonts: "'Plus Jakarta Sans', 'Inter', sans-serif",
    keywords: ['enroll now','learn','course','instructor','certificate','curriculum','skill','lesson'],
    cta: 'Enroll Now',
    audience: 'students, professionals upskilling, career changers',
    features: ['Course cards with ratings and price','Curriculum accordion','Instructor profile cards','Progress/stats counter','Student testimonials','Enrollment CTA'],
  };

  if (isReal) return {
    type: 'realestate', industry: 'Real Estate',
    primaryColor: '#0ea5e9', accentColor: '#38bdf8', bgColor: '#060d14',
    theme: 'dark', style: 'luxurious clean',
    sections: ['Navbar','Hero with Search','Featured Properties','Property Categories','Why Choose Us','Our Process','Agent Profiles','Testimonials','Contact','Footer'],
    tone: 'trustworthy, aspirational, professional',
    fonts: "'Cormorant Garamond', 'Inter', serif",
    keywords: ['find property','browse listings','book viewing','trusted agents','dream home','investment'],
    cta: 'Browse Properties',
    audience: 'home buyers, investors, renters, property owners',
    features: ['Property listing cards with photos','Search/filter bar','Interactive map section','Agent profile cards','Property stats counters','Viewing request form'],
  };

  if (isTravel) return {
    type: 'travel', industry: 'Travel & Hospitality',
    primaryColor: '#06b6d4', accentColor: '#22d3ee', bgColor: '#05101a',
    theme: 'dark', style: 'immersive scenic',
    sections: ['Navbar','Hero with Search','Popular Destinations','Featured Tours','Why Travel With Us','Testimonials','Travel Tips Blog','Newsletter','Footer'],
    tone: 'inspiring, adventurous, dreamy',
    fonts: "'Raleway', 'Inter', sans-serif",
    keywords: ['explore','book now','destinations','adventure','travel tips','packages','guided tours'],
    cta: 'Explore Destinations',
    audience: 'adventurers, families, couples, solo travellers',
    features: ['Destination cards with overlay stats','Tour package cards with pricing','Search/filter bar','Photo gallery','Testimonial slider','Newsletter with travel tips'],
  };

  if (isFinance) return {
    type: 'finance', industry: 'Finance & Fintech',
    primaryColor: '#10b981', accentColor: '#059669', bgColor: '#050f0a',
    theme: 'dark', style: 'precise trustworthy',
    sections: ['Navbar','Hero','Key Metrics/Stats','Features','Security & Trust','How It Works','Pricing','Testimonials','FAQ','CTA','Footer'],
    tone: 'trustworthy, precise, confident',
    fonts: "'IBM Plex Sans', 'Inter', sans-serif",
    keywords: ['invest','secure','returns','portfolio','trusted','regulated','grow your money'],
    cta: 'Get Started',
    audience: 'investors, savers, SMBs, financial professionals',
    features: ['Live stats counters','Security trust badges','Feature comparison table','Calculator widget','Interactive pricing table','Compliance badges'],
  };

  if (isAi) return {
    type: 'ai', industry: 'AI & Machine Learning',
    primaryColor: '#7c3aed', accentColor: '#a78bfa', bgColor: '#07070f',
    theme: 'dark', style: 'futuristic glassmorphism',
    sections: ['Navbar','Hero with demo','Capabilities Grid','How It Works','Model Benchmarks','Use Cases','Pricing','Developer Docs CTA','Testimonials','Footer'],
    tone: 'innovative, intelligent, forward-thinking',
    fonts: "'Geist', 'JetBrains Mono', 'Inter', monospace",
    keywords: ['try for free','API access','model','inference','accuracy','latency','fine-tune','deploy'],
    cta: 'Try for Free',
    audience: 'developers, data scientists, product teams, researchers',
    features: ['Live demo embed/mockup','Code snippet preview','Benchmark comparison table','API docs preview','Use case cards','Token pricing calculator'],
  };

  if (isEvent) return {
    type: 'event', industry: 'Events & Entertainment',
    primaryColor: '#f43f5e', accentColor: '#fb7185', bgColor: '#0f0508',
    theme: 'dark', style: 'bold vibrant',
    sections: ['Navbar','Hero with Countdown','Event Details','Speakers/Performers','Schedule/Agenda','Venue & Map','Sponsors','Tickets CTA','FAQ','Footer'],
    tone: 'exciting, urgent, engaging',
    fonts: "'Bebas Neue', 'Inter', display",
    keywords: ['get tickets','speakers','agenda','venue','register now','limited seats','live'],
    cta: 'Get Tickets',
    audience: 'attendees, fans, professionals, community members',
    features: ['Countdown timer','Speaker profile cards','Schedule/agenda tabs','Ticket tier cards','Venue map embed','Sponsor logo strip'],
  };

  if (isNonprofit) return {
    type: 'nonprofit', industry: 'Nonprofit & Charity',
    primaryColor: '#f97316', accentColor: '#fb923c', bgColor: '#0a0705',
    theme: 'dark', style: 'warm impactful',
    sections: ['Navbar','Hero with Impact Stats','Our Mission','Programs/Initiatives','Impact Numbers','Stories','How to Help','Donate CTA','Partners','Footer'],
    tone: 'compassionate, impactful, inspiring',
    fonts: "'Lora', 'Inter', serif",
    keywords: ['donate','make impact','volunteer','our mission','help us','stories','change lives'],
    cta: 'Donate Now',
    audience: 'donors, volunteers, community members, grant bodies',
    features: ['Animated impact counters','Program cards','Story/blog section','Donation form/CTA','Volunteer signup','Partner logos'],
  };

  if (isStartup) return {
    type: 'startup', industry: 'Startup & Product Launch',
    primaryColor: '#e11d48', accentColor: '#fb7185', bgColor: '#0a0509',
    theme: 'dark', style: 'bold energetic',
    sections: ['Navbar','Hero with waitlist','Problem/Solution','Product Features','Traction/Social Proof','Team','Investors/Backed By','Roadmap','Pricing','FAQ','Footer'],
    tone: 'bold, disruptive, visionary',
    fonts: "'Clash Display', 'Inter', sans-serif",
    keywords: ['join waitlist','early access','launch','backed by','traction','problem we solve','game changer'],
    cta: 'Join the Waitlist',
    audience: 'early adopters, investors, tech enthusiasts',
    features: ['Email waitlist form','Product screenshot mockup','Traction stats counter','Roadmap timeline','Investor logo strip','Team profiles'],
  };

  // ── Default: generic premium website ─────────────────────────────────────
  return {
    type: 'general', industry: 'Business / General',
    primaryColor: '#6c63ff', accentColor: '#a78bfa', bgColor: '#07070f',
    theme: 'dark', style: 'premium glassmorphism',
    sections: ['Navbar','Hero','Features','How It Works','Pricing','Testimonials','FAQ','CTA Banner','Footer'],
    tone: 'professional, modern, trustworthy',
    fonts: "'Inter', system-ui, sans-serif",
    keywords: ['get started','features','how it works','pricing','testimonials','contact'],
    cta: 'Get Started',
    audience: 'businesses, professionals, general audience',
    features: ['Feature cards','Pricing table','Testimonials','FAQ accordion','CTA section','Responsive nav'],
  };
}


type PipelinePhase = 'requirements' | 'planner' | 'ui' | 'code' | 'fix';
type AgentPhase    = 'idle' | 'thinking' | 'streaming' | 'rendering' | 'done' | 'error';
type ViewportMode  = 'desktop' | 'tablet' | 'mobile';
type GenerationMode = 'create' | 'modify';
type PreviewTab    = 'requirements' | 'preview' | 'code';

interface ProjectMemory {
  pages: string[];
  designSystem: { primaryColor: string; fontFamily: string; theme: string };
  sections: string[];
  version: number;
  lastPrompt: string;
}

interface CodeSnippet { language: string; code: string; label?: string }
interface ChatMessage {
  id: string;
  role: 'user' | 'agent';
  content: string;
  streaming?: boolean;
  phase?: AgentPhase;
  pipelinePhase?: PipelinePhase;
  isReady?: boolean;
  mode?: GenerationMode;
  stats?: { chars: number; lines: number; size: string; time: string; model?: string };
  error?: string;
  snippet?: CodeSnippet;
  timestamp: Date;
}

// ─── Pipeline phase definitions ───────────────────────────────────────────────
interface PipelineStep {
  id: PipelinePhase;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  maxChars: number;
  buildPrompt: (userPrompt: string, prev: string, existingHtml: string, memory: ProjectMemory | null) => string;
}

const PIPELINE: PipelineStep[] = [
  {
    id: 'requirements', label: 'Requirements', icon: FileText, maxChars: 2000,
    buildPrompt: (userPrompt, _prev, existingHtml, _memory) => {
      if (existingHtml) {
        return `You are a senior requirements analyst reviewing a website modification request.

Modification request: "${userPrompt}"

Generate a concise **Modification Plan** in markdown format:

## What Changes
- List exactly what sections/features/components will be modified
- Specify any new components or sections to be added

## What Is Preserved
- List every existing element that remains untouched (layout, colors, components, CSS variables)

## Implementation Notes
- Key technical approach for the change
- CSS variables and design tokens to maintain
- JS behaviors to preserve

Keep it under 250 words. Use ## headings and bullet points only.`;
      }
      const ctx = detectWebsiteContext(userPrompt);
      return `You are a senior requirements analyst for a ${ctx.industry} website project.

User request: "${userPrompt}"

DETECTED CONTEXT:
- Website type: ${ctx.type} (${ctx.industry})
- Target audience: ${ctx.audience}
- Brand tone: ${ctx.tone}
- Design style: ${ctx.style}

Generate a structured **Requirements Document** in markdown:

## Overview
Brief description of this ${ctx.type} website, its purpose (${ctx.tone}), and target audience (${ctx.audience}).

## Pages & Sections (in order)
${ctx.sections.map((s: string, i: number) => `${i + 1}. ${s}`).join('\n')}

## Key Features
${ctx.features.map((f: string) => `- ${f}`).join('\n')}

## Design System
- Theme: ${ctx.theme}, style: ${ctx.style}
- Primary color: ${ctx.primaryColor}, Accent: ${ctx.accentColor}
- Fonts: ${ctx.fonts}
- UI style: premium ${ctx.style} with smooth animations

## Domain Keywords to Use
${ctx.keywords.map((k: string) => `"${k}"`).join(', ')}

## Primary CTA
"${ctx.cta}" — prominently featured in Hero and CTA banner

Keep it under 350 words. Be specific and actionable.`;
    },
  },
  {
    id: 'planner', label: 'Planner', icon: Lightbulb, maxChars: 800,
    buildPrompt: (userPrompt, _prev, existingHtml, _memory) => {
      if (existingHtml) {
        return `You are a website architect in MODIFICATION MODE.

MODIFICATION REQUEST: "${userPrompt}"
Existing site preview (first 400 chars): ${existingHtml.slice(0, 400)}...

Output a concise modification architecture plan (max 200 words):
- Exact sections to change (component names)
- Exact sections to preserve (do not touch)
- CSS custom properties to keep unchanged
- New elements/sections/features to add
- JS behaviors to preserve or update
- Responsive breakpoints affected

Reply with ONLY the plan text. No HTML, no code blocks.`;
      }
      const ctx = detectWebsiteContext(userPrompt);
      return `You are an elite ${ctx.industry} website architect. Plan a premium ${ctx.type} website for: "${userPrompt}"

INTELLIGENCE CONTEXT:
- Industry: ${ctx.industry} | Type: ${ctx.type}
- Tone: ${ctx.tone} | Style: ${ctx.style}
- Audience: ${ctx.audience}

Output a precise architecture plan (max 300 words):

SECTIONS (in exact order):
${ctx.sections.map((s: string, i: number) => `${i + 1}. ${s}`).join('\n')}

DESIGN:
- Primary: ${ctx.primaryColor} | Accent: ${ctx.accentColor} | BG: ${ctx.bgColor}
- Theme: ${ctx.theme} | Style: ${ctx.style}

TYPOGRAPHY: ${ctx.fonts}
  Heading: 800-900 weight, tight line-height
  Body: 400-500 weight, 1.6 line-height

DOMAIN FEATURES TO BUILD:
${ctx.features.map((f: string) => `- ${f}`).join('\n')}

DOMAIN KEYWORDS TO USE IN CONTENT:
${ctx.keywords.map((k: string) => `"${k}"`).join(', ')}

PRIMARY CTA: "${ctx.cta}"

ANIMATIONS: IntersectionObserver scroll-reveal, hover lift on cards, gradient text in hero
RESPONSIVE: Mobile-first, hamburger nav at 768px, stacked grid on mobile

Reply with ONLY the plan. No HTML, no code.`;
    },
  },
  {
    id: 'ui', label: 'UI Design', icon: Palette, maxChars: 2500,
    buildPrompt: (userPrompt, plan, existingHtml, _memory) => {
      if (existingHtml) {
        const styleMatch = existingHtml.match(/<style[\s\S]*?<\/style>/i);
        const existingStyle = styleMatch ? styleMatch[0].slice(0, 1800) : '';
        return `You are a UI designer in MODIFICATION MODE.

Modification plan: ${plan}

Existing CSS (MUST preserve all variables and patterns):
${existingStyle}

Output ONLY an updated <style> block that:
- Keeps ALL existing CSS custom properties unchanged
- Adds ONLY the new styles needed for the requested modification
- Maintains the existing design system perfectly
- Adds new component classes without overriding existing ones
- Stays under 150 lines`;
      }
      const ctx = detectWebsiteContext(userPrompt);
      return `You are an elite UI designer building a ${ctx.industry} website design system.

Architecture plan: ${plan}

BRAND INTELLIGENCE:
- Industry: ${ctx.industry} | Tone: ${ctx.tone}
- Style: ${ctx.style}
- Primary: ${ctx.primaryColor} | Accent: ${ctx.accentColor} | BG: ${ctx.bgColor}
- Fonts: ${ctx.fonts}

Output ONLY a complete <style> block (no HTML wrapper, no markdown) with ALL of:

/* === FONTS === */
@import Google Fonts: ${ctx.fonts}

/* === DESIGN TOKENS === */
:root with ALL custom properties:
  --primary: ${ctx.primaryColor}; --primary-hover; --primary-glow: ${ctx.primaryColor}40;
  --accent: ${ctx.accentColor}; --bg: ${ctx.bgColor};
  --bg-secondary; --bg-card; --bg-glass (rgba white 0.04-0.06 + backdrop-filter);
  --text: #f1f1f3; --text-muted: #9ca3af; --text-dim: #6b7280;
  --border: rgba(255,255,255,0.08); --border-subtle;
  --shadow-sm; --shadow-md; --shadow-lg; --shadow-glow: 0 0 40px ${ctx.primaryColor}33;
  --radius-sm: 8px; --radius-md: 12px; --radius-lg: 20px; --radius-full: 9999px;
  --transition-fast: 0.15s ease; --transition-base: 0.25s ease; --transition-slow: 0.4s ease;

/* === BASE === */
CSS reset, box-sizing border-box, scroll-behavior smooth, text selection color

/* === TYPOGRAPHY === */
h1: clamp(2.4rem, 6vw, 4.5rem) weight 800-900
h2: clamp(1.8rem, 3vw, 2.8rem) weight 700-800
h3: 1.2rem weight 700
Body: 1rem / 1.6 weight 400
.gradient-text: background gradient ${ctx.primaryColor} to ${ctx.accentColor}, -webkit-background-clip: text

/* === LAYOUT === */
.container (max-width 1100px, auto margins, padding 0 1.5rem)
.section (padding 5rem 0)
.grid-2 .grid-3 .grid-4 (CSS grid, auto-fit, minmax responsive)
.flex-center .flex-between

/* === NAVIGATION === */
nav: sticky top-0 z-100, backdrop-filter blur(14px), border-bottom
.nav-logo: font-weight 800, color --primary
.nav-links: flex gap-2rem (hidden on mobile)
.nav-cta: .btn-primary style
.hamburger: 3 span bars, transitions for X animation, display none on desktop
nav.scrolled: increased shadow

/* === BUTTONS === */
.btn-primary: bg --primary, color white, padding .7rem 1.8rem, radius --radius-md, font-weight 600
  hover: brightness 1.1, translateY -2px, box-shadow --shadow-glow
.btn-secondary: bg transparent, border 1px --border, color --text
  hover: border-color --primary
.btn-ghost: transparent, color --text-muted, hover bg --bg-card

/* === CARDS === */
.card: bg --bg-card, border 1px --border, border-radius --radius-md, padding 1.8rem
  hover: translateY -5px, border-color ${ctx.primaryColor}55, box-shadow 0 12px 32px ${ctx.primaryColor}22
.card-glass: bg rgba(255,255,255,0.04), backdrop-filter blur(12px), border 1px rgba(255,255,255,0.08)

/* === HERO === */
.hero: min-height 88vh, flex center, text-center
  background: radial-gradient(ellipse 80% 55% at 50% -10%, ${ctx.primaryColor}30, transparent)
.hero-badge: pill shape, bg ${ctx.primaryColor}22, border ${ctx.primaryColor}44, color --primary

/* === DOMAIN COMPONENTS === */
Build CSS classes for: ${ctx.features.slice(0, 5).map((f: string) => f.split(' ').slice(0, 3).join('-').toLowerCase().replace(/[^a-z0-9-]/g, '')).join(', ')}

/* === ANIMATIONS === */
@keyframes fadeInUp, slideInLeft, float (translateY -8px loop), pulse, shimmer
.reveal: opacity 0, translateY 28px, transition .65s ease
.reveal.visible: opacity 1, translateY 0
.reveal-delay-1 through .reveal-delay-4: transition-delay .1s increments

/* === FOOTER === */
footer: border-top --border, padding 3rem 0 1.5rem
.footer-grid: 4-column on desktop, 2-column tablet, 1-column mobile
.footer-bottom: border-top, text-center, text-muted, small text

/* === RESPONSIVE === */
@media max-width 1024px: adjust grids to 2-col
@media max-width 768px: hide .nav-links, show .hamburger, single-col grids, smaller hero text
@media max-width 480px: fine-tune padding, font sizes

Write 200-250 lines of pristine, ${ctx.tone} CSS.`;
    },
  },
  {
    id: 'code', label: 'HTML Builder', icon: Code2, maxChars: 10000,
    buildPrompt: (userPrompt, styleBlock, existingHtml, _memory) => {
      if (existingHtml) {
        return `You are SiteGenie in MODIFICATION MODE.

Original HTML (first 6000 chars):
${existingHtml.slice(0, 6000)}

Updated CSS to merge:
${styleBlock.slice(0, 1200)}

Modification request: "${userPrompt}"

Output the COMPLETE modified HTML file:
- Keep ALL existing sections exactly as-is
- Apply ONLY the specifically requested modification
- Start with <!DOCTYPE html>
- No markdown fences, no commentary
- Fully working, complete file`;
      }
      const ctx = detectWebsiteContext(userPrompt);
      return `You are SiteGenie — build a COMPLETE, production-ready ${ctx.industry} website for: "${userPrompt}"

INTELLIGENCE CONTEXT:
- Type: ${ctx.type} | Industry: ${ctx.industry}
- Audience: ${ctx.audience}
- Tone: ${ctx.tone} | Style: ${ctx.style}
- Primary CTA: "${ctx.cta}"
- Domain keywords to use naturally: ${ctx.keywords.join(', ')}

Embed this CSS verbatim inside <style> in <head>:
${styleBlock.slice(0, 3000)}

REQUIREMENTS:
✅ Output ONLY raw HTML starting exactly with <!DOCTYPE html>
✅ Complete file — no truncation, no placeholders, no TODO comments
✅ REAL ${ctx.industry} content — no generic filler, no Lorem ipsum
✅ Tone of all copy: ${ctx.tone} — written specifically for ${ctx.audience}
✅ Domain keywords used naturally in headings and copy: ${ctx.keywords.slice(0, 5).join(', ')}

REQUIRED SECTIONS (build all, in order):
${ctx.sections.map((s: string, i: number) => `${i + 1}. <!-- COMPONENT: ${s} -->`).join('\n')}

DOMAIN FEATURES TO IMPLEMENT IN FULL:
${ctx.features.map((f: string) => `- ${f}`).join('\n')}

JAVASCRIPT (before </body>):
- Hamburger: toggle .open on .nav-links + animate hamburger bars to X
- Smooth scroll: all a[href^="#"] use scrollIntoView({behavior:'smooth'})
- IntersectionObserver: add .visible to .reveal elements at threshold 0.08
- Sticky nav: add .scrolled after 60px scroll
- FAQ accordion: click to toggle .open, animate max-height
- Counter animation: on scroll-reveal, animate numeric stats from 0 to value
- Any ${ctx.type}-specific JS: ${ctx.type === 'restaurant' ? 'tab switcher for menu categories' : ctx.type === 'event' ? 'countdown timer to event date' : ctx.type === 'ecommerce' ? 'cart item counter' : ctx.type === 'saas' ? 'pricing toggle monthly/annual' : 'smooth tab switching'}

QUALITY STANDARDS:
- Semantic HTML5 (header/main/section/footer/nav/article)
- aria-label on ALL interactive elements
- alt text on ALL img tags
- Zero broken or unclosed tags
- Mobile-first responsive — stack on mobile, grid on desktop
- CTA "${ctx.cta}" must appear PROMINENTLY in Hero and in a full-width CTA Banner section`;
    },
  },
  {
    id: 'fix', label: 'Fix Agent', icon: Bug, maxChars: 10000,
    buildPrompt: (userPrompt, html, _existingHtml, _memory) => {
      const ctx = detectWebsiteContext(userPrompt);
      return `You are SiteGenie's Fix Agent — elite code quality specialist for ${ctx.industry} websites.

Review and fix the following HTML. Check and repair ALL of these:

LAYOUT FIXES:
- Broken or unclosed HTML tags (verify every opening tag has a closing tag)
- Missing DOCTYPE or html/head/body structure
- Sections overflowing on mobile (add overflow:hidden, max-width:100%)
- Broken CSS grid or flexbox layouts
- Missing or broken navigation structure

STYLE FIXES:
- CSS syntax errors (missing semicolons, unclosed braces)
- Missing CSS custom property definitions in :root
- Broken glassmorphism (ensure backdrop-filter AND -webkit-backdrop-filter)
- Poor color contrast — text must always be readable on its background
- Missing hover states on buttons and cards

JAVASCRIPT FIXES:
- JS syntax errors or undefined variable references
- Broken event listeners (null-check querySelector results)
- Non-functioning hamburger menu
- Non-functioning FAQ accordion
- Broken IntersectionObserver or counter animations

CONTENT FIXES:
- Remove any Lorem ipsum text — replace with real ${ctx.industry} copy
- Ensure CTA "${ctx.cta}" is prominent in Hero and CTA Banner
- Ensure domain keywords appear naturally: ${ctx.keywords.slice(0, 4).join(', ')}
- Remove any TODO comments or placeholder values

QUALITY CHECKS:
- All images have descriptive alt text
- All buttons/links have aria-label
- Mobile hamburger menu opens/closes
- Smooth scroll anchors work
- All .reveal animations trigger on scroll

Return the COMPLETE corrected HTML starting with <!DOCTYPE html>.
No markdown fences. No commentary. Full working file only.

HTML TO FIX:
${html.slice(0, 9000)}`;
    },
  },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────
function extractHtml(raw: string): string {
  const s = raw.replace(/^```html\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim();
  const a = s.toLowerCase().indexOf('<!doctype html');
  if (a !== -1) return s.slice(a);
  const b = s.toLowerCase().indexOf('<html');
  if (b !== -1) return s.slice(b);
  return s;
}
function extractStyleBlock(raw: string): string {
  const m = raw.match(/<style[\s\S]*?<\/style>/i);
  return m ? m[0] : raw.trim();
}
function humanSize(str: string) {
  const b = new Blob([str]).size;
  return b < 1024 ? `${b} B` : `${(b / 1024).toFixed(1)} KB`;
}
function guardPrompt(s: string): string {
  return s.length <= MAX_PROMPT_CHARS ? s : s.slice(0, MAX_PROMPT_CHARS) + '\n[…truncated]';
}
function buildMessages(
  systemContent: string,
  history: { role: 'user' | 'assistant'; content: string }[],
) {
  return [
    { role: 'system' as const, content: guardPrompt(systemContent) },
    ...history.slice(-MAX_HISTORY).map(m => ({ ...m, content: guardPrompt(m.content) })),
  ];
}
function inferMemory(html: string, prompt: string): ProjectMemory {
  const colorMatch  = html.match(/--primary:\s*([^;]+)/);
  const fontMatch   = html.match(/font-family:\s*([^;]+)/);
  const themeMatch  = html.includes('dark') || html.includes('#0') ? 'dark' : 'light';
  const sections    = ['nav', 'hero', 'features', 'footer'].filter(s => html.toLowerCase().includes(s));
  return {
    pages: ['index.html'],
    designSystem: {
      primaryColor: colorMatch?.[1]?.trim() ?? '#6366f1',
      fontFamily:   fontMatch?.[1]?.trim()  ?? 'system-ui',
      theme:        themeMatch,
    },
    sections,
    version: 1,
    lastPrompt: prompt,
  };
}

// ─── Generation Variety Engine ────────────────────────────────────────────────
// Produces a unique creative seed on every call so the AI never repeats the
// same layout, palette shade, section order, or hero style.

interface VarietySeed {
  layoutVariant:   string;   // hero layout style
  colorShift:      string;   // hue/saturation nudge instruction
  heroStyle:       string;   // hero visual element
  cardStyle:       string;   // card aesthetic
  sectionOrder:    string;   // which optional sections to include & order
  animationStyle:  string;   // animation personality
  typographyMood:  string;   // font/weight personality
  creativeSuffix:  string;   // unique instruction to force a different result
}

const LAYOUT_VARIANTS = [
  'split-screen hero (text left, visual right)',
  'centered hero with floating 3-D card mockup',
  'full-bleed gradient hero with animated particles',
  'asymmetric hero — oversized heading, small subtext right-aligned',
  'hero with looping SVG background pattern and centered CTA',
  'minimalist hero — large white-space, single bold headline, no imagery',
  'video-style hero with gradient overlay and play button',
  'split diagonal hero — dark left panel, lighter right panel',
];
const HERO_STYLES = [
  'a glowing abstract orb / sphere built with CSS box-shadows',
  'a CSS-only code editor mockup with syntax highlighting',
  'a floating dashboard card with mini bar chart (pure CSS/SVG)',
  'a 3-D perspective phone/browser mockup built in CSS',
  'animated gradient mesh background',
  'geometric grid pattern with subtle animation',
  'CSS blob shape with radial gradient fill',
  'stacked floating cards with depth shadows',
];
const CARD_STYLES = [
  'glassmorphism — frosted blur + rgba border',
  'neumorphism-lite — soft inset shadow, minimal border',
  'flat + color-band — bold left border in accent color',
  'elevated — strong drop shadow, white bg on dark canvas',
  'outlined — single 1px border, no background fill',
  'gradient border — 1px border uses conic-gradient',
];
const ANIMATION_STYLES = [
  'staggered fade-up — 0.12s delay between each card',
  'slide-in from alternating left/right per section',
  'scale-in — cards start at 0.88 scale, ease to 1.0',
  'clip-path reveal — wipe animation from bottom',
  'opacity + translateY with spring easing (cubic-bezier(.34,1.56,.64,1))',
];
const TYPOGRAPHY_MOODS = [
  'editorial — large serif headings, small sans body',
  'techy — monospace accents, clean sans headings',
  'bold — ultra-heavy 900-weight headings, wide letter-spacing',
  'elegant — medium-weight headings, generous line-height',
  'mixed — display font for hero, system-ui for body',
];
const COLOR_SHIFTS = [
  'shift the primary color 15° warmer/more saturated than the base',
  'use a slightly darker, more muted version of the primary for a sophisticated feel',
  'add a vivid complementary accent (180° hue rotation from primary)',
  'use a triadic palette — 3 evenly spaced hues at 120°',
  'desaturate slightly and increase contrast for a premium minimal look',
  'add a warm off-white (#f8f4ef) as the card background instead of pure dark',
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function buildVarietySeed(): VarietySeed {
  const id = Math.random().toString(36).slice(2, 8).toUpperCase();
  return {
    layoutVariant:  pick(LAYOUT_VARIANTS),
    colorShift:     pick(COLOR_SHIFTS),
    heroStyle:      pick(HERO_STYLES),
    cardStyle:      pick(CARD_STYLES),
    animationStyle: pick(ANIMATION_STYLES),
    typographyMood: pick(TYPOGRAPHY_MOODS),
    sectionOrder:   Math.random() > 0.5
      ? 'include a Stats/Counter section after Features'
      : 'include a Comparison table (vs competitors) before Pricing',
    creativeSuffix: `[GEN-ID:${id}] Make this design visually DISTINCT — different from any previous generation.`,
  };
}

function applyVarietyToPrompt(basePrompt: string, seed: VarietySeed): string {
  return `${basePrompt}

CREATIVE VARIATION DIRECTIVES (MANDATORY — these must be applied to make this unique):
- Layout: ${seed.layoutVariant}
- Hero visual element: ${seed.heroStyle}
- Card aesthetic: ${seed.cardStyle}
- Animation style: ${seed.animationStyle}
- Typography mood: ${seed.typographyMood}
- Color treatment: ${seed.colorShift}
- Extra section: ${seed.sectionOrder}
${seed.creativeSuffix}`;
}

// ─── Client-side mock fallback ────────────────────────────────────────────────
// Used when ALL remote LLM models fail (e.g. 502 "No endpoints found").
// Generates a complete, styled HTML website from the user's prompt directly
// in the browser — no server needed.
function buildClientMockHtml(userPrompt: string): string {
  const title = userPrompt.slice(0, 60).replace(/[<>"&]/g, '') || 'My Website';
  const year  = new Date().getFullYear();
  // Derive a simple thematic color from prompt keywords
  const palette: Record<string, string> = {
    restaurant: '#e67e22', food: '#e67e22', cafe: '#a0522d', coffee: '#6f4e37',
    shop: '#2ecc71', store: '#16a085', ecommerce: '#27ae60',
    portfolio: '#8e44ad', blog: '#2980b9', agency: '#1abc9c',
    startup: '#e74c3c', saas: '#6c63ff', ai: '#7c3aed',
    dashboard: '#0ea5e9', admin: '#0f172a', analytics: '#14b8a6',
    health: '#10b981', fitness: '#f59e0b', travel: '#06b6d4',
  };
  const promptLower = userPrompt.toLowerCase();
  const primaryColor = Object.entries(palette).find(([k]) => promptLower.includes(k))?.[1] ?? '#7c3aed';

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title}</title>
<style>
:root{
  --primary:${primaryColor};
  --primary-hover:${primaryColor}cc;
  --bg:#0f0f13;--bg-card:#1a1a24;--bg-glass:rgba(255,255,255,0.04);
  --text:#f1f1f3;--text-muted:#9ca3af;--border:rgba(255,255,255,0.08);
  --radius:14px;--shadow:0 4px 24px rgba(0,0,0,.4);
}
*{box-sizing:border-box;margin:0;padding:0}html{scroll-behavior:smooth}
body{background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,sans-serif;line-height:1.6}
a{color:inherit;text-decoration:none}
/* Nav */
nav{position:sticky;top:0;z-index:100;display:flex;align-items:center;justify-content:space-between;padding:1rem 2rem;background:rgba(15,15,19,.88);backdrop-filter:blur(14px);border-bottom:1px solid var(--border);transition:box-shadow .3s}
nav.scrolled{box-shadow:var(--shadow)}
.logo{font-weight:800;font-size:1.2rem;color:var(--primary);display:flex;align-items:center;gap:.5rem}
.nav-links{display:flex;gap:2rem}
.nav-links a{color:var(--text-muted);font-size:.9rem;transition:color .2s}.nav-links a:hover{color:var(--text)}
.btn{display:inline-flex;align-items:center;gap:.4rem;padding:.6rem 1.4rem;border-radius:10px;font-size:.95rem;font-weight:600;cursor:pointer;border:none;transition:all .2s}
.btn-primary{background:var(--primary);color:#fff}.btn-primary:hover{filter:brightness(1.1);transform:translateY(-2px)}
.btn-outline{background:transparent;color:var(--text);border:1px solid var(--border)}.btn-outline:hover{border-color:var(--primary)}
.hamburger{display:none;flex-direction:column;gap:5px;cursor:pointer;padding:4px}
.hamburger span{width:22px;height:2px;background:var(--text);border-radius:2px;transition:all .3s}
/* Hero */
.hero{min-height:88vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:5rem 2rem;background:radial-gradient(ellipse 80% 55% at 50% -10%,${primaryColor}33,transparent)}
.hero-badge{display:inline-flex;align-items:center;gap:.4rem;background:${primaryColor}22;color:var(--primary);border:1px solid ${primaryColor}44;border-radius:99px;padding:.35rem 1rem;font-size:.78rem;font-weight:600;margin-bottom:1.8rem;letter-spacing:.02em}
.hero h1{font-size:clamp(2.4rem,6vw,4.2rem);font-weight:900;line-height:1.1;margin-bottom:1.4rem;background:linear-gradient(135deg,#fff 0%,${primaryColor}cc 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.hero p{font-size:1.15rem;color:var(--text-muted);max-width:560px;margin:0 auto 2.8rem;line-height:1.7}
.hero-btns{display:flex;gap:1rem;justify-content:center;flex-wrap:wrap}
/* Sections */
section{padding:5rem 2rem}
.container{max-width:1100px;margin:0 auto}
.s-header{text-align:center;margin-bottom:3rem}
.s-header h2{font-size:clamp(1.7rem,3vw,2.5rem);font-weight:800;margin-bottom:.7rem}
.s-header p{color:var(--text-muted);max-width:520px;margin:0 auto}
.grid-3{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1.5rem}
.grid-2{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:2rem;align-items:center}
/* Cards */
.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:1.8rem;transition:transform .25s,border-color .25s,box-shadow .25s}
.card:hover{transform:translateY(-5px);border-color:${primaryColor}55;box-shadow:0 12px 32px ${primaryColor}22}
.card-icon{font-size:2.2rem;margin-bottom:1rem;display:block}
.card h3{font-size:1.1rem;font-weight:700;margin-bottom:.5rem}
.card p{color:var(--text-muted);font-size:.9rem;line-height:1.65}
/* Steps */
.steps{display:flex;flex-direction:column;gap:1.5rem}
.step{display:flex;gap:1.2rem;align-items:flex-start}
.step-num{min-width:44px;height:44px;border-radius:50%;background:${primaryColor}22;border:2px solid ${primaryColor}55;display:flex;align-items:center;justify-content:center;font-weight:800;color:var(--primary);font-size:1.1rem}
.step-body h3{font-weight:700;margin-bottom:.3rem}
.step-body p{color:var(--text-muted);font-size:.9rem}
/* Pricing */
.pricing-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1.5rem}
.price-card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:2rem;display:flex;flex-direction:column}
.price-card.featured{border-color:var(--primary);box-shadow:0 0 30px ${primaryColor}33;position:relative}
.price-badge{position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:var(--primary);color:#fff;padding:.3rem 1.2rem;border-radius:99px;font-size:.75rem;font-weight:700;white-space:nowrap}
.price-card h3{font-size:1.1rem;font-weight:700;margin-bottom:.4rem}
.price-card .price{font-size:2.8rem;font-weight:900;margin:.8rem 0 .3rem}
.price-card .price span{font-size:1rem;font-weight:400;color:var(--text-muted)}
.price-card p{color:var(--text-muted);font-size:.85rem;margin-bottom:1.2rem}
.price-features{list-style:none;margin-bottom:1.5rem;flex:1;display:flex;flex-direction:column;gap:.6rem}
.price-features li{display:flex;align-items:center;gap:.6rem;font-size:.9rem;color:var(--text-muted)}
.price-features li::before{content:"✓";color:var(--primary);font-weight:700;flex-shrink:0}
/* Testimonials */
.test-card{background:var(--bg-glass);border:1px solid var(--border);border-radius:var(--radius);padding:1.8rem;backdrop-filter:blur(8px)}
.test-card blockquote{font-size:.95rem;line-height:1.7;color:var(--text-muted);margin-bottom:1.2rem;font-style:italic}
.test-author{display:flex;align-items:center;gap:.8rem}
.avatar{width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,var(--primary),${primaryColor}88);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.9rem;color:#fff}
.author-info strong{display:block;font-size:.9rem;font-weight:600}
.author-info span{font-size:.8rem;color:var(--text-muted)}
/* CTA */
.cta-box{background:linear-gradient(135deg,${primaryColor}25,${primaryColor}12);border:1px solid ${primaryColor}33;border-radius:20px;text-align:center;padding:5rem 2rem}
.cta-box h2{font-size:clamp(1.8rem,3.5vw,2.6rem);font-weight:800;margin-bottom:1rem}
.cta-box p{color:var(--text-muted);max-width:500px;margin:0 auto 2rem}
/* Footer */
footer{border-top:1px solid var(--border);padding:3rem 2rem 2rem}
.footer-grid{display:grid;grid-template-columns:2fr repeat(3,1fr);gap:2rem;margin-bottom:2.5rem}
.footer-brand p{color:var(--text-muted);font-size:.9rem;margin-top:.8rem;line-height:1.6}
.footer-col h4{font-size:.85rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;margin-bottom:1rem;color:var(--text-muted)}
.footer-col ul{list-style:none;display:flex;flex-direction:column;gap:.6rem}
.footer-col ul li a{color:var(--text-muted);font-size:.9rem;transition:color .2s}.footer-col ul li a:hover{color:var(--text)}
.footer-bottom{border-top:1px solid var(--border);padding-top:1.5rem;text-align:center;color:var(--text-muted);font-size:.82rem}
/* Animations */
.reveal{opacity:0;transform:translateY(28px);transition:opacity .65s ease,transform .65s ease}
.reveal.visible{opacity:1;transform:none}
.reveal-delay-1{transition-delay:.1s}.reveal-delay-2{transition-delay:.2s}.reveal-delay-3{transition-delay:.3s}
/* Responsive */
@media(max-width:900px){.footer-grid{grid-template-columns:1fr 1fr}}
@media(max-width:768px){
  nav{padding:1rem 1.2rem}
  .nav-links{display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,15,19,.97);flex-direction:column;align-items:center;justify-content:center;gap:2rem;font-size:1.2rem}
  .nav-links.open{display:flex}
  .hamburger{display:flex}
  .hero h1{font-size:2.2rem}
  .footer-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>

<!-- COMPONENT: Navbar -->
<nav id="navbar">
  <div class="logo">⚡ ${title}</div>
  <div class="nav-links" id="navLinks">
    <a href="#features" onclick="closeNav()">Features</a>
    <a href="#how-it-works" onclick="closeNav()">How It Works</a>
    <a href="#pricing" onclick="closeNav()">Pricing</a>
    <a href="#contact" onclick="closeNav()">Contact</a>
  </div>
  <div style="display:flex;align-items:center;gap:.8rem">
    <button class="btn btn-primary" onclick="closeNav()">Get Started</button>
    <div class="hamburger" id="hamburger" onclick="toggleNav()" aria-label="Toggle menu" role="button" tabindex="0">
      <span></span><span></span><span></span>
    </div>
  </div>
</nav>

<!-- COMPONENT: Hero -->
<div class="hero">
  <div class="container">
    <div class="hero-badge">✨ Now Live — ${title}</div>
    <h1>${title}</h1>
    <p>A beautifully crafted, production-ready website. Modern design, smooth animations, and fully responsive on every device.</p>
    <div class="hero-btns">
      <button class="btn btn-primary">Get Started Free →</button>
      <button class="btn btn-outline">See Demo</button>
    </div>
  </div>
</div>

<!-- COMPONENT: Features -->
<section id="features">
  <div class="container">
    <div class="s-header">
      <h2 class="reveal">Why Choose Us</h2>
      <p class="reveal reveal-delay-1">Everything you need to succeed, designed beautifully and built to last.</p>
    </div>
    <div class="grid-3">
      <div class="card reveal"><span class="card-icon">🚀</span><h3>Blazing Fast</h3><p>Optimized performance with instant load times, lazy loading, and modern web standards.</p></div>
      <div class="card reveal reveal-delay-1"><span class="card-icon">🎨</span><h3>Premium Design</h3><p>Apple-quality UI with glassmorphism effects, elegant gradients, and premium typography.</p></div>
      <div class="card reveal reveal-delay-2"><span class="card-icon">📱</span><h3>Fully Responsive</h3><p>Pixel-perfect on every screen — desktop, tablet, and mobile from day one.</p></div>
      <div class="card reveal"><span class="card-icon">🔒</span><h3>Secure &amp; Reliable</h3><p>Built with security best practices, accessibility standards, and semantic HTML.</p></div>
      <div class="card reveal reveal-delay-1"><span class="card-icon">⚡</span><h3>Easy to Scale</h3><p>Modular architecture and clean code make it effortless to add features as you grow.</p></div>
      <div class="card reveal reveal-delay-2"><span class="card-icon">🌍</span><h3>Deploy Anywhere</h3><p>One-click deployment to Vercel, Netlify, or any hosting platform in seconds.</p></div>
    </div>
  </div>
</section>

<!-- COMPONENT: How It Works -->
<section id="how-it-works" style="background:rgba(255,255,255,.01)">
  <div class="container">
    <div class="s-header">
      <h2 class="reveal">How It Works</h2>
      <p class="reveal reveal-delay-1">Three simple steps to get started today.</p>
    </div>
    <div class="grid-2">
      <div class="steps">
        <div class="step reveal"><div class="step-num">1</div><div class="step-body"><h3>Describe Your Vision</h3><p>Tell us what you want to build in plain English — no technical knowledge required.</p></div></div>
        <div class="step reveal reveal-delay-1"><div class="step-num">2</div><div class="step-body"><h3>AI Generates It</h3><p>Our 5-phase AI pipeline plans, designs, codes, and fixes your website automatically.</p></div></div>
        <div class="step reveal reveal-delay-2"><div class="step-num">3</div><div class="step-body"><h3>Launch &amp; Iterate</h3><p>Preview, modify, and deploy your website. Keep improving it with simple prompts.</p></div></div>
      </div>
      <div class="reveal" style="background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:2rem;min-height:220px;display:flex;align-items:center;justify-content:center">
        <div style="text-align:center">
          <div style="font-size:4rem;margin-bottom:1rem">⚡</div>
          <p style="color:var(--text-muted);font-size:.95rem">Your website, generated in seconds</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- COMPONENT: Pricing -->
<section id="pricing">
  <div class="container">
    <div class="s-header">
      <h2 class="reveal">Simple Pricing</h2>
      <p class="reveal reveal-delay-1">Pay only for what you use. No subscriptions, no hidden fees.</p>
    </div>
    <div class="pricing-grid">
      <div class="price-card reveal">
        <h3>Beginner</h3>
        <div class="price">₹100<span>/mo</span></div>
        <p>Try SiteGenie risk-free.</p>
        <ul class="price-features">
          <li>200 credits</li><li>~6 generations</li><li>All AI models</li><li>Community support</li>
        </ul>
        <button class="btn btn-outline" style="width:100%">Get Started</button>
      </div>
      <div class="price-card featured reveal reveal-delay-1">
        <div class="price-badge">Most Popular</div>
        <h3>Pro</h3>
        <div class="price">₹1,000<span>/mo</span></div>
        <p>For professionals who build daily.</p>
        <ul class="price-features">
          <li>2,000 credits</li><li>~66 generations</li><li>All AI models</li><li>Priority support</li><li>Modification mode</li>
        </ul>
        <button class="btn btn-primary" style="width:100%">Start Building</button>
      </div>
      <div class="price-card reveal reveal-delay-2">
        <h3>Enterprise</h3>
        <div class="price">₹5,000<span>/mo</span></div>
        <p>For agencies &amp; high-volume teams.</p>
        <ul class="price-features">
          <li>10,000 credits</li><li>~333 generations</li><li>All AI models</li><li>Dedicated support</li><li>Custom branding</li>
        </ul>
        <button class="btn btn-outline" style="width:100%">Contact Sales</button>
      </div>
    </div>
  </div>
</section>

<!-- COMPONENT: Testimonials -->
<section style="background:rgba(255,255,255,.01)">
  <div class="container">
    <div class="s-header">
      <h2 class="reveal">What People Say</h2>
      <p class="reveal reveal-delay-1">Thousands of users trust SiteGenie to build their websites.</p>
    </div>
    <div class="grid-3">
      <div class="test-card reveal"><blockquote>"Absolutely incredible. I had a full restaurant website live in under 5 minutes. The design quality is stunning."</blockquote><div class="test-author"><div class="avatar">A</div><div class="author-info"><strong>Arjun Mehta</strong><span>Restaurant Owner</span></div></div></div>
      <div class="test-card reveal reveal-delay-1"><blockquote>"As a freelancer, SiteGenie saves me hours per project. My clients are amazed at how fast I deliver."</blockquote><div class="test-author"><div class="avatar">P</div><div class="author-info"><strong>Priya Sharma</strong><span>Freelance Designer</span></div></div></div>
      <div class="test-card reveal reveal-delay-2"><blockquote>"We use SiteGenie for all our client landing pages. The AI understands context and brand perfectly."</blockquote><div class="test-author"><div class="avatar">R</div><div class="author-info"><strong>Rahul Gupta</strong><span>Agency Founder</span></div></div></div>
    </div>
  </div>
</section>

<!-- COMPONENT: CTA Banner -->
<section id="contact">
  <div class="container">
    <div class="cta-box reveal">
      <h2>Ready to Build Something Amazing?</h2>
      <p>Join thousands of creators, freelancers, and businesses building with SiteGenie AI.</p>
      <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap">
        <button class="btn btn-primary">Start Building Free →</button>
        <button class="btn btn-outline">View Examples</button>
      </div>
    </div>
  </div>
</section>

<!-- COMPONENT: Footer -->
<footer>
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="logo">⚡ ${title}</div>
        <p>AI-powered website generation. Build premium, production-ready websites in seconds with our 5-phase AI pipeline.</p>
      </div>
      <div class="footer-col"><h4>Product</h4><ul><li><a href="#">Features</a></li><li><a href="#">Pricing</a></li><li><a href="#">Demo</a></li><li><a href="#">Changelog</a></li></ul></div>
      <div class="footer-col"><h4>Company</h4><ul><li><a href="#">About</a></li><li><a href="#">Blog</a></li><li><a href="#">Careers</a></li><li><a href="#">Contact</a></li></ul></div>
      <div class="footer-col"><h4>Legal</h4><ul><li><a href="#">Privacy</a></li><li><a href="#">Terms</a></li><li><a href="#">Security</a></li></ul></div>
    </div>
    <div class="footer-bottom">© ${year} ${title}. Built with ❤️ using SiteGenie AI.</div>
  </div>
</footer>

<script>
// Scroll reveal
const obs = new IntersectionObserver(
  entries => entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); }),
  { threshold: 0.08 }
);
document.querySelectorAll('.reveal').forEach(el => obs.observe(el));

// Sticky nav shadow
window.addEventListener('scroll', () => {
  document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 50);
});

// Hamburger
function toggleNav() {
  document.getElementById('navLinks').classList.toggle('open');
}
function closeNav() {
  document.getElementById('navLinks').classList.remove('open');
}

// Smooth scroll for nav links
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    const el = document.querySelector(a.getAttribute('href'));
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});
</script>
</body>
</html>`;
}

// ─── Subcomponents ────────────────────────────────────────────────────────────
const ThinkingDots: React.FC = () => (
  <span className="inline-flex items-center gap-1 ml-1">
    {[0, 1, 2].map((i) => (
      <motion.span key={i} className="inline-block h-1.5 w-1.5 rounded-full bg-primary"
        animate={{ opacity: [0.3, 1, 0.3] }}
        transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.18 }} />
    ))}
  </span>
);

const PipelineTrack: React.FC<{
  active: PipelinePhase | null;
  done: PipelinePhase[];
  chars: number;
  mode: GenerationMode;
}> = ({ active, done, chars, mode }) => (
  <div className="space-y-2">
    <div className="flex items-center gap-1 flex-wrap">
      {mode === 'modify' && (
        <div className="flex items-center gap-1 px-2 py-1 rounded-full border border-primary/40 bg-primary/10 text-primary text-[11px] font-medium mb-1 w-full">
          <Pencil className="h-3 w-3" /> Modification mode — preserving existing design
        </div>
      )}
      {PIPELINE.map(({ id, label, icon: Icon }) => {
        const isDone   = done.includes(id);
        const isActive = active === id;
        return (
          <div key={id} className={cn(
            'flex items-center gap-1.5 px-2 py-1 rounded-full border text-[11px] font-medium transition-all',
            isDone   ? 'border-primary/60 bg-primary/10 text-primary' :
            isActive ? 'border-primary/40 bg-primary/5 text-primary animate-pulse' :
                       'border-border text-muted-foreground',
          )}>
            <Icon className="h-3 w-3" />
            {label}
            {isDone && <CheckCheck className="h-2.5 w-2.5" />}
          </div>
        );
      })}
    </div>
    {active && (
      <>
        <Progress value={Math.min(99, (chars / 3000) * 100)} className="h-1" />
        <p className="text-xs text-muted-foreground animate-pulse flex items-center gap-1">
          <Zap className="h-3 w-3 text-primary" />
          {chars.toLocaleString()} chars streamed…
        </p>
      </>
    )}
  </div>
);

const CodeBlock: React.FC<{ snippet: CodeSnippet }> = ({ snippet }) => {
  const [copied, setCopied] = useState(false);
  return (
    <div className="mt-2 rounded-lg border border-border overflow-hidden text-xs">
      <div className="flex items-center justify-between px-3 py-1.5 bg-muted/50 border-b border-border">
        <div className="flex items-center gap-2">
          <span className="font-mono text-muted-foreground">{snippet.language}</span>
          {snippet.label && <span className="text-muted-foreground/70">· {snippet.label}</span>}
        </div>
        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => {
          navigator.clipboard.writeText(snippet.code);
          setCopied(true); setTimeout(() => setCopied(false), 1800);
        }}>
          {copied ? <CheckCheck className="h-3 w-3 text-primary" /> : <Copy className="h-3 w-3" />}
        </Button>
      </div>
      <pre className="p-3 overflow-x-auto bg-background/80 leading-relaxed max-h-48">
        <code className="font-mono text-foreground/90">{snippet.code}</code>
      </pre>
    </div>
  );
};

const ChatBubble: React.FC<{
  msg: ChatMessage;
  activePipeline: PipelinePhase | null;
  donePipeline: PipelinePhase[];
  liveChars: number;
  mode: GenerationMode;
}> = ({ msg, activePipeline, donePipeline, liveChars, mode }) => {
  const isUser  = msg.role === 'user';
  const isLive  = msg.streaming;
  const isThink = msg.phase === 'thinking';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22 }}
      className={cn('flex gap-3 w-full', isUser ? 'flex-row-reverse' : 'flex-row')}
    >
      <div className="shrink-0 mt-0.5">
        {isUser ? (
          <Avatar className="h-7 w-7">
            <AvatarFallback className="text-[10px] bg-secondary text-secondary-foreground font-semibold">YOU</AvatarFallback>
          </Avatar>
        ) : (
          <div className="h-7 w-7 rounded-full bg-primary/15 border border-primary/25 flex items-center justify-center">
            <Bot className="h-3.5 w-3.5 text-primary" />
          </div>
        )}
      </div>

      <div className={cn('max-w-[88%] space-y-1', isUser ? 'items-end flex flex-col' : '')}>
        <div className={cn(
          'rounded-2xl px-4 py-3 text-sm leading-relaxed',
          isUser
            ? 'bg-primary text-primary-foreground rounded-tr-sm'
            : 'bg-muted/50 border border-border/70 text-foreground rounded-tl-sm',
        )}>
          {isThink && (
            <span className="flex items-center gap-1.5 text-muted-foreground text-xs">
              <motion.span animate={{ rotate: 360 }} transition={{ duration: 1.4, repeat: Infinity, ease: 'linear' }} className="inline-block">⚙</motion.span>
              Initialising {mode === 'modify' ? 'modification' : 'generation'} pipeline<ThinkingDots />
            </span>
          )}
          {isLive && (
            <PipelineTrack active={activePipeline} done={donePipeline} chars={liveChars} mode={mode} />
          )}
          {msg.phase === 'rendering' && (
            <span className="flex items-center gap-1.5 text-muted-foreground text-xs">
              <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                className="h-3 w-3 rounded-full border-2 border-primary border-t-transparent" />
              {mode === 'modify' ? 'Applying changes…' : 'Rendering preview…'}
            </span>
          )}
          {msg.isReady && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 font-semibold text-primary">
                <PackageCheck className="h-4 w-4" />
                {msg.mode === 'modify' ? 'Modification applied! ✨' : 'Website ready! 🎉'}
              </div>
              <p className="text-muted-foreground text-[13px] leading-relaxed">
                {msg.mode === 'modify'
                  ? 'Your existing site was modified. Original design and structure preserved.'
                  : 'Generated via 5-phase pipeline: Requirements → Planner → UI Design → HTML Builder → Fix Agent.'}
              </p>
              {msg.stats && (
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { Icon: BarChart3, label: 'Characters', val: msg.stats.chars.toLocaleString() },
                    { Icon: FileCode2, label: 'Lines',       val: msg.stats.lines.toLocaleString() },
                    { Icon: Zap,       label: 'Bundle size', val: msg.stats.size },
                    { Icon: Clock,     label: 'Gen time',    val: msg.stats.time },
                  ].map(({ Icon, label, val }) => (
                    <div key={label} className="flex items-center gap-2 bg-muted/40 rounded-lg px-3 py-2">
                      <Icon className="h-3.5 w-3.5 text-primary shrink-0" />
                      <div className="min-w-0">
                        <p className="text-[10px] text-muted-foreground">{label}</p>
                        <p className="text-xs font-semibold">{val}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {msg.stats?.model && (
                <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <Sparkles className="h-2.5 w-2.5" /> Model: {msg.stats.model}
                </p>
              )}
              {msg.snippet && <CodeBlock snippet={msg.snippet} />}
            </div>
          )}
          {msg.phase === 'error' && (
            <div className="flex items-start gap-2 text-destructive">
              <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold text-sm">Generation failed</p>
                <p className="text-xs text-muted-foreground mt-0.5">{msg.error}</p>
              </div>
            </div>
          )}
          {!msg.phase && !msg.isReady && !isUser && !isLive && (
            <span>{msg.content}</span>
          )}
          {isUser && <span>{msg.content}</span>}
        </div>
        <span className="text-[10px] text-muted-foreground px-1">
          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </motion.div>
  );
};

// ─── Browser frame ────────────────────────────────────────────────────────────
const BrowserFrame: React.FC<{
  html: string;
  liveHtml: string;
  viewport: ViewportMode;
  isGenerating: boolean;
  isDragging: boolean;
  activePhase: PipelinePhase | null;
  mode: GenerationMode;
}> = ({ html, liveHtml, viewport, isGenerating, isDragging, activePhase, mode }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const displayHtml = html || liveHtml;

  useEffect(() => {
    if (!iframeRef.current || !displayHtml) return;
    const doc = iframeRef.current.contentDocument ?? iframeRef.current.contentWindow?.document;
    if (doc) { doc.open(); doc.write(displayHtml); doc.close(); }
  }, [displayHtml, refreshKey]);

  const maxW: Record<ViewportMode, string> = {
    desktop: 'w-full', tablet: 'max-w-[768px]', mobile: 'max-w-[390px]',
  };
  const phaseLabel: Record<PipelinePhase, string> = {
    requirements: 'Writing requirements…', planner: 'Planning…', ui: 'Designing UI…', code: 'Building HTML…', fix: 'Fixing code…',
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col items-center overflow-hidden bg-muted/10 p-3">
      <div className={cn(
        'flex-1 min-h-0 w-full rounded-xl overflow-hidden border border-border shadow-xl flex flex-col transition-[max-width] duration-300',
        maxW[viewport],
      )}>
        <div className="flex items-center gap-2 px-3 py-2.5 bg-card border-b border-border shrink-0">
          <div className="flex gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-destructive/60" />
            <span className="h-2.5 w-2.5 rounded-full bg-yellow-400/60" />
            <span className="h-2.5 w-2.5 rounded-full bg-green-500/60" />
          </div>
          <div className="flex-1 mx-2 bg-muted rounded px-3 py-1 text-[11px] text-muted-foreground font-mono truncate">
            {activePhase ? phaseLabel[activePhase] : displayHtml ? 'preview.sitegenie.app' : 'about:blank'}
          </div>
          {isGenerating && (
            <Badge variant="secondary" className={cn('text-[9px] px-1.5 h-4 gap-1 animate-pulse', mode === 'modify' ? 'bg-orange-500/10 text-orange-500 border-orange-500/30' : '')}>
              {mode === 'modify' ? <><Pencil className="h-2.5 w-2.5" /> Modifying</> : <><Zap className="h-2.5 w-2.5" /> Live</>}
            </Badge>
          )}
          <Globe className="h-3 w-3 text-muted-foreground" />
        </div>

        <div className="flex-1 min-h-0 relative">
          {isGenerating && !displayHtml ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-background">
              <motion.div animate={{ rotate: 360 }}
                transition={{ duration: 1.6, repeat: Infinity, ease: 'linear' }}
                className="h-9 w-9 rounded-full border-[3px] border-primary border-t-transparent" />
              <p className="text-sm text-muted-foreground">
                {activePhase ? phaseLabel[activePhase] : 'Starting pipeline…'}
              </p>
            </div>
          ) : displayHtml ? (
            <>
              <iframe ref={iframeRef} title="Live Website Preview"
                sandbox="allow-scripts allow-same-origin"
                className="absolute inset-0 w-full h-full bg-white"
                style={{ pointerEvents: isDragging ? 'none' : 'auto' }} />
              {isGenerating && (
                <div className="absolute top-2 left-2 right-2 z-10">
                  <div className="bg-background/80 backdrop-blur-sm border border-border rounded-lg px-3 py-1.5 flex items-center gap-2">
                    <Wrench className="h-3 w-3 text-primary animate-spin" />
                    <span className="text-[11px] text-muted-foreground">
                      {activePhase ? phaseLabel[activePhase] : 'Processing…'}
                    </span>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-muted-foreground">
              <div className="h-14 w-14 rounded-2xl border-2 border-dashed border-border flex items-center justify-center">
                <Globe className="h-6 w-6 opacity-30" />
              </div>
              <p className="text-sm font-medium">Preview will appear here</p>
              <p className="text-xs opacity-50">5-phase pipeline · OpenRouter · Gemini 2.5 Flash</p>
            </div>
          )}
          {!isGenerating && displayHtml && (
            <Button size="icon" variant="secondary"
              className="absolute bottom-3 right-3 h-7 w-7 shadow-md opacity-60 hover:opacity-100"
              onClick={() => setRefreshKey(k => k + 1)}>
              <RefreshCw className="h-3 w-3" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

// ─── Suggestions ──────────────────────────────────────────────────────────────
const CREATE_PROMPTS = [
  'SaaS landing page for an AI project management tool',
  'Restaurant website with online menu and reservation system',
  'Portfolio website for a UX/UI designer',
  'E-commerce store for premium handmade jewellery',
  'Startup launch page for a fitness tracking app',
  'Travel agency website with destination packages',
  'Healthcare clinic website with appointment booking',
  'AI tool landing page with pricing and demo',
];
const MODIFY_PROMPTS = [
  'Add a dark glassmorphism hero with animated gradient',
  'Add a 3-tier pricing section with a "Most Popular" badge',
  'Improve typography — use a premium Google Font',
  'Add smooth IntersectionObserver scroll-reveal animations',
  'Add a testimonials section with star ratings',
  'Add a sticky header that blurs on scroll',
];

// ─── Main page ────────────────────────────────────────────────────────────────
const AgentChatPage: React.FC = () => {
  const { user }       = useAuth();
  const navigate       = useNavigate();
  const [searchParams] = useSearchParams();
  const pid = searchParams.get('project');

  // ── Credits ─────────────────────────────────────────────────────────────────
  const { credits, plan, loading: creditsLoading, deductCredits, getLatestCredits } = useCredits();

  // ── Core state ──────────────────────────────────────────────────────────────
  const [messages, setMessages]             = useState<ChatMessage[]>([]);
  const [input, setInput]                   = useState('');
  const [phase, setPhase]                   = useState<AgentPhase>('idle');
  const [genMode, setGenMode]               = useState<GenerationMode>('create');
  const [activePipeline, setActivePipeline] = useState<PipelinePhase | null>(null);
  const [donePipeline, setDonePipeline]     = useState<PipelinePhase[]>([]);
  const [generatedHtml, setGeneratedHtml]   = useState('');
  const [liveHtml, setLiveHtml]             = useState('');
  const [generatedCode, setGeneratedCode]   = useState('');
  const [liveChars, setLiveChars]           = useState(0);
  const [viewport, setViewport]             = useState<ViewportMode>('desktop');
  const [mobileTab, setMobileTab]           = useState<'chat' | 'preview'>('chat');
  const [codeCopied, setCodeCopied]         = useState(false);
  const [projectName, setProjectName]       = useState('New Chat');
  const [activeTab, setActiveTab]           = useState<PreviewTab>('requirements');
  const [requirementsDoc, setRequirementsDoc]     = useState('');
  const [liveRequirements, setLiveRequirements]   = useState('');
  const [isReqStreaming, setIsReqStreaming]        = useState(false);
  const [projectMemory, setProjectMemory]   = useState<ProjectMemory | null>(null);
  const [modelUsed, setModelUsed]           = useState('');
  const [showExportGate, setShowExportGate] = useState(false);
  // Tracks the saved Supabase project row so modifications update instead of inserting
  const [savedProjectId, setSavedProjectId] = useState<string | null>(null);
  const [splitPct, setSplitPct]  = useState(40);
  const isDragging               = useRef(false);
  const dragStartX               = useRef(0);
  const dragStartPct             = useRef(40);
  const containerRef             = useRef<HTMLDivElement>(null);

  const onDividerMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isDragging.current   = true;
    dragStartX.current   = e.clientX;
    dragStartPct.current = splitPct;
    document.body.style.cursor     = 'col-resize';
    document.body.style.userSelect = 'none';
  }, [splitPct]);

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (!isDragging.current || !containerRef.current) return;
      const total = containerRef.current.getBoundingClientRect().width;
      setSplitPct(Math.min(75, Math.max(20, dragStartPct.current + ((e.clientX - dragStartX.current) / total) * 100)));
    };
    const onUp = () => {
      if (!isDragging.current) return;
      isDragging.current = false;
      document.body.style.cursor = document.body.style.userSelect = '';
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
  }, []);

  // ── Refs ────────────────────────────────────────────────────────────────────
  const abortRef         = useRef<AbortController | null>(null);
  const rawBufferRef     = useRef('');
  const liveReqBuffer    = useRef('');
  const liveHtmlTimer    = useRef<ReturnType<typeof setTimeout> | null>(null);
  const messagesEndRef   = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!pid) {
      // Fresh chat — show generic welcome
      setMessages([{
        id: 'welcome', role: 'agent', timestamp: new Date(),
        content: "Hi! I'm SiteGenie 🤖 — an intelligent, autonomous AI website builder. I detect your industry from your prompt and automatically choose the right colors, typography, sections, and content tone. I use a 5-phase pipeline (Requirements → Planner → UI Design → HTML Builder → Fix Agent) to generate production-ready websites tailored to your domain. Just describe what you want to build — e.g. \"restaurant with online menu\", \"SaaS landing page\", \"portfolio for a photographer\" — and I'll handle everything.",
      }]);
      return;
    }

    // Load existing project from DB
    (async () => {
      const { data, error } = await supabase
        .from('projects')
        .select('id, name, description')
        .eq('id', pid)
        .maybeSingle();

      if (error || !data) {
        // Project not found — fall back to fresh chat
        setMessages([{
          id: 'welcome', role: 'agent', timestamp: new Date(),
          content: "Hi! I'm SiteGenie 🤖 — an intelligent, autonomous AI website builder. I detect your industry from your prompt and automatically choose the right colors, typography, sections, and content tone. I use a 5-phase pipeline (Requirements → Planner → UI Design → HTML Builder → Fix Agent) to generate production-ready websites tailored to your domain. Just describe what you want to build — e.g. \"restaurant with online menu\", \"SaaS landing page\", \"portfolio for a photographer\" — and I'll handle everything.",
        }]);
        return;
      }

      // Restore project context
      setProjectName(data.name || 'Untitled Project');
      setSavedProjectId(data.id);

      const originalPrompt = data.description || '';
      setMessages([
        {
          id: 'project-loaded', role: 'agent', timestamp: new Date(),
          content: `Welcome back! 👋 You've opened **${data.name || 'Untitled Project'}**.${originalPrompt ? `\n\nThis project was originally built from:\n> ${originalPrompt}` : ''}\n\nDescribe what changes you'd like to make — or type a new prompt to regenerate this site from scratch.`,
        },
      ]);
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pid]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // ── Message helpers ─────────────────────────────────────────────────────────
  const addMsg = useCallback((msg: Omit<ChatMessage, 'id' | 'timestamp'>): string => {
    const id = crypto.randomUUID();
    setMessages(prev => [...prev, { ...msg, id, timestamp: new Date() }]);
    return id;
  }, []);
  const patchLastAgent = useCallback((patch: Partial<ChatMessage>) => {
    setMessages(prev => {
      const copy = [...prev];
      for (let i = copy.length - 1; i >= 0; i--) {
        if (copy[i].role === 'agent') { copy[i] = { ...copy[i], ...patch }; break; }
      }
      return copy;
    });
  }, []);

  // ── Single-phase call ────────────────────────────────────────────────────────
  const runPhase = useCallback((
    systemPrompt: string,
    userContent: string,
    onChunk: (c: string) => void,
  ): Promise<string> => {
    return new Promise((resolve, reject) => {
      const buf = { text: '' };
      sendStreamRequest({
        functionUrl:     EDGE_FN_URL,
        requestBody:     { messages: buildMessages(systemPrompt, [{ role: 'user', content: userContent }]) },
        supabaseAnonKey: SUPABASE_ANON_KEY,
        signal:          abortRef.current?.signal,
        onData: (data: string) => {
          try {
            const frame = JSON.parse(data);
            // Dual-format: Gemini gateway (new) → candidates[0].content.parts[0].text
            //              OpenAI/OpenRouter (legacy) → choices[0].delta.content
            const chunk: string =
              frame?.candidates?.[0]?.content?.parts?.[0]?.text
              ?? frame?.choices?.[0]?.delta?.content
              ?? '';
            if (!chunk) return;
            buf.text += chunk;
            onChunk(chunk);
          } catch { /* partial / incomplete frame */ }
        },
        onComplete: () => resolve(buf.text),
        onError:    (err) => reject(err),
      });
    });
  }, []);

  const scheduleLivePreview = useCallback((raw: string) => {
    if (liveHtmlTimer.current) return;
    liveHtmlTimer.current = setTimeout(() => {
      liveHtmlTimer.current = null;
      const partial = extractHtml(raw);
      if (partial.length > 300) setLiveHtml(partial);
    }, PREVIEW_FLUSH_MS);
  }, []);

  // ── Main pipeline ───────────────────────────────────────────────────────────
  const handleGenerate = useCallback(async (prompt: string) => {
    // Block only while actively generating — allow sending from 'done' and 'error' states
    const isActive = phase === 'thinking' || phase === 'streaming' || phase === 'rendering';
    if (!prompt.trim() || isActive) return;

    const trimmed = prompt.trim();
    setInput('');

    // ── Credits check before starting ──────────────────────────────────────
    if (user) {
      // Fetch fresh credits from DB — never rely on stale React state
      const freshCredits = await getLatestCredits();
      if (freshCredits < 30) {
        toast.error('Not enough credits! Each generation costs 30 credits. Top up on the Credits page.', {
          action: { label: 'Buy Credits', onClick: () => navigate('/dashboard/subscription') },
        });
        return;
      }
    }

    // Detect mode: if we already have HTML, this is a modification
    const isModify = generatedHtml.length > 100;
    const mode: GenerationMode = isModify ? 'modify' : 'create';

    setPhase('thinking');
    setGenMode(mode);
    setActivePipeline(null);
    setDonePipeline([]);
    setLiveHtml('');
    setLiveChars(0);
    setLiveRequirements('');
    setIsReqStreaming(false);
    rawBufferRef.current = '';
    liveReqBuffer.current = '';
    if (!isModify) { setGeneratedHtml(''); setGeneratedCode(''); setRequirementsDoc(''); }

    const name = trimmed.length > 50 ? trimmed.slice(0, 47) + '…' : trimmed;
    if (!isModify) setProjectName(name);
    const t0 = Date.now();

    addMsg({ role: 'user', content: trimmed });
    addMsg({ role: 'agent', content: '', phase: 'thinking', mode });
    abortRef.current = new AbortController();

    // ── Deduct 30 credits ────────────────────────────────────────────────────
    if (user) {
      const deductResult = await deductCredits();
      if (!deductResult.success) {
        setPhase('idle');
        setMessages(prev => prev.slice(0, -2)); // remove the two messages we just added
        toast.error(deductResult.error ?? 'Failed to deduct credits', {
          action: { label: 'Buy Credits', onClick: () => navigate('/dashboard/subscription') },
        });
        return;
      }
    }

    try {
      let planText   = '';
      let styleBlock = '';
      let htmlOutput = isModify ? generatedHtml : '';

      // Generate a fresh variety seed for every new creation so each output is unique
      const varietySeed = isModify ? null : buildVarietySeed();

      for (const step of PIPELINE) {
        if (abortRef.current.signal.aborted) break;

        setActivePipeline(step.id);
        setPhase('streaming');
        patchLastAgent({ phase: 'streaming', streaming: true, mode });

        // Build prompt — apply variety seed to planner/ui/code phases for new creations
        let userContent: string;
        if (step.id === 'requirements')
          userContent = step.buildPrompt(trimmed, '', isModify ? generatedHtml : '', projectMemory);
        else if (step.id === 'planner')
          userContent = varietySeed
            ? applyVarietyToPrompt(step.buildPrompt(trimmed, '', '', projectMemory), varietySeed)
            : step.buildPrompt(trimmed, '', isModify ? generatedHtml : '', projectMemory);
        else if (step.id === 'ui')
          userContent = varietySeed
            ? applyVarietyToPrompt(step.buildPrompt(trimmed, planText, '', projectMemory), varietySeed)
            : step.buildPrompt(trimmed, planText, isModify ? generatedHtml : '', projectMemory);
        else if (step.id === 'code')
          userContent = varietySeed
            ? applyVarietyToPrompt(step.buildPrompt(trimmed, styleBlock, '', projectMemory), varietySeed)
            : step.buildPrompt(trimmed, styleBlock, isModify ? generatedHtml : '', projectMemory);
        else
          userContent = step.buildPrompt(trimmed, htmlOutput, '', projectMemory);

        const sysPrompt = (step.id === 'code' || step.id === 'fix')
          ? (isModify ? MODIFY_SYSTEM_PROMPT : CORE_SYSTEM_PROMPT)
          : 'You are an expert web designer and requirements analyst. Be concise and precise.';

        // For the requirements phase, stream directly to the Requirements tab
        if (step.id === 'requirements') {
          setIsReqStreaming(true);
          setActiveTab('requirements');
          liveReqBuffer.current = '';
        }

        const result = await runPhase(
          sysPrompt,
          guardPrompt(userContent),
          (chunk) => {
            setLiveChars(c => c + chunk.length);
            if (step.id === 'requirements') {
              liveReqBuffer.current += chunk;
              setLiveRequirements(liveReqBuffer.current);
            } else if (step.id === 'code' || step.id === 'fix') {
              rawBufferRef.current += chunk;
              scheduleLivePreview(rawBufferRef.current);
            }
          },
        );

        if (step.id === 'requirements') {
          setRequirementsDoc(result);
          setLiveRequirements('');
          setIsReqStreaming(false);
        } else if (step.id === 'planner')   planText   = result;
        else if (step.id === 'ui')          styleBlock = extractStyleBlock(result);
        else if (step.id === 'code')        { rawBufferRef.current = result; htmlOutput = result; }
        else if (step.id === 'fix')         { rawBufferRef.current = result; htmlOutput = result; }

        setDonePipeline(prev => [...prev, step.id]);
      }

      if (abortRef.current.signal.aborted) return;

      const finalHtml = extractHtml(htmlOutput || rawBufferRef.current);
      const elapsed   = ((Date.now() - t0) / 1000).toFixed(1) + 's';

      setPhase('rendering');
      patchLastAgent({ phase: 'rendering', streaming: false, mode });
      setActivePipeline(null);
      if (liveHtmlTimer.current) { clearTimeout(liveHtmlTimer.current); liveHtmlTimer.current = null; }

      setTimeout(() => {
        setGeneratedHtml(finalHtml);
        setLiveHtml('');
        setGeneratedCode(finalHtml);
        setActiveTab('preview');
        setPhase('done');
        setMobileTab('preview');

        // Update project memory
        const memory = inferMemory(finalHtml, trimmed);
        if (isModify && projectMemory) {
          memory.version = projectMemory.version + 1;
          memory.pages   = projectMemory.pages;
        }
        setProjectMemory(memory);

        patchLastAgent({
          phase: undefined, streaming: false, isReady: true, mode,
          stats: {
            chars: finalHtml.length,
            lines: finalHtml.split('\n').length,
            size:  humanSize(finalHtml),
            time:  elapsed,
            model: modelUsed || 'gpt-4o',
          },
          snippet: {
            language: 'html', label: 'Preview (first 8 lines)',
            code: finalHtml.split('\n').slice(0, 8).join('\n'),
          },
        });

        // ── Auto-save project to DB ─────────────────────────────────────────
        if (user) {
          if (isModify && savedProjectId) {
            // Update existing project row — don't create a duplicate
            supabase.from('projects')
              .update({ name: projectName, description: trimmed, updated_at: new Date().toISOString() })
              .eq('id', savedProjectId)
              .then(({ error }) => {
                if (error) console.error('Project update failed:', error.message);
              });
          } else if (!isModify) {
            // Insert new project and store the ID for future modifications
            supabase.from('projects')
              .insert({ user_id: user.id, name, description: trimmed, status: 'draft' })
              .select('id')
              .maybeSingle()
              .then(({ data, error }) => {
                if (error) {
                  console.error('Project save failed:', error.message);
                  toast.error('Website generated but could not be saved to Projects.');
                } else if (data?.id) {
                  setSavedProjectId(data.id);
                }
              });
          }
        }
      }, 350);

    } catch (err: unknown) {
      // Always reset requirements streaming so panel doesn't stay stuck
      setIsReqStreaming(false);
      if (abortRef.current?.signal.aborted) return;
      const raw = err instanceof Error ? err.message : String(err);

      const errMsg = raw.includes('429') ? 'Rate limit exceeded. Please try again shortly.'
        : raw.includes('402') ? 'Insufficient AI credits.'
        : raw || 'Unknown error.';
      setPhase('error');
      setActivePipeline(null);
      patchLastAgent({ phase: 'error', streaming: false, error: errMsg });
      toast.error(errMsg);
    }
  }, [phase, generatedHtml, projectMemory, projectName, savedProjectId, modelUsed, user, credits, addMsg, patchLastAgent, runPhase, scheduleLivePreview, deductCredits, getLatestCredits, navigate]);

  const handleStop = () => {
    abortRef.current?.abort();
    setPhase('idle');
    setActivePipeline(null);
    patchLastAgent({ phase: 'error', streaming: false, error: 'Stopped by user.' });
  };

  const handleSend    = () => handleGenerate(input);
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  // ── Export is a paid feature — only pro/enterprise users can copy code ─────
  // Derived from the profile's plan column, set to 'pro' or 'enterprise'
  // when the user completes any Razorpay payment via add_credits_after_payment.
  const hasPaidAccess = user !== null && plan !== 'free';

  const copyCode = () => {
    if (!generatedCode) return;
    if (!hasPaidAccess) { setShowExportGate(true); return; }
    navigator.clipboard.writeText(generatedCode);
    setCodeCopied(true); toast.success('Code copied!');
    setTimeout(() => setCodeCopied(false), 2000);
  };
  const openInNewTab = () => {
    if (!generatedHtml) return;
    if (!hasPaidAccess) { setShowExportGate(true); return; }
    window.open(URL.createObjectURL(new Blob([generatedHtml], { type: 'text/html' })), '_blank');
  };
  const resetChat = () => {
    setGeneratedHtml(''); setGeneratedCode(''); setLiveHtml('');
    setRequirementsDoc(''); setLiveRequirements(''); setIsReqStreaming(false);
    setProjectMemory(null); setProjectName('New Chat');
    setSavedProjectId(null);
    setActiveTab('requirements');
    navigate('/dashboard/chat');
  };

  const isGenerating = phase === 'thinking' || phase === 'streaming' || phase === 'rendering';
  const hasExistingSite = generatedHtml.length > 100;
  const suggestions = hasExistingSite ? MODIFY_PROMPTS : CREATE_PROMPTS;

  // ── Chat panel ──────────────────────────────────────────────────────────────
  const ChatPanel = (
    <div className="flex flex-col h-full min-h-0">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border shrink-0 bg-card">
        <div className="h-7 w-7 rounded-full bg-primary/15 border border-primary/25 flex items-center justify-center shrink-0">
          <Sparkles className="h-3.5 w-3.5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate">{projectName}</p>
          <p className="text-[11px] text-muted-foreground flex items-center gap-1">
            {hasExistingSite ? (
              <><Pencil className="h-2.5 w-2.5" /> Modification mode</>
            ) : (
              <>5-phase pipeline · OpenRouter</>
            )}
            {projectMemory && (
              <Badge variant="outline" className="text-[9px] px-1 py-0 h-3.5 ml-1">
                v{projectMemory.version}
              </Badge>
            )}
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 ml-1" />
          </p>
        </div>

        {/* ── Credits badge ─────────────────────────────────────────────── */}
        {user && (
          <button
            onClick={() => navigate('/dashboard/subscription')}
            title="Credits – click to buy more"
            className="flex items-center gap-1 px-2 py-1 rounded-lg border border-border bg-muted/30 hover:bg-muted hover:border-primary/40 transition-colors shrink-0"
          >
            <Coins className="h-3 w-3 text-primary" />
            {creditsLoading ? (
              <span className="text-[11px] text-muted-foreground">…</span>
            ) : (
              <span className={`text-[11px] font-semibold tabular-nums ${(credits ?? 0) < 30 ? 'text-destructive' : 'text-foreground'}`}>
                {(credits ?? 0).toLocaleString()}
              </span>
            )}
            {!creditsLoading && (credits ?? 0) < 30 && (
              <AlertCircle className="h-3 w-3 text-destructive" />
            )}
          </button>
        )}

        {hasExistingSite && (
          <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" title="Start fresh"
            onClick={resetChat}>
            <RotateCcw className="h-3.5 w-3.5" />
          </Button>
        )}
        <Button variant="ghost" size="sm" className="gap-1.5 text-xs shrink-0 h-7"
          onClick={() => navigate('/dashboard/chat')}>
          <Plus className="h-3 w-3" /><span className="hidden sm:inline">New</span>
        </Button>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-4">
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <ChatBubble key={msg.id} msg={msg}
              activePipeline={msg.streaming ? activePipeline : null}
              donePipeline={msg.streaming ? donePipeline : []}
              liveChars={msg.streaming ? liveChars : 0}
              mode={genMode} />
          ))}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {!isGenerating && (
        <div className="px-4 pb-2 flex flex-wrap gap-1.5">
          {suggestions.map(p => (
            <button key={p} onClick={() => handleGenerate(p)}
              className="max-w-[180px] text-xs px-3 py-1 rounded-full border border-border bg-muted/30 hover:bg-muted hover:border-primary/40 text-muted-foreground hover:text-foreground transition-colors text-left truncate"
              title={p}>
              {p.length > 32 ? p.slice(0, 30) + '…' : p}
            </button>
          ))}
        </div>
      )}

      <div className="px-4 py-3 border-t border-border shrink-0 bg-card space-y-2">
        {hasExistingSite && !isGenerating && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/5 border border-primary/20 text-xs text-primary">
            <Pencil className="h-3 w-3 shrink-0" />
            <span>Modification mode — describe changes to apply to your existing site</span>
          </div>
        )}
        {!hasExistingSite && input.trim().length > 3 && (() => {
          const ctx = detectWebsiteContext(input);
          return ctx.type !== 'general' ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/5 border border-primary/20 text-xs text-primary">
              <Sparkles className="h-3 w-3 shrink-0" />
              <span>Detected: <strong>{ctx.industry}</strong> — optimising design, colors &amp; sections for {ctx.audience}</span>
            </div>
          ) : null;
        })()}
        <div className="flex gap-2 items-end">
          <Textarea value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={hasExistingSite
              ? 'Describe changes… e.g. "add a dark pricing section with 3 tiers"'
              : 'Describe your website… e.g. SaaS landing page for a design tool'}
            className="min-h-[44px] max-h-28 resize-none flex-1 text-sm" rows={1}
            disabled={isGenerating} />
          {isGenerating ? (
            <Button onClick={handleStop} size="icon"
              className="h-11 w-11 shrink-0 bg-destructive hover:bg-destructive/90">
              <StopCircle className="h-4 w-4" />
            </Button>
          ) : (
            <Button onClick={handleSend} disabled={!input.trim()} size="icon" className="h-11 w-11 shrink-0">
              <Send className="h-4 w-4" />
            </Button>
          )}
        </div>
        <p className="text-[10px] text-muted-foreground text-center flex items-center justify-center gap-1 flex-wrap">
          <kbd className="px-1 py-0.5 rounded border border-border bg-muted font-mono text-[9px]">Enter</kbd> send &nbsp;·&nbsp;
          <kbd className="px-1 py-0.5 rounded border border-border bg-muted font-mono text-[9px]">Shift+Enter</kbd> new line
          {user && (
            <>
              &nbsp;·&nbsp;
              <Coins className="h-2.5 w-2.5 text-primary inline-block" />
              <span className={`font-semibold ${(credits ?? 0) < 30 ? 'text-destructive' : ''}`}>
                {creditsLoading ? '…' : (credits ?? 0).toLocaleString()}
              </span>
              <span>credits · 30 per generation</span>
            </>
          )}
        </p>
      </div>
    </div>
  );

  // ── Preview toolbar ─────────────────────────────────────────────────────────
  const PreviewToolbar = (
    <div className="flex items-center gap-2 px-4 py-2 border-b border-border shrink-0 bg-card flex-wrap">
      {/* Viewport controls – only relevant on preview tab */}
      {activeTab === 'preview' && (
        <>
          <div className="flex items-center gap-0.5 border border-border rounded-lg p-0.5 bg-muted/20">
            {([
              { mode: 'desktop' as ViewportMode, Icon: Monitor,    label: 'Desktop' },
              { mode: 'tablet'  as ViewportMode, Icon: Tablet,     label: 'Tablet'  },
              { mode: 'mobile'  as ViewportMode, Icon: Smartphone, label: 'Mobile'  },
            ] as const).map(({ mode, Icon, label }) => (
              <button key={mode} onClick={() => setViewport(mode)}
                className={cn('flex items-center gap-1 px-2 py-1 rounded-md text-xs transition-colors',
                  viewport === mode ? 'bg-background text-foreground shadow-sm font-medium' : 'text-muted-foreground hover:text-foreground')}>
                <Icon className="h-3 w-3" /><span className="hidden lg:inline">{label}</span>
              </button>
            ))}
          </div>
          <Separator orientation="vertical" className="h-4" />
        </>
      )}

      {/* Tab switcher: Requirements · Preview · Code */}
      <div className="flex gap-0.5">
        {([
          { id: 'requirements' as PreviewTab, Icon: FileText, label: 'Requirements' },
          { id: 'preview'      as PreviewTab, Icon: Eye,      label: 'Preview'      },
          { id: 'code'         as PreviewTab, Icon: Code2,    label: 'Code'         },
        ]).map(({ id, Icon, label }) => (
          <button key={id} onClick={() => setActiveTab(id)}
            className={cn(
              'flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors relative',
              activeTab === id ? 'bg-muted text-foreground' : 'text-muted-foreground hover:text-foreground',
            )}>
            <Icon className="h-3 w-3" />
            <span className="hidden sm:inline">{label}</span>
            {/* dot indicator when requirements is streaming */}
            {id === 'requirements' && isReqStreaming && (
              <span className="absolute top-0.5 right-0.5 h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
            )}
          </button>
        ))}
      </div>

      {isGenerating && activePipeline && (
        <Badge variant="secondary" className="text-[10px] px-2 h-5 gap-1 animate-pulse capitalize">
          <Zap className="h-2.5 w-2.5" />
          {activePipeline === 'requirements' ? 'Requirements' : activePipeline}
        </Badge>
      )}
      {projectMemory && !isGenerating && (
        <Badge variant="outline" className="text-[10px] px-2 h-5 gap-1">
          v{projectMemory.version} · {projectMemory.designSystem.theme}
        </Badge>
      )}
      <div className="flex-1" />
      <Button
        variant="ghost" size="icon"
        className={cn('h-7 w-7 relative', !hasPaidAccess && 'text-muted-foreground')}
        onClick={copyCode}
        disabled={!generatedCode}
        title={hasPaidAccess ? 'Copy code' : 'Upgrade to copy code'}
      >
        {codeCopied
          ? <CheckCheck className="h-3.5 w-3.5 text-primary" />
          : <Copy className="h-3.5 w-3.5" />}
        {!hasPaidAccess && generatedCode && (
          <Lock className="h-2.5 w-2.5 absolute -bottom-0.5 -right-0.5 text-amber-500" />
        )}
      </Button>
      <Button
        variant="ghost" size="icon"
        className={cn('h-7 w-7 relative', !hasPaidAccess && 'text-muted-foreground')}
        onClick={openInNewTab}
        disabled={!generatedHtml}
        title={hasPaidAccess ? 'Open in new tab' : 'Upgrade to open in new tab'}
      >
        <ExternalLink className="h-3.5 w-3.5" />
        {!hasPaidAccess && generatedHtml && (
          <Lock className="h-2.5 w-2.5 absolute -bottom-0.5 -right-0.5 text-amber-500" />
        )}
      </Button>
    </div>
  );

  const PreviewContent = (
    <div className="flex-1 min-h-0 overflow-hidden flex flex-col">
      {activeTab === 'requirements' ? (
        <RequirementsPanel
          content={isReqStreaming ? liveRequirements : requirementsDoc}
          isStreaming={isReqStreaming}
          isModify={genMode === 'modify'}
        />
      ) : activeTab === 'preview' ? (
        <BrowserFrame html={generatedHtml} liveHtml={liveHtml} viewport={viewport}
          isGenerating={isGenerating} isDragging={isDragging.current}
          activePhase={activePipeline} mode={genMode} />
      ) : generatedCode ? (
        <pre className="flex-1 overflow-auto p-4 text-xs font-mono leading-relaxed text-foreground whitespace-pre-wrap break-words bg-background">
          {generatedCode}
        </pre>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center gap-3 text-muted-foreground">
          <FileCode2 className="h-10 w-10 opacity-25" />
          <p className="text-sm">Generated code will appear here</p>
        </div>
      )}
    </div>
  );

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <DashboardLayout fullHeight>
      <PageMeta title="AI Builder - SiteGenie" noIndex />
      {/* Desktop: resizable split */}
      <div ref={containerRef}
        className="hidden md:flex flex-1 min-h-0 overflow-hidden select-none">
        <div className="shrink-0 border-r border-border bg-background flex flex-col h-full overflow-hidden"
          style={{ width: `${splitPct}%`, minWidth: 260 }}>
          {ChatPanel}
        </div>
        <div onMouseDown={onDividerMouseDown}
          className="w-1.5 shrink-0 flex items-center justify-center bg-border/40 hover:bg-primary/30 cursor-col-resize transition-colors group z-10"
          title="Drag to resize">
          <GripVertical className="h-5 w-5 text-muted-foreground/50 group-hover:text-primary transition-colors pointer-events-none" />
        </div>
        <div className="flex-1 min-w-0 flex flex-col bg-background overflow-hidden">
          {PreviewToolbar}
          {PreviewContent}
        </div>
      </div>

      {/* Mobile: tabbed */}
      <div className="flex md:hidden flex-1 min-h-0 flex-col overflow-hidden">
        <div className="flex border-b border-border bg-card shrink-0">
          {(['chat', 'preview'] as const).map(tab => (
            <button key={tab} onClick={() => setMobileTab(tab)}
              className={cn('flex-1 py-2.5 text-sm font-medium flex items-center justify-center gap-2 transition-colors',
                mobileTab === tab ? 'text-primary border-b-2 border-primary bg-primary/5' : 'text-muted-foreground')}>
              {tab === 'chat'
                ? <><Bot className="h-4 w-4" /> Chat</>
                : <><Eye className="h-4 w-4" /> Preview</>}
              {tab === 'preview' && isGenerating && (
                <Badge variant="secondary" className="text-[9px] px-1 py-0 h-4">Live</Badge>
              )}
            </button>
          ))}
        </div>
        <div className="flex-1 min-h-0 overflow-hidden">
          {mobileTab === 'chat'
            ? <div className="h-full flex flex-col">{ChatPanel}</div>
            : (
              <div className="h-full flex flex-col">
                <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-card shrink-0">
                  <div className="flex gap-0.5 border border-border rounded-lg p-0.5 bg-muted/20">
                    {([{ mode: 'desktop' as ViewportMode, Icon: Monitor }, { mode: 'mobile' as ViewportMode, Icon: Smartphone }] as const)
                      .map(({ mode, Icon }) => (
                        <button key={mode} onClick={() => setViewport(mode)}
                          className={cn('p-1.5 rounded-md transition-colors',
                            viewport === mode ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground')}>
                          <Icon className="h-3 w-3" />
                        </button>
                      ))}
                  </div>
                  <div className="flex-1" />
                  <Button
                    variant="ghost" size="icon"
                    className={cn('h-7 w-7 relative', !hasPaidAccess && 'text-muted-foreground')}
                    onClick={copyCode}
                    disabled={!generatedCode}
                  >
                    {codeCopied ? <CheckCheck className="h-3.5 w-3.5 text-primary" /> : <Copy className="h-3.5 w-3.5" />}
                    {!hasPaidAccess && generatedCode && (
                      <Lock className="h-2.5 w-2.5 absolute -bottom-0.5 -right-0.5 text-amber-500" />
                    )}
                  </Button>
                  <Button
                    variant="ghost" size="icon"
                    className={cn('h-7 w-7 relative', !hasPaidAccess && 'text-muted-foreground')}
                    onClick={openInNewTab}
                    disabled={!generatedHtml}
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                    {!hasPaidAccess && generatedHtml && (
                      <Lock className="h-2.5 w-2.5 absolute -bottom-0.5 -right-0.5 text-amber-500" />
                    )}
                  </Button>
                </div>
                <BrowserFrame html={generatedHtml} liveHtml={liveHtml} viewport={viewport}
                  isGenerating={isGenerating} isDragging={false}
                  activePhase={activePipeline} mode={genMode} />
              </div>
            )
          }
        </div>
      </div>

      {/* ── Export Gate Dialog (free users) ───────────────────────────────── */}
      <Dialog open={showExportGate} onOpenChange={setShowExportGate}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md text-center">
          <DialogHeader>
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-amber-500/10 border border-amber-500/30">
              <Crown className="h-7 w-7 text-amber-500" />
            </div>
            <DialogTitle className="text-xl font-bold text-balance">
              Export is a Premium Feature
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground text-pretty mt-1">
              Upgrade to any paid plan to copy your generated code, open it in a new tab, and
              download your websites. Free accounts can generate and preview — but exporting
              requires a subscription.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-2 space-y-2">
            <div className="rounded-lg border border-border bg-muted/30 p-3 text-left space-y-1.5 text-sm">
              {[
                { icon: Copy,        label: 'Copy full source code' },
                { icon: ExternalLink,label: 'Open website in new tab' },
                { icon: Code2,       label: 'View & edit generated HTML/CSS/JS' },
                { icon: Sparkles,    label: 'Unlimited generations & modifications' },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-2 text-foreground">
                  <Icon className="h-4 w-4 text-primary shrink-0" />
                  <span>{label}</span>
                </div>
              ))}
            </div>
            <Button
              className="w-full gap-2 font-semibold"
              onClick={() => { setShowExportGate(false); navigate('/dashboard/subscription'); }}
            >
              <Crown className="h-4 w-4" />
              Upgrade Now
            </Button>
            <Button variant="ghost" className="w-full text-muted-foreground"
              onClick={() => setShowExportGate(false)}>
              Maybe later
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
};

export default AgentChatPage;
