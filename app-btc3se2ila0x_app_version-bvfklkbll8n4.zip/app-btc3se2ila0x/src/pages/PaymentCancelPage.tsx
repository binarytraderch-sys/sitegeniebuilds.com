import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { XCircle, ArrowLeft, RefreshCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';

const PaymentCancelPage: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md text-center space-y-6"
      >
        <div className="h-20 w-20 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
          <XCircle className="h-10 w-10 text-destructive" />
        </div>

        <div>
          <h1 className="text-2xl font-bold">Payment Cancelled</h1>
          <p className="text-muted-foreground text-sm mt-2 text-pretty">
            Your payment was cancelled and you have not been charged.
            You can go back and try again whenever you&apos;re ready.
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <Button asChild className="bg-primary hover:bg-primary/90">
            <Link to="/dashboard/subscription">
              <RefreshCcw className="h-4 w-4 mr-2" /> Try Again
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/dashboard">
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to Dashboard
            </Link>
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default PaymentCancelPage;
