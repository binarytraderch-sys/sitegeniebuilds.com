import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { CheckCircle2, ArrowRight, ReceiptText, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
// @ts-ignore
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface VerifyResult {
  verified: boolean;
  status: string;
  amount: number | null;
  currency: string | null;
  customerEmail: string | null;
  customerName: string | null;
  sessionId: string;
}

const PaymentSuccessPage: React.FC = () => {
  const [params] = useSearchParams();
  const sessionId = params.get('session_id');
  const [loading, setLoading] = useState(true);
  const [result, setResult] = useState<VerifyResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!sessionId) {
      setError('No session ID found. Please contact support.');
      setLoading(false);
      return;
    }

    (async () => {
      try {
        const { data, error: fnErr } = await supabase.functions.invoke('verify-stripe-payment', {
          body: { sessionId },
        });
        if (fnErr) {
          const msg = await fnErr?.context?.text();
          throw new Error(msg || fnErr.message);
        }
        if (data?.code === 'SUCCESS') {
          setResult(data.data);
        } else {
          throw new Error(data?.message || 'Verification failed');
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Verification failed';
        setError(msg);
        toast.error(msg);
      } finally {
        setLoading(false);
      }
    })();
  }, [sessionId]);

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md text-center"
      >
        {loading ? (
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
            <p className="text-muted-foreground">Verifying your payment...</p>
          </div>
        ) : error ? (
          <div className="space-y-4">
            <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
              <ReceiptText className="h-8 w-8 text-destructive" />
            </div>
            <h1 className="text-2xl font-bold">Verification Failed</h1>
            <p className="text-muted-foreground text-sm">{error}</p>
            <Button asChild className="bg-primary hover:bg-primary/90">
              <Link to="/dashboard/subscription">Go to Subscription</Link>
            </Button>
          </div>
        ) : result?.verified ? (
          <div className="space-y-6">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
              className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto"
            >
              <CheckCircle2 className="h-10 w-10 text-primary" />
            </motion.div>
            <div>
              <h1 className="text-2xl font-bold">Payment Successful!</h1>
              <p className="text-muted-foreground text-sm mt-2">
                Your subscription has been activated. Welcome to the next level!
              </p>
            </div>

            <Card>
              <CardContent className="p-5 text-left space-y-3">
                {result.customerName && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Name</span>
                    <span className="font-medium">{result.customerName}</span>
                  </div>
                )}
                {result.customerEmail && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Email</span>
                    <span className="font-medium">{result.customerEmail}</span>
                  </div>
                )}
                {result.amount != null && result.currency && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Amount Paid</span>
                    <span className="font-semibold text-primary">
                      {new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: result.currency,
                      }).format(result.amount / 100)}
                    </span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Order</span>
                  <span className="font-mono text-xs">{result.sessionId.slice(-12)}</span>
                </div>
              </CardContent>
            </Card>

            <div className="flex flex-col gap-3">
              <Button asChild className="bg-primary hover:bg-primary/90">
                <Link to="/dashboard">
                  Go to Dashboard <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
              </Button>
              <Button asChild variant="outline">
                <Link to="/dashboard/subscription">View Subscription</Link>
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <h1 className="text-2xl font-bold">Payment Pending</h1>
            <p className="text-muted-foreground text-sm">
              Your payment is being processed. Please check back shortly.
            </p>
            <Button asChild variant="outline">
              <Link to="/dashboard/subscription">View Subscription</Link>
            </Button>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default PaymentSuccessPage;
