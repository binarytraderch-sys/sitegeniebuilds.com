import React from 'react';
import HeroSection from '@/components/landing/HeroSection';
import TechStack from '@/components/landing/TechStack';
import HowItWorks from '@/components/landing/HowItWorks';
import Features from '@/components/landing/Features';
import DemoSection from '@/components/landing/DemoSection';
import Pricing from '@/components/landing/Pricing';
import Testimonials from '@/components/landing/Testimonials';
import FAQ from '@/components/landing/FAQ';
import Newsletter from '@/components/landing/Newsletter';
import Contact from '@/components/landing/Contact';
import PageMeta from '@/components/common/PageMeta';

const HomePage: React.FC = () => {
  return (
    <>
      <PageMeta
        title="SiteGenie - AI Website Builder"
        description="Generate beautiful modern websites instantly using AI prompts with SiteGenie AI Website Builder."
        canonical="https://sitegeniebuild.com/"
        ogImage="https://sitegeniebuild.com/og-image.png"
      />
      <HeroSection />
      <TechStack />
      <HowItWorks />
      <Features />
      <DemoSection />
      <Pricing />
      <Testimonials />
      <FAQ />
      <Newsletter />
      <Contact />
    </>
  );
};

export default HomePage;