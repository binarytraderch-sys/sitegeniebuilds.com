import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'motion/react';
import {
  CreditCard, Check, Zap, Building2, Star, RefreshCw,
  Coins, TrendingUp, History, Sparkles, AlertCircle, Gift,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import PageMeta from '@/components/common/PageMeta';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
// @ts-ignore
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useCredits } from '@/hooks/use-credits';
import { toast } from 'sonner';
import DashboardLayout from '@/components/layout/DashboardLayout';

// ── Razorpay global type ───────────────────────────────────────────────────────
declare global {
  interface Window {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    Razorpay: any;
  }
}

// ── Plan config ───────────────────────────────────────────────────────────────
interface CreditPlan {
  key: string;
  name: string;
  priceRupees: number;
  credits: number;
  description: string;
  icon: React.ReactNode;
  badge?: string;
  features: string[];
}

const CREDIT_PLANS: CreditPlan[] = [
  {
    key: 'beginner',
    name: 'Beginner',
    priceRupees: 100,
    credits: 200,
    description: 'Perfect for trying out SiteGenie.',
    icon: <Sparkles className="h-5 w-5" />,
    features: ['200 credits', '~6 website generations', 'All AI models included', 'Community support'],
  },
  {
    key: 'starter',
    name: 'Starter',
    priceRupees: 500,
    credits: 1000,
    description: 'Great for individuals getting started.',
    icon: <Star className="h-5 w-5" />,
    features: ['1,000 credits', '~33 website generations', 'All AI models included', 'Email support'],
  },
  {
    key: 'professional',
    name: 'Professional',
    priceRupees: 1000,
    credits: 2000,
    description: 'For professionals who build frequently.',
    icon: <Zap className="h-5 w-5" />,
    badge: 'Best Value',
    features: ['2,000 credits', '~66 website generations', 'All AI models included', 'Priority support', 'Modification mode'],
  },
  {
    key: 'enterprise',
    name: 'Enterprise',
    priceRupees: 5000,
    credits: 10000,
    description: 'For agencies and high-volume builders.',
    icon: <Building2 className="h-5 w-5" />,
    features: ['10,000 credits', '~333 website generations', 'All AI models included', 'Dedicated support', 'Custom branding'],
  },
];

// ── Credit transaction type ────────────────────────────────────────────────────
interface CreditTx {
  id: string;
  type: 'topup' | 'deduction';
  amount: number;
  description: string;
  created_at: string;
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' });
}

function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) { resolve(true); return; }
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload  = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

const RZP_KEY_ID = 'rzp_live_St30tyoOfYZkyP';

const SubscriptionPage: React.FC = () => {
  const { user, profile } = useAuth();
  const { credits, loading: creditsLoading, fetchCredits, addCredits, claimDailyCredits, dailyClaimed } = useCredits();
  const [transactions, setTransactions] = useState<CreditTx[]>([]);
  const [txLoading, setTxLoading]       = useState(true);
  const [payLoading, setPayLoading]     = useState<string | null>(null);
  const [dailyLoading, setDailyLoading] = useState(false);

  const fetchTransactions = useCallback(async () => {
    if (!user) return;
    setTxLoading(true);
    const { data } = await supabase
      .from('credit_transactions')
      .select('id, type, amount, description, created_at')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(20);
    setTransactions(Array.isArray(data) ? data : []);
    setTxLoading(false);
  }, [user]);

  useEffect(() => { fetchTransactions(); }, [fetchTransactions]);

  const handleBuy = async (plan: CreditPlan) => {
    if (!user) { toast.error('Please log in first'); return; }
    setPayLoading(plan.key);

    const loaded = await loadRazorpayScript();
    if (!loaded) {
      toast.error('Failed to load Razorpay. Check your internet connection.');
      setPayLoading(null);
      return;
    }

    const options = {
      key:         RZP_KEY_ID,
      amount:      plan.priceRupees * 100,
      currency:    'INR',
      name:        'SiteGenie',
      description: `${plan.name} – ${plan.credits.toLocaleString()} credits`,
      image:       'https://avatars.githubusercontent.com/u/139895814?s=200&v=4',
      prefill: {
        email: profile?.email ?? user.email ?? '',
        name:  profile?.full_name ?? '',
      },
      theme: { color: '#7c3aed' },
      handler: async (response: {
        razorpay_payment_id: string;
        razorpay_order_id?: string;
        razorpay_signature?: string;
      }) => {
        // Add credits via secure DB RPC
        const result = await addCredits(
          plan.credits,
          `${plan.name} – ₹${plan.priceRupees}/month`,
          response.razorpay_payment_id,
          response.razorpay_order_id ?? '',
        );

        if (result.success) {
          toast.success(`✅ Payment successful! ${plan.credits.toLocaleString()} credits added. Total: ${result.total?.toLocaleString()}`);
          fetchTransactions();
        } else {
          toast.error(result.error ?? 'Credits could not be added. Contact support with payment ID: ' + response.razorpay_payment_id);
        }
        setPayLoading(null);
      },
      modal: {
        ondismiss: () => { setPayLoading(null); },
      },
    };

    const rzp = new window.Razorpay(options);
    rzp.on('payment.failed', (resp: { error: { description: string } }) => {
      toast.error(`Payment failed: ${resp.error.description}`);
      setPayLoading(null);
    });
    rzp.open();
  };

  const handleClaimDaily = async () => {
    setDailyLoading(true);
    const result = await claimDailyCredits();
    if (result.success) {
      toast.success('🎁 30 free daily credits claimed! Come back tomorrow for more.');
      fetchTransactions();
    } else if (result.already_claimed) {
      toast.info('You already claimed your free credits today. Come back tomorrow!');
    } else {
      toast.error(result.error ?? 'Failed to claim daily credits');
    }
    setDailyLoading(false);
  };

  return (
    <DashboardLayout>
      <PageMeta title="Credits & Plans - SiteGenie" noIndex />
      <div className="space-y-8 max-w-5xl">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2 text-balance">
            <Coins className="h-6 w-6 text-primary" /> Credits & Plans
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Buy credits to generate websites. Each generation costs 30 credits.
          </p>
        </div>

        {/* Credits balance card */}
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-primary/15 flex items-center justify-center text-primary shrink-0">
                <Sparkles className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Available Credits</p>
                {creditsLoading ? (
                  <Skeleton className="h-8 w-24 bg-muted mt-1" />
                ) : (
                  <p className="text-3xl font-bold text-primary">{(credits ?? 0).toLocaleString()}</p>
                )}
              </div>
            </div>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground bg-background rounded-lg px-3 py-2 border border-border">
                <Zap className="h-3.5 w-3.5 text-primary shrink-0" />
                <span>30 credits per generation</span>
              </div>
              {!creditsLoading && (credits ?? 0) < 30 && (
                <div className="flex items-center gap-1.5 text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2 border border-destructive/20">
                  <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                  <span>Not enough credits — top up below</span>
                </div>
              )}
              <Button variant="outline" size="sm" onClick={fetchCredits} className="gap-1.5 shrink-0">
                <RefreshCw className="h-3.5 w-3.5" /> Refresh
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Daily Free Credits Banner */}
        <Card className={`border-2 transition-colors ${dailyClaimed ? 'border-border bg-muted/20' : 'border-primary/40 bg-gradient-to-r from-primary/5 to-primary/10'}`}>
          <CardContent className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className={`h-11 w-11 rounded-xl flex items-center justify-center shrink-0 ${dailyClaimed ? 'bg-muted text-muted-foreground' : 'bg-primary/15 text-primary'}`}>
                <Gift className="h-5 w-5" />
              </div>
              <div>
                <p className="font-semibold text-sm">Daily Free Credits</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {dailyClaimed
                    ? 'You\'ve claimed your 30 free credits today — come back tomorrow!'
                    : 'Claim 30 free credits every day, just for logging in.'}
                </p>
              </div>
            </div>
            <Button
              size="sm"
              onClick={handleClaimDaily}
              disabled={dailyClaimed || dailyLoading}
              className="shrink-0 gap-1.5"
              variant={dailyClaimed ? 'outline' : 'default'}
            >
              {dailyLoading ? (
                <RefreshCw className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Gift className="h-3.5 w-3.5" />
              )}
              {dailyClaimed ? 'Claimed Today ✓' : 'Claim 30 Free Credits'}
            </Button>
          </CardContent>
        </Card>

        {/* Plans */}
        <div>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" /> Buy Credits
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {CREDIT_PLANS.map((plan, i) => (
              <motion.div key={plan.key}
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="h-full"
              >
                <Card className={`h-full flex flex-col relative ${plan.badge ? 'border-primary/50 shadow-md' : ''}`}>
                  {plan.badge && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground shadow-sm">{plan.badge}</Badge>
                    </div>
                  )}
                  <CardHeader className="pb-4">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="h-8 w-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                        {plan.icon}
                      </div>
                      <CardTitle className="text-base">{plan.name}</CardTitle>
                    </div>
                    <div className="flex items-end gap-1">
                      <span className="text-3xl font-bold">₹{plan.priceRupees.toLocaleString('en-IN')}</span>
                      <span className="text-muted-foreground text-sm mb-1">/month</span>
                    </div>
                    <div className="flex items-center gap-1.5 mt-1">
                      <Coins className="h-3.5 w-3.5 text-primary" />
                      <span className="text-sm font-semibold text-primary">{plan.credits.toLocaleString()} credits</span>
                    </div>
                    <CardDescription className="text-pretty mt-1">{plan.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col">
                    <ul className="space-y-2 flex-1">
                      {plan.features.map((f) => (
                        <li key={f} className="flex items-start gap-2 text-sm">
                          <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                    <Button
                      onClick={() => handleBuy(plan)}
                      disabled={payLoading !== null}
                      variant={plan.badge ? 'default' : 'outline'}
                      className="mt-6 w-full"
                    >
                      {payLoading === plan.key ? (
                        <><RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Opening…</>
                      ) : (
                        <><CreditCard className="h-4 w-4 mr-2" /> Buy {plan.credits.toLocaleString()} Credits</>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1.5">
            <span className="h-4 w-4 inline-flex items-center justify-center rounded bg-muted">🔒</span>
            Secured by Razorpay · UPI, Cards, Net Banking, Wallets accepted
          </p>
        </div>

        {/* Transaction history */}
        <div>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <History className="h-5 w-5 text-primary" /> Transaction History
          </h2>
          <Card>
            {txLoading ? (
              <CardContent className="p-4 space-y-3">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 bg-muted rounded" />
                ))}
              </CardContent>
            ) : transactions.length === 0 ? (
              <CardContent className="p-8 text-center">
                <CreditCard className="h-8 w-8 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground text-sm">No transactions yet. Buy credits to get started!</p>
              </CardContent>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border text-left">
                      <th className="px-4 py-3 text-xs font-medium text-muted-foreground uppercase whitespace-nowrap">Date</th>
                      <th className="px-4 py-3 text-xs font-medium text-muted-foreground uppercase whitespace-nowrap">Description</th>
                      <th className="px-4 py-3 text-xs font-medium text-muted-foreground uppercase whitespace-nowrap">Credits</th>
                      <th className="px-4 py-3 text-xs font-medium text-muted-foreground uppercase whitespace-nowrap">Type</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((tx) => (
                      <tr key={tx.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3 text-sm whitespace-nowrap">{formatDate(tx.created_at)}</td>
                        <td className="px-4 py-3 text-sm">{tx.description}</td>
                        <td className="px-4 py-3 text-sm font-semibold whitespace-nowrap">
                          <span className={tx.type === 'topup' ? 'text-primary' : 'text-muted-foreground'}>
                            {tx.type === 'topup' ? '+' : '-'}{tx.amount.toLocaleString()}
                          </span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Badge
                            variant={tx.type === 'topup' ? 'default' : 'secondary'}
                            className={`text-xs capitalize ${tx.type === 'topup' ? 'bg-primary/10 text-primary border-primary/20' : ''}`}
                          >
                            {tx.type === 'topup' ? 'Top-up' : 'Used'}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default SubscriptionPage;
