import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import {
  Plus, Search, Grid3X3, List, MoreHorizontal, Globe, FileText,
  Archive, Trash2, Copy, Eye, FolderOpen, Pencil, MessageSquareCode, LayoutDashboard,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import PageMeta from '@/components/common/PageMeta';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
// @ts-ignore
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import type { Project, ProjectStatus } from '@/types/types';
import { toast } from 'sonner';
import DashboardLayout from '@/components/layout/DashboardLayout';

type ViewMode = 'grid' | 'list';
type FilterStatus = 'all' | ProjectStatus;

const STATUS_CONFIG: Record<ProjectStatus, { label: string; variant: 'default' | 'secondary' | 'outline'; icon: React.ReactNode }> = {
  published: { label: 'Published', variant: 'default', icon: <Globe className="h-3 w-3" /> },
  draft: { label: 'Draft', variant: 'secondary', icon: <FileText className="h-3 w-3" /> },
  archived: { label: 'Archived', variant: 'outline', icon: <Archive className="h-3 w-3" /> },
};

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function StatCard({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <Card className="h-full">
      <CardContent className="p-5 flex items-center gap-4">
        <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary shrink-0">
          {icon}
        </div>
        <div>
          <p className="text-2xl font-bold">{value}</p>
          <p className="text-sm text-muted-foreground">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

const ProjectsPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<ViewMode>('grid');
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<FilterStatus>('all');

  // Create dialog
  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');

  // Edit dialog
  const [editOpen, setEditOpen] = useState(false);
  const [editProject, setEditProject] = useState<Project | null>(null);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editing, setEditing] = useState(false);

  // Delete dialog
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Project | null>(null);
  const [deleting, setDeleting] = useState(false);

  const fetchProjects = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .eq('user_id', user.id)
      .order('updated_at', { ascending: false });
    if (error) {
      toast.error('Failed to load projects.');
    } else {
      setProjects(Array.isArray(data) ? data : []);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => { fetchProjects(); }, [fetchProjects]);

  const filtered = projects.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || p.status === filter;
    return matchSearch && matchFilter;
  });

  const stats = {
    total: projects.length,
    published: projects.filter((p) => p.status === 'published').length,
    drafts: projects.filter((p) => p.status === 'draft').length,
  };

  // Create
  const handleCreate = async () => {
    if (!user || !newName.trim()) return;
    setCreating(true);
    const { error } = await supabase.from('projects').insert({
      user_id: user.id,
      name: newName.trim(),
      description: newDesc.trim() || null,
      status: 'draft',
    });
    setCreating(false);
    if (error) { toast.error('Failed to create project.'); return; }
    toast.success('Project created!');
    setCreateOpen(false);
    setNewName(''); setNewDesc('');
    fetchProjects();
  };

  // Edit
  const openEdit = (p: Project) => {
    setEditProject(p); setEditName(p.name); setEditDesc(p.description ?? '');
    setEditOpen(true);
  };
  const handleEdit = async () => {
    if (!editProject || !editName.trim()) return;
    setEditing(true);
    const { error } = await supabase.from('projects')
      .update({ name: editName.trim(), description: editDesc.trim() || null })
      .eq('id', editProject.id);
    setEditing(false);
    if (error) { toast.error('Failed to update project.'); return; }
    toast.success('Project updated!');
    setEditOpen(false);
    fetchProjects();
  };

  // Duplicate
  const handleDuplicate = async (p: Project) => {
    if (!user) return;
    const { error } = await supabase.from('projects').insert({
      user_id: user.id,
      name: `${p.name} (Copy)`,
      description: p.description,
      status: 'draft',
    });
    if (error) { toast.error('Failed to duplicate project.'); return; }
    toast.success('Project duplicated!');
    fetchProjects();
  };

  // Delete
  const openDelete = (p: Project) => { setDeleteTarget(p); setDeleteOpen(true); };
  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    const { error } = await supabase.from('projects').delete().eq('id', deleteTarget.id);
    setDeleting(false);
    if (error) { toast.error('Failed to delete project.'); return; }
    toast.success('Project deleted.');
    setDeleteOpen(false);
    fetchProjects();
  };

  const ProjectActions = ({ project }: { project: Project }) => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => navigate(`/dashboard/chat?project=${project.id}`)}>
          <MessageSquareCode className="h-4 w-4 mr-2" /> Open in Chat
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => openEdit(project)}>
          <Pencil className="h-4 w-4 mr-2" /> Edit
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleDuplicate(project)}>
          <Copy className="h-4 w-4 mr-2" /> Duplicate
        </DropdownMenuItem>
        {project.preview_url && (
          <DropdownMenuItem onClick={() => window.open(project.preview_url!, '_blank')}>
            <Eye className="h-4 w-4 mr-2" /> Preview
          </DropdownMenuItem>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem
          className="text-destructive focus:text-destructive"
          onClick={() => openDelete(project)}
        >
          <Trash2 className="h-4 w-4 mr-2" /> Delete
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );

  return (
    <DashboardLayout>
      <PageMeta title="My Projects - SiteGenie" noIndex />
      <div className="space-y-6 max-w-7xl">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
              <LayoutDashboard className="h-6 w-6 text-primary" />
              My Projects
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Manage and organize your AI-generated websites.
            </p>
          </div>
          <Button onClick={() => navigate('/dashboard/chat')} className="bg-primary hover:bg-primary/90 shrink-0">
            <Plus className="h-4 w-4 mr-2" /> New Project
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatCard label="Total Projects" value={stats.total} icon={<FolderOpen className="h-5 w-5" />} />
          <StatCard label="Published" value={stats.published} icon={<Globe className="h-5 w-5" />} />
          <StatCard label="Drafts" value={stats.drafts} icon={<FileText className="h-5 w-5" />} />
        </div>

        {/* Toolbar */}
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search projects..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex gap-2 shrink-0">
            <Select value={filter} onValueChange={(v) => setFilter(v as FilterStatus)}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="published">Published</SelectItem>
                <SelectItem value="draft">Drafts</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setView('grid')}
              className={view === 'grid' ? 'bg-accent' : ''}
              aria-label="Grid view"
              type="button"
            >
              <Grid3X3 className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setView('list')}
              className={view === 'list' ? 'bg-accent' : ''}
              aria-label="List view"
              type="button"
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Projects */}
        {loading ? (
          <div className={view === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4' : 'space-y-3'}>
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-40 rounded-xl bg-muted" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-20 text-center"
          >
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <FolderOpen className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">
              {search || filter !== 'all' ? 'No projects found' : 'No projects yet'}
            </h3>
            <p className="text-muted-foreground text-sm max-w-xs">
              {search || filter !== 'all'
                ? 'Try adjusting your search or filter.'
                : 'Create your first project and start building with AI.'}
            </p>
            {!search && filter === 'all' && (
              <Button onClick={() => navigate('/dashboard/chat')} className="mt-6 bg-primary hover:bg-primary/90">
                <Plus className="h-4 w-4 mr-2" /> Create First Project
              </Button>
            )}
          </motion.div>
        ) : view === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((project, i) => {
              const cfg = STATUS_CONFIG[project.status];
              return (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <Card className="h-full flex flex-col hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold truncate text-balance">{project.name}</h3>
                          {project.description && (
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2 text-pretty">
                              {project.description}
                            </p>
                          )}
                        </div>
                        <ProjectActions project={project} />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0 mt-auto">
                      <div className="flex items-center justify-between gap-2">
                        <Badge variant={cfg.variant} className="flex items-center gap-1 text-xs shrink-0">
                          {cfg.icon} {cfg.label}
                        </Badge>
                        <span className="text-xs text-muted-foreground hidden sm:block">{formatDate(project.updated_at)}</span>
                        <Button
                          size="sm"
                          variant="secondary"
                          className="h-7 gap-1.5 text-xs shrink-0 ml-auto"
                          onClick={() => navigate(`/dashboard/chat?project=${project.id}`)}
                        >
                          <MessageSquareCode className="h-3 w-3" /> Open in Chat
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map((project, i) => {
              const cfg = STATUS_CONFIG[project.status];
              return (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <Card>
                    <CardContent className="p-4 flex items-center gap-4">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{project.name}</p>
                        {project.description && (
                          <p className="text-xs text-muted-foreground truncate">{project.description}</p>
                        )}
                      </div>
                      <Badge variant={cfg.variant} className="flex items-center gap-1 text-xs shrink-0">
                        {cfg.icon} {cfg.label}
                      </Badge>
                      <span className="text-xs text-muted-foreground shrink-0 hidden md:block">
                        {formatDate(project.updated_at)}
                      </span>
                      <Button
                        size="sm"
                        variant="secondary"
                        className="h-7 gap-1.5 text-xs shrink-0"
                        onClick={() => navigate(`/dashboard/chat?project=${project.id}`)}
                      >
                        <MessageSquareCode className="h-3 w-3" />
                        <span className="hidden sm:inline">Open in Chat</span>
                      </Button>
                      <ProjectActions project={project} />
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Create Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>Create New Project</DialogTitle>
            <DialogDescription>Give your project a name to get started.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label htmlFor="new-name">Project Name</Label>
              <Input
                id="new-name"
                placeholder="My Awesome Website"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="mt-1.5"
              />
            </div>
            <div>
              <Label htmlFor="new-desc">Description (optional)</Label>
              <Textarea
                id="new-desc"
                placeholder="A brief description..."
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                className="mt-1.5 resize-none"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)} type="button">Cancel</Button>
            <Button
              onClick={handleCreate}
              disabled={creating || !newName.trim()}
              className="bg-primary hover:bg-primary/90"
              type="button"
            >
              {creating ? 'Creating...' : 'Create Project'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Project</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label htmlFor="edit-name">Project Name</Label>
              <Input
                id="edit-name"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="mt-1.5"
              />
            </div>
            <div>
              <Label htmlFor="edit-desc">Description</Label>
              <Textarea
                id="edit-desc"
                value={editDesc}
                onChange={(e) => setEditDesc(e.target.value)}
                className="mt-1.5 resize-none"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)} type="button">Cancel</Button>
            <Button
              onClick={handleEdit}
              disabled={editing || !editName.trim()}
              className="bg-primary hover:bg-primary/90"
              type="button"
            >
              {editing ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>Delete Project</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete <strong>{deleteTarget?.name}</strong>? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteOpen(false)} type="button">Cancel</Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleting}
              type="button"
            >
              {deleting ? 'Deleting...' : 'Delete Project'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
};

export default ProjectsPage;
